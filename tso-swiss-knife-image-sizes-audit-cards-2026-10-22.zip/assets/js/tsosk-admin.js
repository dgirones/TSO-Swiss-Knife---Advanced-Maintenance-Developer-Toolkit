/**
 * TSO Swiss Knife – Admin JavaScript
 *
 * Handles all AJAX interactions for every module tab.
 * All data is read from data-* attributes on buttons so nonces
 * are always fresh (rendered server-side per request).
 *
 * @package TSO_Swiss_Knife
 * @since   1.0.0
 */

/* global tsosk, jQuery */
( function ( $ ) {
	'use strict';

	// ── Helpers ────────────────────────────────────────────────────────────

	/**
	 * Show a brief status message inside an element, auto-hide after 4 s.
	 *
	 * @param {jQuery} $el      Target element.
	 * @param {string} msg      Message text.
	 * @param {string} [type]   'ok' | 'warn' | 'error'  (default 'ok').
	 * @param {number} [ttl]    Milliseconds before hiding (default 4000).
	 */
	function showMsg( $el, msg, type, ttl ) {
		var cls = 'tsosk-msg tsosk-msg--' + ( type || 'ok' );
		$el.attr( 'class', cls ).text( msg ).show();
		clearTimeout( $el.data( 'timer' ) );
		$el.data( 'timer', setTimeout( function () {
			$el.fadeOut( 300 );
		}, ttl || 4000 ) );
	}

	/**
	 * Generic AJAX POST wrapper.
	 *
	 * @param {Object}   params
	 * @param {string}   params.action   WP AJAX action slug.
	 * @param {Object}   params.data     Extra POST data.
	 * @param {Function} params.success  Callback( response ).
	 * @param {Function} [params.error]  Optional error callback( xhr ).
	 */
	function ajaxPost( params ) {
		var request = $.post(
			tsosk.ajax_url,
			$.extend( { action: params.action }, params.data ),
			function ( response ) {
				if ( params.success ) {
					params.success( response );
				}
			},
			'json'
		);
		request.fail( function ( xhr ) {
			if ( params.error ) {
				params.error( xhr );
			}
		} );
		if ( params.complete ) {
			request.always( params.complete );
		}
	}

	// ── Cron Manager ───────────────────────────────────────────────────────

	$( document ).on( 'click', '.tsosk-cron-run', function () {
		var $btn   = $( this );
		var hook   = $btn.data( 'hook' );
		var ts     = $btn.data( 'timestamp' );
		var sig    = $btn.data( 'sig' );
		var nonce  = $btn.data( 'nonce' );
		var $row   = $btn.closest( 'tr' );
		var $msg   = $row.find( '.tsosk-ajax-msg' );

		$btn.prop( 'disabled', true ).text( tsosk.i18n.running );

		ajaxPost( {
			action : 'tsosk_cron_run',
			data   : { hook: hook, timestamp: ts, sig: sig, nonce: nonce },
			success: function ( r ) {
				if ( r.success ) {
					showMsg( $msg, tsosk.i18n.done, 'ok' );
					setTimeout( function () { window.location.reload(); }, 700 );
				} else {
					showMsg( $msg, r.data || tsosk.i18n.error, 'error' );
					$btn.prop( 'disabled', false ).text( tsosk.i18n.run );
				}
			},
			error: function () {
				showMsg( $msg, tsosk.i18n.error, 'error' );
				$btn.prop( 'disabled', false ).text( tsosk.i18n.run );
			}
		} );
	} );

	$( document ).on( 'click', '.tsosk-cron-delete', function () {
		if ( ! window.confirm( tsosk.i18n.confirm_delete ) ) {
			return;
		}
		var $btn  = $( this );
		var hook  = $btn.data( 'hook' );
		var ts    = $btn.data( 'timestamp' );
		var sig   = $btn.data( 'sig' );
		var nonce = $btn.data( 'nonce' );
		var $row  = $btn.closest( 'tr' );

		$btn.prop( 'disabled', true );

		ajaxPost( {
			action : 'tsosk_cron_delete',
			data   : { hook: hook, timestamp: ts, sig: sig, nonce: nonce },
			success: function ( r ) {
				if ( r.success ) {
					$row.fadeOut( 300, function () { $( this ).remove(); } );
				} else {
					alert( r.data || tsosk.i18n.error );
					$btn.prop( 'disabled', false );
				}
			},
			error: function () {
				alert( tsosk.i18n.error );
				$btn.prop( 'disabled', false );
			}
		} );
	} );

	$( document ).on( 'click', '.tsosk-cron-edit', function () {
		var $btn = $( this );
		var ts   = parseInt( $btn.data( 'timestamp' ), 10 );
		var when = new Date( ts * 1000 );
		var pad  = function ( n ) { return n < 10 ? '0' + n : String( n ); };
		var local = when.getFullYear() + '-' + pad( when.getMonth() + 1 ) + '-' + pad( when.getDate() )
			+ 'T' + pad( when.getHours() ) + ':' + pad( when.getMinutes() );

		$( '#tsosk-cron-edit-hook' ).val( $btn.data( 'hook' ) );
		$( '#tsosk-cron-edit-timestamp' ).val( $btn.data( 'timestamp' ) );
		$( '#tsosk-cron-edit-sig' ).val( $btn.data( 'sig' ) );
		$( '#tsosk-cron-edit-when' ).val( local );
		$( '#tsosk-cron-edit-schedule' ).val( $btn.data( 'schedule' ) || 'single' );
		$( '#tsosk-cron-edit-msg' ).hide().text( '' );
		$( '#tsosk-cron-edit-panel' ).slideDown( 200 );
		$( 'html, body' ).animate( { scrollTop: $( '#tsosk-cron-edit-panel' ).offset().top - 40 }, 200 );
	} );

	$( document ).on( 'click', '#tsosk-cron-edit-cancel', function () {
		$( '#tsosk-cron-edit-panel' ).slideUp( 200 );
	} );

	$( document ).on( 'click', '#tsosk-cron-edit-save', function () {
		var $btn  = $( this );
		var $msg  = $( '#tsosk-cron-edit-msg' );
		var when  = $( '#tsosk-cron-edit-when' ).val();
		if ( ! when ) {
			showMsg( $msg, tsosk.i18n.error, 'error' );
			return;
		}
		var newTs = Math.floor( new Date( when ).getTime() / 1000 );
		if ( ! newTs || isNaN( newTs ) ) {
			showMsg( $msg, tsosk.i18n.error, 'error' );
			return;
		}

		$btn.prop( 'disabled', true );
		ajaxPost( {
			action : 'tsosk_cron_reschedule',
			data   : {
				nonce         : $( '#tsosk-cron-edit-nonce' ).val(),
				hook          : $( '#tsosk-cron-edit-hook' ).val(),
				timestamp     : $( '#tsosk-cron-edit-timestamp' ).val(),
				sig           : $( '#tsosk-cron-edit-sig' ).val(),
				new_timestamp : newTs,
				schedule      : $( '#tsosk-cron-edit-schedule' ).val()
			},
			success: function ( r ) {
				if ( r.success ) {
					showMsg( $msg, r.data || tsosk.i18n.cron_rescheduled, 'ok' );
					setTimeout( function () { window.location.reload(); }, 700 );
				} else {
					showMsg( $msg, r.data || tsosk.i18n.error, 'error' );
					$btn.prop( 'disabled', false );
				}
			},
			error: function () {
				showMsg( $msg, tsosk.i18n.error, 'error' );
				$btn.prop( 'disabled', false );
			}
		} );
	} );

	// ── Debug Mode ─────────────────────────────────────────────────────────

	$( document ).on( 'click', '.tsosk-clear-log', function () {
		var $btn  = $( this );
		var nonce = $btn.data( 'nonce' );
		var $msg  = $( '#tsosk-log-msg' );
		var path  = $btn.data( 'log-path' );
		var label = $btn.data( 'log-label' ) || path;
		var confirmMsg = tsosk.i18n.debug_empty_log_confirm.replace( '%s', label );

		if ( ! confirm( confirmMsg ) ) {
			return;
		}

		$btn.prop( 'disabled', true );

		ajaxPost( {
			action : 'tsosk_debug_clear_log',
			data   : { nonce: nonce, log_path: path },
			success: function ( r ) {
				if ( r.success ) {
					showMsg( $msg, r.data || tsosk.i18n.done, 'ok' );
					var anchor = $btn.closest( 'tr' ).find( 'a[href^="#tsosk-log-"]' ).attr( 'href' );
					if ( anchor ) {
						$( anchor ).find( '.tsosk-log-preview' ).empty();
					}
				} else {
					showMsg( $msg, r.data || tsosk.i18n.error, 'error' );
				}
				$btn.prop( 'disabled', false );
			},
			error: function () {
				showMsg( $msg, tsosk.i18n.error, 'error' );
				$btn.prop( 'disabled', false );
			}
		} );
	} );

	$( document ).on( 'click', '.tsosk-shrink-log', function () {
		var $btn  = $( this );
		var nonce = $btn.data( 'nonce' );
		var $msg  = $( '#tsosk-log-msg' );
		var path  = $btn.data( 'log-path' );
		var label = $btn.data( 'log-label' ) || path;
		var confirmMsg = ( tsosk.i18n.debug_shrink_log_confirm || 'Keep only the last 500 lines of %s? Older lines will be archived.' ).replace( '%s', label );

		if ( ! confirm( confirmMsg ) ) {
			return;
		}

		$btn.prop( 'disabled', true );

		ajaxPost( {
			action : 'tsosk_debug_shrink_log',
			data   : { nonce: nonce, log_path: path, keep_lines: 500 },
			success: function ( r ) {
				showMsg( $msg, r.success ? ( r.data || tsosk.i18n.done ) : ( r.data || tsosk.i18n.error ), r.success ? 'ok' : 'error' );
				if ( r.success ) {
					setTimeout( function () { window.location.reload(); }, 1200 );
				}
				$btn.prop( 'disabled', false );
			},
			error: function () {
				showMsg( $msg, tsosk.i18n.error, 'error' );
				$btn.prop( 'disabled', false );
			}
		} );
	} );

	function tsoskScrollLogPreviewToEnd( path ) {
		var $preview = path
			? tsoskFindLogTargets( path ).card.find( '.tsosk-log-preview' )
			: $( [] );

		if ( ! $preview.length ) {
			return;
		}

		var el = $preview.get( 0 );
		el.scrollTop = el.scrollHeight;
	}

	function tsoskFindLogTargets( path ) {
		return {
			card: $( '.tsosk-log-card' ).filter( function () {
				return $( this ).attr( 'data-log-path' ) === path;
			} ),
			row: $( '.tsosk-log-row' ).filter( function () {
				return $( this ).attr( 'data-log-path' ) === path;
			} ),
			buttons: $( '.tsosk-refresh-log' ).filter( function () {
				return $( this ).attr( 'data-log-path' ) === path;
			} )
		};
	}

	function tsoskApplyLogRefresh( path, data ) {
		var targets = tsoskFindLogTargets( path );

		if ( ! data.unchanged && data.html && targets.card.length ) {
			targets.card.find( '.tsosk-log-preview' ).html( data.html );
			targets.card.find( '.tsosk-log-size' ).text( data.size );
			targets.card.attr( 'data-log-modified', data.modified );
			targets.card.find( '.tsosk-log-search' ).trigger( 'input' );
		}

		if ( targets.row.length ) {
			targets.row.find( '.tsosk-log-size-cell' ).text( data.size );
			targets.row.find( '.tsosk-log-modified-cell' ).text( data.modified_label || '' );
			targets.row.attr( 'data-log-modified', data.modified );
		}
	}

	$( document ).on( 'click', '.tsosk-refresh-log', function () {
		var $btn   = $( this );
		var nonce  = $btn.data( 'nonce' );
		var path   = $btn.attr( 'data-log-path' ) || '';
		var $msg   = $( '#tsosk-log-msg' );
		var targets = tsoskFindLogTargets( path );
		var source = targets.card.length ? targets.card : targets.row;
		var lastModified = parseInt( source.attr( 'data-log-modified' ) || '0', 10 );
		var label = tsosk.i18n.refresh_log || 'Refresh';

		if ( ! path ) {
			return;
		}

		targets.buttons.prop( 'disabled', true ).text( tsosk.i18n.running );

		ajaxPost( {
			action : 'tsosk_debug_refresh_log',
			data   : { nonce: nonce, log_path: path, last_modified: lastModified },
			success: function ( r ) {
				if ( r.success && r.data ) {
					tsoskApplyLogRefresh( path, r.data );
					showMsg( $msg, r.data.message || tsosk.i18n.done, 'ok' );
					tsoskScrollLogPreviewToEnd( path );
				} else {
					showMsg( $msg, r.data || tsosk.i18n.error, 'error' );
				}
				targets.buttons.prop( 'disabled', false ).text( label );
			},
			error: function () {
				showMsg( $msg, tsosk.i18n.error, 'error' );
				targets.buttons.prop( 'disabled', false ).text( label );
			}
		} );
	} );

	$( document ).on( 'click', '.tsosk-log-scroll-end', function () {
		var $card = $( this ).closest( '.tsosk-log-card' );
		var path  = $card.attr( 'data-log-path' ) || '';

		if ( path ) {
			tsoskScrollLogPreviewToEnd( path );
		}

		var $preview = $card.find( '.tsosk-log-preview' );
		if ( $preview.length && $preview.get( 0 ).scrollIntoView ) {
			$preview.get( 0 ).scrollIntoView( { block: 'nearest', behavior: 'smooth' } );
		}
	} );

	$( document ).on( 'input change', '.tsosk-log-search, .tsosk-log-level', function () {
		var $card = $( this ).closest( '.tsosk-card' );
		var query = $card.find( '.tsosk-log-search' ).val().toLowerCase();
		var level = $card.find( '.tsosk-log-level' ).val();

		$card.find( '.tsosk-log-line' ).each( function () {
			var $line = $( this );
			var textMatches = ! query || $line.text().toLowerCase().indexOf( query ) !== -1;
			var levelMatches = level === 'all' || $line.data( 'level' ) === level;
			$line.toggle( textMatches && levelMatches );
		} );
	} );

	// ── Health Report ──────────────────────────────────────────────────────

	$( document ).on( 'click', '#tsosk-404-save-alerts', function () {
		var $btn = $( this );
		var $msg = $( '#tsosk-404-alerts-msg' );

		$btn.prop( 'disabled', true ).text( tsosk.i18n.running );

		ajaxPost( {
			action : 'tsosk_404_save_alerts',
			data   : {
				nonce              : $btn.data( 'nonce' ),
				enabled            : $( '#tsosk-alerts-enabled' ).prop( 'checked' ) ? 1 : 0,
				email              : $( '#tsosk-alerts-email' ).val(),
				not_found_threshold: $( '#tsosk-alerts-404-threshold' ).val()
			},
			success: function ( r ) {
				showMsg( $msg, r.success ? ( r.data || tsosk.i18n.done ) : ( r.data || tsosk.i18n.error ), r.success ? 'ok' : 'error' );
				$btn.prop( 'disabled', false ).text( tsosk.i18n.save_alerts );
			},
			error: function () {
				showMsg( $msg, tsosk.i18n.error, 'error' );
				$btn.prop( 'disabled', false ).text( tsosk.i18n.save_alerts );
			}
		} );
	} );

	$( document ).on( 'click', '#tsosk-404-test-alert', function () {
		var $btn  = $( this );
		var $msg  = $( '#tsosk-404-alerts-msg' );
		var label = $btn.text();

		$btn.prop( 'disabled', true ).text( tsosk.i18n.running );

		ajaxPost( {
			action : 'tsosk_404_test_alert',
			data   : { nonce: $btn.data( 'nonce' ) },
			success: function ( r ) {
				showMsg( $msg, r.success ? ( r.data || tsosk.i18n.done ) : ( r.data || tsosk.i18n.error ), r.success ? 'ok' : 'error' );
				$btn.prop( 'disabled', false ).text( label );
			},
			error: function () {
				showMsg( $msg, tsosk.i18n.error, 'error' );
				$btn.prop( 'disabled', false ).text( label );
			}
		} );
	} );

	// ── WP Internals ───────────────────────────────────────────────────────

	$( document ).on( 'input', '#tsosk-internals-search', function () {
		var q = $( this ).val().toLowerCase();
		$( '.tsosk-internals-row' ).each( function () {
			$( this ).toggle( $( this ).text().toLowerCase().indexOf( q ) !== -1 );
		} );
	} );

	// ── Users & Sessions ───────────────────────────────────────────────────

	$( document ).on( 'click', '.tsosk-user-close-sessions', function () {
		if ( ! window.confirm( tsosk.i18n.confirm_delete ) ) {
			return;
		}
		var $btn = $( this );
		var $msg = $btn.siblings( '.tsosk-ajax-msg' );

		$btn.prop( 'disabled', true ).text( tsosk.i18n.running );
		ajaxPost( {
			action : 'tsosk_user_destroy_sessions',
			data   : { nonce: $btn.data( 'nonce' ), user_id: $btn.data( 'user-id' ) },
			success: function ( r ) {
				if ( r.success ) {
					showMsg( $msg, r.data || tsosk.i18n.done, 'ok' );
					setTimeout( function () { window.location.reload(); }, 600 );
				} else {
					showMsg( $msg, r.data || tsosk.i18n.error, 'error' );
					$btn.prop( 'disabled', false ).text( tsosk.i18n.close_all_sessions );
				}
			},
			error: function () {
				showMsg( $msg, tsosk.i18n.error, 'error' );
				$btn.prop( 'disabled', false ).text( tsosk.i18n.close_all_sessions );
			}
		} );
	} );

	$( document ).on( 'click', '.tsosk-user-close-one-session', function () {
		var $btn = $( this );
		var $row = $btn.closest( 'tr' );
		$btn.prop( 'disabled', true );
		ajaxPost( {
			action : 'tsosk_user_destroy_one_session',
			data   : { nonce: $btn.data( 'nonce' ), user_id: $btn.data( 'user-id' ), token: $btn.data( 'token' ) },
			success: function ( r ) {
				if ( r.success ) {
					$row.fadeOut( 300, function () { $( this ).remove(); } );
				} else {
					alert( r.data || tsosk.i18n.error );
					$btn.prop( 'disabled', false );
				}
			},
			error: function () {
				alert( tsosk.i18n.error );
				$btn.prop( 'disabled', false );
			}
		} );
	} );

	$( document ).on( 'click', '.tsosk-user-force-pwd', function () {
		if ( ! window.confirm( tsosk.i18n.force_pwd_confirm ) ) { return; }
		var $btn = $( this );
		var $msg = $btn.siblings( '.tsosk-ajax-msg' );
		ajaxPost( {
			action : 'tsosk_user_force_password',
			data   : { nonce: $btn.data( 'nonce' ), user_id: $btn.data( 'user-id' ) },
			success: function ( r ) {
				showMsg( $msg, r.success ? ( r.data || tsosk.i18n.done ) : ( r.data || tsosk.i18n.error ), r.success ? 'ok' : 'error' );
			},
			error: function () { showMsg( $msg, tsosk.i18n.error, 'error' ); }
		} );
	} );

	function tsoskUsersBulkInactive( action ) {
		var nonce = $( '#tsosk-users-bulk-nonce' ).val();
		var ids   = [];
		$( '.tsosk-users-inactive-cb:checked' ).each( function () { ids.push( $( this ).val() ); } );
		if ( ! ids.length ) {
			window.alert( tsosk.i18n.users_select_one );
			return;
		}
		if ( ! window.confirm( action === 'delete' ? tsosk.i18n.confirm_delete : tsosk.i18n.users_bulk_confirm ) ) {
			return;
		}
		var $msg = $( '#tsosk-users-bulk-msg' );
		ajaxPost( {
			action : 'tsosk_user_bulk_inactive',
			data   : { nonce: nonce, bulk_action: action, user_ids: ids, days: 90 },
			success: function ( r ) {
				showMsg( $msg, r.success ? ( r.data || tsosk.i18n.done ) : ( r.data || tsosk.i18n.error ), r.success ? 'ok' : 'error' );
				if ( r.success ) { setTimeout( function () { window.location.reload(); }, 700 ); }
			},
			error: function () { showMsg( $msg, tsosk.i18n.error, 'error' ); }
		} );
	}

	$( document ).on( 'click', '#tsosk-users-bulk-subscriber', function () { tsoskUsersBulkInactive( 'subscriber' ); } );
	$( document ).on( 'click', '#tsosk-users-bulk-delete', function () { tsoskUsersBulkInactive( 'delete' ); } );
	$( document ).on( 'change', '#tsosk-users-select-all', function () {
		$( '.tsosk-users-inactive-cb' ).prop( 'checked', $( this ).prop( 'checked' ) );
	} );

	$( document ).on( 'click', '#tsosk-users-clear-history', function () {
		if ( ! window.confirm( tsosk.i18n.confirm_delete ) ) { return; }
		var $btn = $( this );
		var $msg = $( '#tsosk-users-history-msg' );
		ajaxPost( {
			action : 'tsosk_users_clear_history',
			data   : { nonce: $btn.data( 'nonce' ) },
			success: function ( r ) {
				showMsg( $msg, r.success ? ( r.data || tsosk.i18n.done ) : ( r.data || tsosk.i18n.error ), r.success ? 'ok' : 'error' );
				if ( r.success ) { setTimeout( function () { window.location.reload(); }, 600 ); }
			},
			error: function () { showMsg( $msg, tsosk.i18n.error, 'error' ); }
		} );
	} );

	// ── Media Cleaner ──────────────────────────────────────────────────────

	// Full media review: runs in batches; "Resume" continues an interrupted scan from the stored state.
	function tsoskMediaRun( $btn, start ) {
		var $main = $( '#tsosk-media-full-review' );
		var $msg  = $( '#tsosk-media-full-review-msg' );
		var $prog = $( '#tsosk-media-full-review-progress' );
		var nonce = $btn.data( 'nonce' );
		var label = tsosk.i18n.media_full_review || 'Run full media review';
		var fails = 0;

		function finish() {
			$main.prop( 'disabled', false ).text( label );
			$( '#tsosk-media-full-review-resume' ).prop( 'disabled', false );
		}

		function tick( first ) {
			ajaxPost( {
				action : 'tsosk_media_full_review',
				data   : { nonce: nonce, start: first ? 1 : 0 },
				success: function ( r ) {
					fails = 0;
					if ( ! r.success ) {
						showMsg( $msg, r.data || tsosk.i18n.error, 'error' );
						finish();
						return;
					}
					if ( r.data.progress ) {
						$prog.text( r.data.progress );
					}
					if ( r.data.done ) {
						var html = r.data.html || {};
						$( '#tsosk-media-resume-note' ).remove();
						if ( undefined !== html.summary ) {
							$( '#tsosk-media-summary-wrap' ).html( html.summary );
						}
						if ( html.missing ) {
							$( '#tsosk-media-missing-wrap' ).html( html.missing );
						}
						if ( undefined !== html.duplicates ) {
							$( '#tsosk-media-duplicates-wrap' ).html( html.duplicates );
						}
						if ( html.orphans ) {
							$( '#tsosk-media-orphans-wrap' ).html( html.orphans );
						}
						showMsg( $msg, r.data.message || tsosk.i18n.done, 'ok' );
						finish();
						return;
					}
					tick( false );
				},
				error: function () {
					// A slow or failed request keeps the stored state: retry a few times, then offer Resume.
					fails++;
					if ( fails <= 2 ) {
						setTimeout( function () { tick( false ); }, 1500 * fails );
						return;
					}
					showMsg( $msg, tsosk.i18n.media_scan_interrupted || tsosk.i18n.error, 'error' );
					finish();
					if ( ! $( '#tsosk-media-full-review-resume' ).length ) {
						$main.after( $( '<button type="button" class="button" id="tsosk-media-full-review-resume"></button>' )
							.attr( 'data-nonce', nonce )
							.text( tsosk.i18n.media_resume || 'Resume' ) );
					}
				}
			} );
		}

		$main.prop( 'disabled', true ).text( tsosk.i18n.running );
		$( '#tsosk-media-full-review-resume' ).prop( 'disabled', true );
		showMsg( $msg, '', '' );
		if ( start ) {
			$prog.text( tsosk.i18n.media_full_review_starting || 'Starting full media review…' );
		}
		tick( start );
	}

	$( document ).on( 'click', '#tsosk-media-full-review', function () {
		tsoskMediaRun( $( this ), true );
	} );

	$( document ).on( 'click', '#tsosk-media-full-review-resume', function () {
		tsoskMediaRun( $( this ), false );
	} );

	$( document ).on( 'click', '.tsosk-media-regenerate', function () {
		var $btn = $( this );
		var $msg = $btn.siblings( '.tsosk-ajax-msg' );

		$btn.prop( 'disabled', true ).text( tsosk.i18n.running );
		ajaxPost( {
			action : 'tsosk_media_regenerate',
			data   : { nonce: $btn.data( 'nonce' ), attachment_id: $btn.data( 'attachment-id' ) },
			success: function ( r ) {
				if ( r.success ) {
					showMsg( $msg, r.data || tsosk.i18n.done, 'ok' );
				} else {
					showMsg( $msg, r.data || tsosk.i18n.error, 'error' );
				}
				$btn.prop( 'disabled', false ).text( tsosk.i18n.regenerate );
			},
			error: function () {
				showMsg( $msg, tsosk.i18n.error, 'error' );
				$btn.prop( 'disabled', false ).text( tsosk.i18n.regenerate );
			}
		} );
	} );

	// ── Email Diagnostics ──────────────────────────────────────────────────

	function tsoskEmailPayloadMessage( data, fallback ) {
		if ( data && typeof data === 'object' && data.message ) {
			return data.message;
		}
		if ( typeof data === 'string' && data ) {
			return data;
		}
		return fallback || tsosk.i18n.error;
	}

	function tsoskEmailApplyResultsHtml( data ) {
		if ( data && typeof data === 'object' && data.html ) {
			$( '#tsosk-email-results' ).html( data.html );
		}
	}

	$( document ).on( 'click', '#tsosk-email-send-test', function () {
		var $btn = $( this );
		var $msg = $( '#tsosk-email-msg' );
		var format = $( 'input[name="tsosk_email_format"]:checked' ).val() || 'plain';

		$btn.prop( 'disabled', true ).text( tsosk.i18n.running );
		ajaxPost( {
			action : 'tsosk_email_send_test',
			data   : {
				nonce  : $btn.data( 'nonce' ),
				email  : $( '#tsosk-email-test-address' ).val(),
				cc     : $( '#tsosk-email-test-cc' ).val(),
				format : format
			},
			success: function ( r ) {
				if ( r.success ) {
					showMsg( $msg, tsoskEmailPayloadMessage( r.data, tsosk.i18n.done ), 'ok' );
					tsoskEmailApplyResultsHtml( r.data );
				} else {
					showMsg( $msg, tsoskEmailPayloadMessage( r.data, tsosk.i18n.error ), 'error' );
					tsoskEmailApplyResultsHtml( r.data );
				}
				$btn.prop( 'disabled', false ).text( tsosk.i18n.send_test );
			},
			error: function ( xhr ) {
				var data = xhr && xhr.responseJSON ? xhr.responseJSON.data : null;
				showMsg( $msg, tsoskEmailPayloadMessage( data, tsosk.i18n.error ), 'error' );
				tsoskEmailApplyResultsHtml( data );
				$btn.prop( 'disabled', false ).text( tsosk.i18n.send_test );
			}
		} );
	} );

	$( document ).on( 'click', '#tsosk-email-copy-report', function () {
		var $msg = $( '#tsosk-email-copy-msg' );
		var text = $( '#tsosk-email-report' ).val() || '';
		var doneLabel = ( tsosk.i18n && tsosk.i18n.email_copied ) ? tsosk.i18n.email_copied : 'Copied';

		function onCopied() {
			showMsg( $msg, doneLabel, 'ok' );
		}

		if ( navigator.clipboard && navigator.clipboard.writeText ) {
			navigator.clipboard.writeText( text ).then( onCopied ).catch( function () {
				$( '#tsosk-email-report' ).trigger( 'select' );
				try {
					document.execCommand( 'copy' );
					onCopied();
				} catch ( e ) {
					showMsg( $msg, tsosk.i18n.error, 'error' );
				}
			} );
			return;
		}

		$( '#tsosk-email-report' ).trigger( 'select' );
		try {
			document.execCommand( 'copy' );
			onCopied();
		} catch ( e2 ) {
			showMsg( $msg, tsosk.i18n.error, 'error' );
		}
	} );

	// ── Transients Manager ─────────────────────────────────────────────────

	$( document ).on( 'click', '.tsosk-transient-delete', function () {
		if ( ! window.confirm( tsosk.i18n.confirm_delete ) ) {
			return;
		}
		var $btn  = $( this );
		var key   = $btn.data( 'key' );
		var nonce = $btn.data( 'nonce' );
		var $row  = $btn.closest( 'tr' );

		$btn.prop( 'disabled', true );

		ajaxPost( {
			action : 'tsosk_transient_delete',
			data   : { nonce: nonce, key: key },
			success: function ( r ) {
				if ( r.success ) {
					$row.fadeOut( 300, function () { $( this ).remove(); } );
				} else {
					alert( r.data || tsosk.i18n.error );
					$btn.prop( 'disabled', false );
				}
			},
			error: function () {
				alert( tsosk.i18n.error );
				$btn.prop( 'disabled', false );
			}
		} );
	} );

	$( document ).on( 'click', '#tsosk-purge-expired', function () {
		var $btn  = $( this );
		var nonce = $btn.data( 'nonce' );
		var $msg  = $( '#tsosk-transient-bulk-msg' );

		$btn.prop( 'disabled', true ).text( tsosk.i18n.running );

		ajaxPost( {
			action : 'tsosk_transients_purge_exp',
			data   : { nonce: nonce },
			success: function ( r ) {
				if ( r.success ) {
					showMsg( $msg, r.data || tsosk.i18n.done, 'ok' );
					// Remove expired rows from table.
					$( '.tsosk-transient-expired' ).closest( 'tr' ).fadeOut( 400, function () {
						$( this ).remove();
					} );
				} else {
					showMsg( $msg, r.data || tsosk.i18n.error, 'error' );
				}
				$btn.prop( 'disabled', false ).text( tsosk.i18n.purge_expired );
			},
			error: function () {
				showMsg( $msg, tsosk.i18n.error, 'error' );
				$btn.prop( 'disabled', false ).text( tsosk.i18n.purge_expired );
			}
		} );
	} );

	$( document ).on( 'click', '#tsosk-purge-all', function () {
		if ( ! window.confirm( tsosk.i18n.confirm_purge ) ) {
			return;
		}
		var $btn  = $( this );
		var nonce = $btn.data( 'nonce' );
		var $msg  = $( '#tsosk-transient-bulk-msg' );

		$btn.prop( 'disabled', true ).text( tsosk.i18n.running );

		ajaxPost( {
			action : 'tsosk_transients_purge_all',
			data   : { nonce: nonce },
			success: function ( r ) {
				if ( r.success ) {
					showMsg( $msg, r.data || tsosk.i18n.done, 'ok' );
					$( '#tsosk-transients-table tbody tr' ).fadeOut( 400, function () {
						$( this ).remove();
					} );
				} else {
					showMsg( $msg, r.data || tsosk.i18n.error, 'error' );
				}
				$btn.prop( 'disabled', false ).text( tsosk.i18n.purge_all );
			},
			error: function () {
				showMsg( $msg, tsosk.i18n.error, 'error' );
				$btn.prop( 'disabled', false ).text( tsosk.i18n.purge_all );
			}
		} );
	} );

	// Transients: live filter.
	$( document ).on( 'input', '#tsosk-transients-search', function () {
		var q = $( this ).val().toLowerCase();
		$( '#tsosk-transients-table tbody tr' ).each( function () {
			var key = $( this ).find( 'td:first' ).text().toLowerCase();
			$( this ).toggle( key.indexOf( q ) !== -1 );
		} );
	} );

	// Transients: status filter tabs.
	$( document ).on( 'click', '.tsosk-transients-filter', function () {
		var filter = $( this ).data( 'filter' );
		$( '.tsosk-transients-filter' ).removeClass( 'tsosk-filter-active' );
		$( this ).addClass( 'tsosk-filter-active' );
		$( '#tsosk-transients-filter-select' ).val( filter );

		$( '#tsosk-transients-table tbody tr' ).each( function () {
			if ( filter === 'all' ) {
				$( this ).show();
			} else if ( filter === 'expired' ) {
				$( this ).toggle( $( this ).hasClass( 'tsosk-transient-expired' ) );
			} else if ( filter === 'active' ) {
				$( this ).toggle( ! $( this ).hasClass( 'tsosk-transient-expired' ) );
			}
		} );
	} );

	// Transients: sync filter pills with server-side filter on load.
	( function () {
		var active = $( '.tsosk-filter-pills' ).data( 'active-filter' );
		if ( active && active !== 'all' ) {
			$( '.tsosk-transients-filter' ).removeClass( 'tsosk-filter-active' );
			$( '.tsosk-transients-filter[data-filter="' + active + '"]' ).addClass( 'tsosk-filter-active' );
		}
	} )();

	// Transients: sortable columns (client-side).
	$( document ).on( 'click', '#tsosk-transients-table th.tsosk-sortable', function () {
		var $th    = $( this );
		var col    = $th.data( 'sort' );
		var asc    = $th.hasClass( 'tsosk-sort-asc' );
		var $tbody = $( '#tsosk-transients-table tbody' );
		var rows   = $tbody.find( 'tr' ).get();

		$( '#tsosk-transients-table th.tsosk-sortable' ).removeClass( 'tsosk-sort-asc tsosk-sort-desc' );
		$th.addClass( asc ? 'tsosk-sort-desc' : 'tsosk-sort-asc' );

		rows.sort( function ( a, b ) {
			var av, bv;
			if ( col === 'key' ) {
				av = $( a ).data( 'key' ) || '';
				bv = $( b ).data( 'key' ) || '';
				return String( av ).localeCompare( String( bv ) );
			}
			if ( col === 'size' || col === 'timeout' ) {
				av = parseInt( $( a ).data( col ), 10 ) || 0;
				bv = parseInt( $( b ).data( col ), 10 ) || 0;
				return av - bv;
			}
			if ( col === 'status' ) {
				av = $( a ).data( 'status' ) || '';
				bv = $( b ).data( 'status' ) || '';
				return String( av ).localeCompare( String( bv ) );
			}
			return 0;
		} );

		if ( asc ) {
			rows.reverse();
		}
		$.each( rows, function ( _, row ) {
			$tbody.append( row );
		} );
	} );

	// ── Constants: live search ──────────────────────────────────────────────

	$( document ).on( 'input', '#tsosk-constants-search', function () {
		var q = $( this ).val().toLowerCase();
		$( '.tsosk-constant-row' ).each( function () {
			var name = $( this ).find( 'td:first' ).text().toLowerCase();
			$( this ).toggle( name.indexOf( q ) !== -1 );
		} );
		// Hide group headers that have no visible rows.
		$( '.tsosk-card' ).each( function () {
			var $card    = $( this );
			var visible  = $card.find( '.tsosk-constant-row:visible' ).length;
			$card.toggle( visible > 0 );
		} );
	} );

	// ── REST API Controls ──────────────────────────────────────────────────

	$( document ).on( 'click', '#tsosk-rest-save', function () {
		var $btn       = $( this );
		var nonce      = $btn.data( 'nonce' );
		var $msg       = $( '#tsosk-rest-msg' );
		var mode       = $( 'input[name="tsosk_rest_mode"]:checked' ).val();
		var disabled_ns = [];
		var blockUserEnum = $( '#tsosk-rest-block-user-enum' ).prop( 'checked' ) ? 1 : 0;

		$( '.tsosk-ns-cb:checked' ).each( function () {
			disabled_ns.push( $( this ).val() );
		} );

		$btn.prop( 'disabled', true );

		ajaxPost( {
			action : 'tsosk_rest_save',
			data   : { nonce: nonce, mode: mode, disabled_namespaces: disabled_ns, block_user_enumeration: blockUserEnum },
			success: function ( r ) {
				if ( r.success ) {
					showMsg( $msg, tsosk.i18n.done, 'ok' );
				} else {
					showMsg( $msg, r.data || tsosk.i18n.error, 'error' );
				}
				$btn.prop( 'disabled', false );
			},
			error: function () {
				showMsg( $msg, tsosk.i18n.error, 'error' );
				$btn.prop( 'disabled', false );
			}
		} );
	} );

	$( document ).on( 'click', '#tsosk-rest-clear-log', function () {
		var $btn  = $( this );
		var nonce = $btn.data( 'nonce' );

		$btn.prop( 'disabled', true );

		ajaxPost( {
			action : 'tsosk_rest_clear_log',
			data   : { nonce: nonce },
			success: function ( r ) {
				if ( r.success ) {
					window.location.reload();
				} else {
					$btn.prop( 'disabled', false );
				}
			},
			error: function () {
				$btn.prop( 'disabled', false );
			}
		} );
	} );

	// ── Heartbeat Controls ─────────────────────────────────────────────────

	$( document ).on( 'click', '#tsosk-heartbeat-save', function () {
		var $btn     = $( this );
		var nonce    = $btn.data( 'nonce' );
		var $msg     = $( '#tsosk-heartbeat-msg' );
		var mode     = $( 'input[name="tsosk_heartbeat_mode"]:checked' ).val();
		var interval = parseInt( $( '#tsosk-heartbeat-interval' ).val(), 10 ) || 0;

		$btn.prop( 'disabled', true );

		ajaxPost( {
			action : 'tsosk_heartbeat_save',
			data   : { nonce: nonce, mode: mode, interval: interval },
			success: function ( r ) {
				if ( r.success ) {
					showMsg( $msg, r.data || tsosk.i18n.done, 'ok' );
				} else {
					showMsg( $msg, r.data || tsosk.i18n.error, 'error' );
				}
				$btn.prop( 'disabled', false );
			},
			error: function () {
				showMsg( $msg, tsosk.i18n.error, 'error' );
				$btn.prop( 'disabled', false );
			}
		} );
	} );

	// ── Update Manager ───────────────────────────────────────────────────────

	$( document ).on( 'change', 'input[name="tsosk_um_preset"]', function () {
		var preset = $( 'input[name="tsosk_um_preset"]:checked' ).val();
		$( '.tsosk-um-custom-panel' ).toggle( preset === 'custom' );
	} );

	$( document ).on( 'input', '#tsosk-um-plugin-filter', function () {
		var q = $( this ).val().toLowerCase();
		$( '.tsosk-um-plugin-row' ).each( function () {
			var hay = $( this ).data( 'search' ) || '';
			$( this ).toggle( ! q || String( hay ).indexOf( q ) !== -1 );
		} );
	} );

	$( document ).on( 'click', '#tsosk-um-run-updates', function () {
		var $btn  = $( this );
		var nonce = $btn.data( 'nonce' );
		var $msg  = $( '#tsosk-um-run-msg' );
		var label = $btn.text();

		$btn.prop( 'disabled', true ).text( tsosk.i18n.running );

		ajaxPost( {
			action : 'tsosk_um_run_updates',
			data   : { nonce: nonce },
			success: function ( r ) {
				if ( r.success ) {
					var text = ( r.data && r.data.message ) ? r.data.message : ( r.data || tsosk.i18n.done );
					showMsg( $msg, text, 'ok' );
					setTimeout( function () { window.location.reload(); }, 1500 );
				} else {
					showMsg( $msg, r.data || tsosk.i18n.error, 'error' );
					$btn.prop( 'disabled', false ).text( label );
				}
			},
			error: function () {
				showMsg( $msg, tsosk.i18n.error, 'error' );
				$btn.prop( 'disabled', false ).text( label );
			}
		} );
	} );

	$( document ).on( 'click', '.tsosk-um-install-all', function () {
		var $btn  = $( this );
		var nonce = $btn.data( 'nonce' );
		var $msg  = $btn.nextAll( '.tsosk-um-install-msg' ).first();
		var label = $btn.text();
		var confirmMsg = ( tsosk.i18n.um_install_all_confirm || 'Install the pending updates now?' )
			.replace( '%1$d', String( parseInt( $btn.data( 'plugins' ), 10 ) || 0 ) )
			.replace( '%2$d', String( parseInt( $btn.data( 'themes' ), 10 ) || 0 ) )
			.replace( '%3$d', String( parseInt( $btn.data( 'translations' ), 10 ) || 0 ) );

		if ( ! window.confirm( confirmMsg ) ) {
			return;
		}

		var done   = [];
		var failed = [];
		var skip   = [];

		$( '.tsosk-um-install-all, .tsosk-um-update-plugin, #tsosk-um-run-updates, #tsosk-um-install-translations' ).prop( 'disabled', true );
		// Keep the button the same width while it says "Running…", so nothing next to it moves.
		$btn.css( 'min-width', $btn.outerWidth() + 'px' ).text( tsosk.i18n.running );

		function finish( errorText ) {
			var text;
			var type = 'ok';
			if ( errorText ) {
				text = errorText;
				type = 'error';
			} else if ( failed.length ) {
				text = ( tsosk.i18n.um_install_all_partial || 'Installed: %1$d. Failed: %2$s' )
					.replace( '%1$d', String( done.length ) )
					.replace( '%2$s', failed.map( function ( f ) { return f.name + ( f.error ? ' (' + f.error + ')' : '' ); } ).join( '; ' ) );
				type = 'error';
			} else if ( done.length ) {
				text = ( tsosk.i18n.um_install_all_done || 'Pending updates installed: %d.' ).replace( '%d', String( done.length ) );
			} else {
				text = tsosk.i18n.um_install_all_none || 'Nothing to install.';
			}
			showMsg( $msg, text, type );
			$btn.text( label );
			if ( ! errorText && ! failed.length ) {
				setTimeout( function () { window.location.reload(); }, 2000 );
			} else {
				$( '.tsosk-um-install-all, .tsosk-um-update-plugin, #tsosk-um-run-updates, #tsosk-um-install-translations' ).prop( 'disabled', false );
			}
		}

		function next( first ) {
			ajaxPost( {
				action : 'tsosk_um_install_next',
				data   : { nonce: nonce, first: first ? 1 : 0, skip: skip.join( ',' ) },
				success: function ( r ) {
					if ( ! r.success ) {
						finish( r.data || tsosk.i18n.error );
						return;
					}
					var item = r.data ? r.data.item : null;
					if ( item ) {
						skip.push( item.key );
						( item.ok ? done : failed ).push( item );
					}
					if ( item && r.data.remaining > 0 ) {
						showMsg( $msg, ( tsosk.i18n.um_install_all_progress || 'Installing… (%d done)' ).replace( '%d', String( done.length ) ), 'ok' );
						next( false );
					} else {
						finish( '' );
					}
				},
				error: function () {
					finish( tsosk.i18n.error );
				}
			} );
		}

		next( true );
	} );

	$( document ).on( 'click', '.tsosk-um-update-plugin', function () {
		var $btn  = $( this );
		var name  = String( $btn.data( 'name' ) || '' );
		var $msg  = $( '#tsosk-um-run-msg' );
		var label = $btn.text();
		var confirmMsg = ( tsosk.i18n.um_update_plugin_confirm || 'Update %s now?' ).replace( '%s', name );

		if ( ! window.confirm( confirmMsg ) ) {
			return;
		}

		$( '.tsosk-um-update-plugin' ).prop( 'disabled', true );
		$btn.text( tsosk.i18n.running );

		ajaxPost( {
			action : 'tsosk_um_update_plugin',
			data   : { nonce: $btn.data( 'nonce' ), plugin: $btn.data( 'plugin' ) },
			success: function ( r ) {
				if ( r.success ) {
					showMsg( $msg, ( r.data && r.data.message ) ? r.data.message : tsosk.i18n.done, 'ok' );
					setTimeout( function () { window.location.reload(); }, 1500 );
				} else {
					showMsg( $msg, r.data || tsosk.i18n.error, 'error' );
					$( '.tsosk-um-update-plugin' ).prop( 'disabled', false );
					$btn.text( label );
				}
			},
			error: function () {
				showMsg( $msg, tsosk.i18n.error, 'error' );
				$( '.tsosk-um-update-plugin' ).prop( 'disabled', false );
				$btn.text( label );
			}
		} );
	} );

	$( document ).on( 'click', '#tsosk-um-install-translations', function () {
		var $btn     = $( this );
		var nonce    = $btn.data( 'nonce' );
		var pending  = parseInt( $btn.data( 'pending' ), 10 ) || 0;
		var $msg     = $( '#tsosk-um-run-msg' );
		var label    = $btn.text();
		var confirmMsg = tsosk.i18n.um_install_translations_confirm;

		if ( pending > 0 && confirmMsg ) {
			confirmMsg = confirmMsg.replace( '%d', String( pending ) );
		}

		if ( ! window.confirm( confirmMsg || label ) ) {
			return;
		}

		$btn.prop( 'disabled', true );
		$( '#tsosk-um-run-updates' ).prop( 'disabled', true );
		$btn.text( tsosk.i18n.running );

		ajaxPost( {
			action : 'tsosk_um_install_translations',
			data   : { nonce: nonce },
			success: function ( r ) {
				if ( r.success ) {
					var text = ( r.data && r.data.message ) ? r.data.message : ( r.data || tsosk.i18n.done );
					showMsg( $msg, text, 'ok' );
					setTimeout( function () { window.location.reload(); }, 1800 );
				} else {
					showMsg( $msg, r.data || tsosk.i18n.error, 'error' );
					$btn.prop( 'disabled', false ).text( label );
					$( '#tsosk-um-run-updates' ).prop( 'disabled', false );
				}
			},
			error: function () {
				showMsg( $msg, tsosk.i18n.error, 'error' );
				$btn.prop( 'disabled', false ).text( label );
				$( '#tsosk-um-run-updates' ).prop( 'disabled', false );
			}
		} );
	} );

	$( document ).on( 'click', '#tsosk-um-save', function () {
		var $btn   = $( this );
		var nonce  = $btn.data( 'nonce' );
		var $msg   = $( '#tsosk-um-msg' );
		var preset = $( 'input[name="tsosk_um_preset"]:checked' ).val();
		var pluginRules = {};

		$( '.tsosk-um-plugin-row' ).each( function () {
			var file = $( this ).data( 'plugin' );
			if ( ! file ) {
				return;
			}
			pluginRules[ file ] = {
				block: $( this ).find( '.tsosk-um-plugin-block' ).is( ':checked' ) ? 1 : 0
			};
		} );

		var data = {
			nonce              : nonce,
			preset             : preset,
			plugin_rules       : JSON.stringify( pluginRules ),
			email_core_major   : $( '#tsosk-um-email-core-major' ).is( ':checked' ) ? 1 : 0,
			email_core_minor   : $( '#tsosk-um-email-core-minor' ).is( ':checked' ) ? 1 : 0,
			email_core_fail    : $( '#tsosk-um-email-core-fail' ).is( ':checked' ) ? 1 : 0,
			email_manual_core  : $( '#tsosk-um-email-manual-core' ).is( ':checked' ) ? 1 : 0,
			email_plugin       : $( '#tsosk-um-email-plugin' ).is( ':checked' ) ? 1 : 0,
			email_theme        : $( '#tsosk-um-email-theme' ).is( ':checked' ) ? 1 : 0
		};

		if ( preset === 'custom' ) {
			data.block_core         = $( '#tsosk-um-block-core' ).is( ':checked' ) ? 1 : 0;
			data.block_plugins      = $( '#tsosk-um-block-plugins' ).is( ':checked' ) ? 1 : 0;
			data.block_themes       = $( '#tsosk-um-block-themes' ).is( ':checked' ) ? 1 : 0;
			data.block_translations = $( '#tsosk-um-block-translations' ).is( ':checked' ) ? 1 : 0;
			data.hide_update_nags   = $( '#tsosk-um-hide-nags' ).is( ':checked' ) ? 1 : 0;
		}

		$btn.prop( 'disabled', true );
		ajaxPost( {
			action : 'tsosk_um_save',
			data   : data,
			success: function ( r ) {
				if ( r.success ) {
					showMsg( $msg, tsosk.i18n.done, 'ok' );
				} else {
					showMsg( $msg, r.data || tsosk.i18n.error, 'error' );
				}
				$btn.prop( 'disabled', false );
			},
			error: function () {
				showMsg( $msg, tsosk.i18n.error, 'error' );
				$btn.prop( 'disabled', false );
			}
		} );
	} );

	// ── Hooks Inspector: live search ────────────────────────────────────────

	$( document ).on( 'input', '#tsosk-hooks-search', function () {
		var q = $( this ).val().toLowerCase();
		$( '#tsosk-hooks-table tbody tr' ).each( function () {
			var hook = $( this ).find( 'td:first' ).text().toLowerCase();
			$( this ).toggle( hook.indexOf( q ) !== -1 );
		} );
	} );

	// ── Rewrite Rules ──────────────────────────────────────────────────────

	// Soft and hard flush share one handler (the buttons carry data-hard). Both are locked while a
	// flush runs, so a soft and a hard flush can never overlap.
	$( document ).on( 'click', '#tsosk-flush-soft, #tsosk-flush-hard', function () {
		var $btn    = $( this );
		var $both   = $( '#tsosk-flush-soft, #tsosk-flush-hard' );
		var $msg    = $( '#tsosk-rewrite-msg' );
		var hard    = 1 === parseInt( $btn.data( 'hard' ), 10 ) ? 1 : 0;

		function unlock() {
			$both.prop( 'disabled', false );
			$( '#tsosk-flush-soft' ).text( tsosk.i18n.soft_flush );
			$( '#tsosk-flush-hard' ).text( tsosk.i18n.hard_flush );
		}

		$both.prop( 'disabled', true );
		$btn.text( tsosk.i18n.running );

		ajaxPost( {
			action : 'tsosk_flush_rewrite',
			data   : { nonce: $btn.data( 'nonce' ), hard: hard },
			success: function ( r ) {
				var d    = r.data;
				var text = ( d && 'object' === typeof d ) ? d.message : d;
				if ( r.success && d && d.warning ) {
					// Partly done (e.g. .htaccess not writable): keep the warning on screen longer.
					showMsg( $msg, text || tsosk.i18n.done, 'warn', 15000 );
				} else {
					showMsg( $msg, text || ( r.success ? tsosk.i18n.done : tsosk.i18n.error ), r.success ? 'ok' : 'error', r.success ? 6000 : 0 );
				}
				unlock();
			},
			error: function () {
				showMsg( $msg, tsosk.i18n.error, 'error' );
				unlock();
			}
		} );
	} );

	// Rewrite rules: live filter.
	$( document ).on( 'input', '#tsosk-rewrite-search', function () {
		var q = $( this ).val().toLowerCase();
		$( '#tsosk-rewrite-table tbody tr' ).each( function () {
			var rule  = $( this ).find( 'td:first' ).text().toLowerCase();
			var query = $( this ).find( 'td:last' ).text().toLowerCase();
			$( this ).toggle( rule.indexOf( q ) !== -1 || query.indexOf( q ) !== -1 );
		} );
	} );

	// ── Maintenance Mode ───────────────────────────────────────────────────

	var tsoskMaintLogoFrame = null;

	function tsoskMaintLogoPreviewUrl( attachment ) {
		if ( attachment.sizes && attachment.sizes.large ) {
			return attachment.sizes.large.url;
		}
		if ( attachment.sizes && attachment.sizes.medium ) {
			return attachment.sizes.medium.url;
		}
		return attachment.url || '';
	}

	$( document ).on( 'click', '#tsosk-m-logo-select', function ( e ) {
		e.preventDefault();
		if ( typeof wp === 'undefined' || ! wp.media ) {
			return;
		}
		if ( tsoskMaintLogoFrame ) {
			tsoskMaintLogoFrame.open();
			return;
		}
		tsoskMaintLogoFrame = wp.media( {
			title   : tsosk.i18n.maint_select_logo || 'Select logo',
			button  : { text: tsosk.i18n.maint_use_logo || 'Use this image' },
			library : { type: 'image' },
			multiple: false
		} );
		tsoskMaintLogoFrame.on( 'select', function () {
			var attachment = tsoskMaintLogoFrame.state().get( 'selection' ).first().toJSON();
			var url        = tsoskMaintLogoPreviewUrl( attachment );
			$( '#tsosk-m-logo-id' ).val( attachment.id || 0 );
			$( '#tsosk-m-logo-preview' ).addClass( 'has-logo' ).html(
				url ? $( '<img>', { src: url, alt: '' } ) : ''
			);
			$( '#tsosk-m-logo-remove' ).prop( 'disabled', ! attachment.id );
		} );
		tsoskMaintLogoFrame.open();
	} );

	$( document ).on( 'click', '#tsosk-m-logo-remove', function () {
		$( '#tsosk-m-logo-id' ).val( '0' );
		$( '#tsosk-m-logo-preview' ).removeClass( 'has-logo' ).empty();
		$( this ).prop( 'disabled', true );
	} );

	$( document ).on( 'click', '#tsosk-maintenance-toggle', function () {
		var $btn  = $( this );
		var nonce = $btn.data( 'nonce' );
		var $msg  = $( '#tsosk-maintenance-toggle-msg' );

		$btn.prop( 'disabled', true );

		ajaxPost( {
			action : 'tsosk_maintenance_toggle',
			data   : { nonce: nonce },
			success: function ( r ) {
				if ( r.success ) {
					showMsg( $msg, r.data.message || tsosk.i18n.done, 'ok' );
					// Update status badge text.
					var $badge = $( '#tsosk-maintenance-status' );
					if ( r.data.enabled ) {
						$badge.text( tsosk.i18n.on ).removeClass( 'tsosk-badge-ok' ).addClass( 'tsosk-badge-warn' );
						$btn.text( tsosk.i18n.disable );
					} else {
						$badge.text( tsosk.i18n.off ).removeClass( 'tsosk-badge-warn' ).addClass( 'tsosk-badge-ok' );
						$btn.text( tsosk.i18n.enable );
					}
				} else {
					showMsg( $msg, r.data || tsosk.i18n.error, 'error' );
				}
				$btn.prop( 'disabled', false );
			},
			error: function () {
				showMsg( $msg, tsosk.i18n.error, 'error' );
				$btn.prop( 'disabled', false );
			}
		} );
	} );

	$( document ).on( 'click', '#tsosk-maintenance-save', function () {
		var $btn    = $( this );
		var nonce   = $btn.data( 'nonce' );
		var $msg    = $( '#tsosk-maintenance-save-msg' );
		var message = $( '#tsosk-m-message' ).val();
		var ips     = $( '#tsosk-m-ips' ).val();

		$btn.prop( 'disabled', true );

		ajaxPost( {
			action : 'tsosk_maintenance_save',
			data   : {
				nonce        : nonce,
				message      : message,
				page_title   : $( '#tsosk-m-page-title' ).val() || '',
				whitelist_ips: ips,
				logo_id      : $( '#tsosk-m-logo-id' ).val() || 0
			},
			success: function ( r ) {
				if ( r.success ) {
					showMsg( $msg, tsosk.i18n.done, 'ok' );
				} else {
					showMsg( $msg, r.data || tsosk.i18n.error, 'error' );
				}
				$btn.prop( 'disabled', false );
			},
			error: function () {
				showMsg( $msg, tsosk.i18n.error, 'error' );
				$btn.prop( 'disabled', false );
			}
		} );
	} );

	$( document ).on( 'click', '#tsosk-maintenance-preview', function () {
		var nonce   = $( this ).data( 'nonce' );
		var message = $( '#tsosk-m-message' ).val();
		var $form   = $( '<form>', {
			method : 'POST',
			action : tsosk.ajax_url,
			target : 'tsosk_maintenance_preview'
		} );

		$form.append( $( '<input>', { type: 'hidden', name: 'action', value: 'tsosk_maintenance_preview' } ) );
		$form.append( $( '<input>', { type: 'hidden', name: 'nonce', value: nonce } ) );
		$form.append( $( '<input>', { type: 'hidden', name: 'logo_id', value: $( '#tsosk-m-logo-id' ).val() || 0 } ) );
		$form.append( $( '<input>', { type: 'hidden', name: 'page_title', value: $( '#tsosk-m-page-title' ).val() || '' } ) );
		$form.append( $( '<textarea>', { name: 'message' } ).css( 'display', 'none' ).val( message ) );
		window.open( '', 'tsosk_maintenance_preview' );
		$form.appendTo( 'body' ).submit().remove();
	} );

	// ── Plugin Conflict Sandbox ─────────────────────────────────────────────

	// Helper buttons: Select All.
	$( document ).on( 'click', '#tsosk-sb-select-all', function () {
		$( '.tsosk-sandbox-cb' ).prop( 'checked', true );
	} );

	// Helper buttons: Select Normally Active.
	$( document ).on( 'click', '#tsosk-sb-select-active', function () {
		$( '.tsosk-sandbox-cb' ).each( function () {
			var $cb = $( this );
			var $row = $cb.closest( '.tsosk-plugin-row' );
			$cb.prop( 'checked', $row.data( 'normal' ) === 1 || $row.data( 'normal' ) === '1' || $row.data( 'normal' ) === true );
		} );
	} );

	// Helper buttons: Deselect All.
	$( document ).on( 'click', '#tsosk-sb-select-none', function () {
		$( '.tsosk-sandbox-cb' ).prop( 'checked', false );
	} );

	$( document ).on( 'click', '#tsosk-sandbox-apply', function () {
		if ( ! window.confirm( tsosk.i18n.confirm_sandbox ) ) {
			return;
		}
		var $btn    = $( this );
		var nonce   = $btn.data( 'nonce' );
		var $msg    = $( '#tsosk-sandbox-msg' );
		var plugins = [];

		$( '.tsosk-sandbox-cb:checked' ).each( function () {
			plugins.push( $( this ).val() );
		} );

		$btn.prop( 'disabled', true ).text( tsosk.i18n.running );

		ajaxPost( {
			action : 'tsosk_sandbox_apply',
			data   : { nonce: nonce, plugins: plugins },
			success: function ( r ) {
				if ( r.success ) {
					showMsg( $msg, r.data || tsosk.i18n.done, 'ok' );
					// Reload after a short delay so the sandbox takes effect.
					setTimeout( function () {
						window.location.reload();
					}, 1200 );
				} else {
					showMsg( $msg, r.data || tsosk.i18n.error, 'error' );
					$btn.prop( 'disabled', false ).text( tsosk.i18n.apply_sandbox );
				}
			},
			error: function () {
				showMsg( $msg, tsosk.i18n.error, 'error' );
				$btn.prop( 'disabled', false ).text( tsosk.i18n.apply_sandbox );
			}
		} );
	} );

	$( document ).on( 'click', '#tsosk-sandbox-reset', function () {
		var $btn  = $( this );
		var nonce = $btn.data( 'nonce' );
		var $msg  = $( '#tsosk-sandbox-msg' );

		$btn.prop( 'disabled', true ).text( tsosk.i18n.running );

		ajaxPost( {
			action : 'tsosk_sandbox_reset',
			data   : { nonce: nonce },
			success: function ( r ) {
				if ( r.success ) {
					showMsg( $msg, r.data || tsosk.i18n.done, 'ok' );
					setTimeout( function () {
						window.location.reload();
					}, 1200 );
				} else {
					showMsg( $msg, r.data || tsosk.i18n.error, 'error' );
					$btn.prop( 'disabled', false ).text( tsosk.i18n.reset_sandbox );
				}
			},
			error: function () {
				showMsg( $msg, tsosk.i18n.error, 'error' );
				$btn.prop( 'disabled', false ).text( tsosk.i18n.reset_sandbox );
			}
		} );
	} );

	// ── Plugin Sandbox: automatic bisection ─────────────────────────────────

	function tsoskBisectPost( action, extra, $btn, $msg, origText ) {
		var data = { nonce: $btn.data( 'nonce' ) };
		if ( extra ) {
			$.extend( data, extra );
		}
		$btn.prop( 'disabled', true ).text( tsosk.i18n.running );

		ajaxPost( {
			action : action,
			data   : data,
			success: function ( r ) {
				if ( r.success ) {
					showMsg( $msg, r.data || tsosk.i18n.done, 'ok' );
					setTimeout( function () {
						window.location.reload();
					}, 1200 );
				} else {
					showMsg( $msg, r.data || tsosk.i18n.error, 'error' );
					$btn.prop( 'disabled', false ).text( origText );
				}
			},
			error: function () {
				showMsg( $msg, tsosk.i18n.error, 'error' );
				$btn.prop( 'disabled', false ).text( origText );
			}
		} );
	}

	$( document ).on( 'click', '#tsosk-bisect-start', function () {
		if ( ! window.confirm( tsosk.i18n.confirm_bisect_start ) ) {
			return;
		}
		var $btn = $( this );
		tsoskBisectPost( 'tsosk_sandbox_bisect_start', null, $btn, $( '#tsosk-bisect-start-msg' ), $btn.text() );
	} );

	$( document ).on( 'click', '#tsosk-bisect-yes', function () {
		var $btn = $( this );
		tsoskBisectPost( 'tsosk_sandbox_bisect_vote', { reproduced: 'yes' }, $btn, $( '#tsosk-bisect-msg' ), $btn.text() );
	} );

	$( document ).on( 'click', '#tsosk-bisect-no', function () {
		var $btn = $( this );
		tsoskBisectPost( 'tsosk_sandbox_bisect_vote', { reproduced: 'no' }, $btn, $( '#tsosk-bisect-msg' ), $btn.text() );
	} );

	$( document ).on( 'click', '#tsosk-bisect-cancel', function () {
		var $btn = $( this );
		tsoskBisectPost( 'tsosk_sandbox_bisect_cancel', null, $btn, $( '#tsosk-bisect-msg' ), $btn.text() );
	} );

	// ── Redirects ──────────────────────────────────────────────────────────

	var TSOSK_404_PREFILL_KEY = 'tsosk_404_prefill_queue';

	function tsosk404GetPrefillQueue() {
		try {
			var raw = sessionStorage.getItem( TSOSK_404_PREFILL_KEY );
			var arr = raw ? JSON.parse( raw ) : [];
			return Array.isArray( arr ) ? arr.filter( Boolean ) : [];
		} catch ( e ) {
			return [];
		}
	}

	// Source currently shown in the form that came from the queue ('' when typed/edited by hand).
	var tsosk404QueueCurrent = '';

	function tsosk404RefreshQueueUi() {
		var active = tsosk404GetPrefillQueue().length > 0 || '' !== tsosk404QueueCurrent;
		$( '#tsosk-redirect-skip, #tsosk-redirect-cancel-queue' ).prop( 'hidden', ! active );
	}

	function tsosk404SetPrefillQueue( sources ) {
		try {
			sessionStorage.setItem( TSOSK_404_PREFILL_KEY, JSON.stringify( sources || [] ) );
		} catch ( err ) {
			// sessionStorage unavailable — queue falls back to single-row prefill.
		}
		tsosk404RefreshQueueUi();
	}

	function tsosk404UncheckSource( source ) {
		$( '#tsosk-404-table .tsosk-404-select' ).each( function () {
			if ( String( $( this ).data( 'source' ) || '' ) === source ) {
				$( this ).prop( 'checked', false );
			}
		} );
		var $rows     = $( '#tsosk-404-table .tsosk-404-select' );
		var $checked  = $rows.filter( ':checked' );
		$( '#tsosk-404-select-all' ).prop( 'checked', $rows.length > 0 && $checked.length === $rows.length );
	}

	// The redirect form lives in the "Redirects" sub-tab, but the buttons that fill it live in
	// the "404 Monitor" sub-tab: switch tab first, otherwise the form is hidden and nothing seems to happen.
	function tsosk404FocusRedirectForm() {
		rdShowTab( 'rules' );
		var $source = $( '#tsosk-redirect-source' );
		$( '#tsosk-redirect-target' ).focus();
		if ( $source.length && $source.is( ':visible' ) ) {
			$( 'html, body' ).animate( { scrollTop: $source.offset().top - 80 }, 200 );
		}
	}

	function tsosk404PrefillFromQueue( introTotal, silent ) {
		var queue = tsosk404GetPrefillQueue();
		if ( ! queue.length ) {
			return false;
		}
		var source = queue.shift();
		tsosk404SetPrefillQueue( queue );
		if ( ! source ) {
			return tsosk404PrefillFromQueue( introTotal, silent );
		}
		// Do not clear the remaining queue when resetting fields.
		resetRedirectForm( false );
		tsosk404QueueCurrent = source;
		tsosk404RefreshQueueUi();
		$( '#tsosk-redirect-source' ).val( source );
		tsosk404UncheckSource( source );
		var remaining = queue.length;
		var $msg      = $( '#tsosk-redirect-msg' );
		if ( silent ) {
			// The caller shows its own message (skip / duplicate).
		} else if ( introTotal && introTotal > 1 && tsosk.i18n.redirects_prefill_queue ) {
			showMsg( $msg, tsosk.i18n.redirects_prefill_queue.replace( '%1$d', String( introTotal ) ), 'ok' );
		} else if ( remaining > 0 && tsosk.i18n.redirects_prefill_next ) {
			showMsg( $msg, tsosk.i18n.redirects_prefill_next.replace( '%1$d', String( remaining ) ), 'ok' );
		}
		tsosk404FocusRedirectForm();
		return true;
	}

	function resetRedirectForm( clearQueue ) {
		if ( false !== clearQueue ) {
			tsosk404SetPrefillQueue( [] );
		}
		tsosk404QueueCurrent = '';
		tsosk404RefreshQueueUi();
		$( '#tsosk-redirect-id' ).val( '' );
		$( '#tsosk-redirect-source' ).val( '' );
		$( '#tsosk-redirect-target' ).val( '' );
		$( '#tsosk-redirect-match-type' ).val( 'exact' );
		$( '#tsosk-redirect-status' ).val( '301' );
		$( '#tsosk-redirect-enabled' ).prop( 'checked', true );
		$( '#tsosk-redirect-save' ).text( tsosk.i18n.save_redirect );
	}

	// "Clear Form" only empties the fields; the pending queue is kept (use Skip / Cancel queue).
	$( document ).on( 'click', '#tsosk-redirect-reset-form', function () {
		resetRedirectForm( false );
	} );

	$( document ).on( 'click', '#tsosk-redirect-skip', function () {
		var $msg = $( '#tsosk-redirect-msg' );
		if ( tsosk404PrefillFromQueue( 0, true ) ) {
			var remaining = tsosk404GetPrefillQueue().length;
			showMsg( $msg, ( tsosk.i18n.redirects_skipped_next || '' ).replace( '%1$d', String( remaining ) ), 'ok' );
			return;
		}
		resetRedirectForm( false );
		showMsg( $msg, tsosk.i18n.redirects_queue_done || tsosk.i18n.done, 'ok' );
	} );

	$( document ).on( 'click', '#tsosk-redirect-cancel-queue', function () {
		resetRedirectForm( true );
		showMsg( $( '#tsosk-redirect-msg' ), tsosk.i18n.redirects_queue_cancelled || tsosk.i18n.done, 'ok' );
	} );

	$( function () {
		tsosk404RefreshQueueUi();
	} );

	$( document ).on( 'click', '.tsosk-redirect-edit', function () {
		var $btn = $( this );
		$( '#tsosk-redirect-id' ).val( $btn.data( 'id' ) );
		$( '#tsosk-redirect-source' ).val( $btn.data( 'source' ) );
		$( '#tsosk-redirect-target' ).val( $btn.data( 'target' ) );
		$( '#tsosk-redirect-match-type' ).val( $btn.data( 'match-type' ) || 'exact' );
		$( '#tsosk-redirect-status' ).val( String( $btn.data( 'status' ) ) );
		$( '#tsosk-redirect-enabled' ).prop( 'checked', $btn.data( 'enabled' ) === 1 || $btn.data( 'enabled' ) === '1' );
		$( '#tsosk-redirect-save' ).text( tsosk.i18n.update_redirect );
		$( 'html, body' ).animate( { scrollTop: $( '#tsosk-redirect-source' ).offset().top - 80 }, 200 );
	} );

	$( document ).on( 'click', '#tsosk-redirect-save', function () {
		var $btn = $( this );
		var $msg = $( '#tsosk-redirect-msg' );

		$btn.prop( 'disabled', true ).text( tsosk.i18n.running );

		ajaxPost( {
			action : 'tsosk_redirect_save',
			data   : {
				nonce      : $btn.data( 'nonce' ),
				redirect_id: $( '#tsosk-redirect-id' ).val(),
				source     : $( '#tsosk-redirect-source' ).val(),
				target     : $( '#tsosk-redirect-target' ).val(),
				match_type : $( '#tsosk-redirect-match-type' ).val(),
				status     : $( '#tsosk-redirect-status' ).val(),
				enabled    : $( '#tsosk-redirect-enabled' ).prop( 'checked' ) ? 1 : 0
			},
			success: function ( r ) {
				if ( r.success ) {
					showMsg( $msg, ( r.data && r.data.message ) || tsosk.i18n.done, 'ok' );
					if ( tsosk404GetPrefillQueue().length ) {
						tsosk404PrefillFromQueue( 0 );
						$btn.prop( 'disabled', false ).text( tsosk.i18n.save_redirect );
						return;
					}
					tsosk404SetPrefillQueue( [] );
					setTimeout( function () {
						window.location.reload();
					}, 700 );
				} else {
					var errData = r.data;
					var isObj   = errData && 'object' === typeof errData;
					var errText = isObj ? errData.message : errData;
					// A queued URL that already has a rule must not block the rest of the batch.
					if ( isObj && 'duplicate' === errData.code && '' !== tsosk404QueueCurrent && ! $( '#tsosk-redirect-id' ).val() && $( '#tsosk-redirect-source' ).val() === tsosk404QueueCurrent ) {
						var dupSource = tsosk404QueueCurrent;
						tsosk404UncheckSource( dupSource );
						if ( tsosk404PrefillFromQueue( 0, true ) ) {
							showMsg( $msg, ( tsosk.i18n.redirects_dup_skipped || '' ).replace( '%1$s', dupSource ).replace( '%2$d', String( tsosk404GetPrefillQueue().length ) ), 'ok' );
						} else {
							resetRedirectForm( false );
							showMsg( $msg, ( tsosk.i18n.redirects_dup_skipped_last || '' ).replace( '%1$s', dupSource ), 'ok' );
						}
						$btn.prop( 'disabled', false ).text( tsosk.i18n.save_redirect );
						return;
					}
					showMsg( $msg, errText || tsosk.i18n.error, 'error' );
					$btn.prop( 'disabled', false ).text( tsosk.i18n.save_redirect );
				}
			},
			error: function () {
				showMsg( $msg, tsosk.i18n.error, 'error' );
				$btn.prop( 'disabled', false ).text( tsosk.i18n.save_redirect );
			}
		} );
	} );

	$( document ).on( 'click', '.tsosk-redirect-toggle', function () {
		var $btn = $( this );
		var $msg = $( '#tsosk-redirect-msg' );

		$btn.prop( 'disabled', true );

		ajaxPost( {
			action : 'tsosk_redirect_toggle',
			data   : { nonce: $btn.data( 'nonce' ), redirect_id: $btn.data( 'id' ) },
			success: function ( r ) {
				if ( r.success ) {
					showMsg( $msg, ( r.data && r.data.message ) || tsosk.i18n.done, 'ok' );
					setTimeout( function () {
						window.location.reload();
					}, 700 );
				} else {
					showMsg( $msg, r.data || tsosk.i18n.error, 'error' );
					$btn.prop( 'disabled', false );
				}
			},
			error: function () {
				showMsg( $msg, tsosk.i18n.error, 'error' );
				$btn.prop( 'disabled', false );
			}
		} );
	} );

	$( document ).on( 'click', '.tsosk-redirect-delete', function () {
		if ( ! window.confirm( tsosk.i18n.confirm_delete ) ) {
			return;
		}
		var $btn = $( this );
		var $msg = $( '#tsosk-redirect-msg' );

		$btn.prop( 'disabled', true );

		ajaxPost( {
			action : 'tsosk_redirect_delete',
			data   : { nonce: $btn.data( 'nonce' ), redirect_id: $btn.data( 'id' ) },
			success: function ( r ) {
				if ( r.success ) {
					showMsg( $msg, ( r.data && r.data.message ) || tsosk.i18n.done, 'ok' );
					setTimeout( function () {
						window.location.reload();
					}, 700 );
				} else {
					showMsg( $msg, r.data || tsosk.i18n.error, 'error' );
					$btn.prop( 'disabled', false );
				}
			},
			error: function () {
				showMsg( $msg, tsosk.i18n.error, 'error' );
				$btn.prop( 'disabled', false );
			}
		} );
	} );

	// ── Redirect Rules list: filter, sort, select, bulk actions, reorder, CSV ──

	// 404 Monitor: click a header to sort the table (URL, visits, last visit, referrer, IP, action).
	function tsosk404Sort( $th ) {
		var col     = String( $th.data( 'sort' ) );
		var numeric = ( 'hits' === col || 'last' === col || 'covered' === col );
		var current = $th.hasClass( 'tsosk-sort-asc' ) ? 'asc' : ( $th.hasClass( 'tsosk-sort-desc' ) ? 'desc' : '' );
		var dir;
		if ( ! current ) {
			dir = ( 'hits' === col || 'last' === col ) ? 'desc' : 'asc'; // Most visits / most recent first.
		} else {
			dir = 'asc' === current ? 'desc' : 'asc';
		}
		$( '#tsosk-404-table th.tsosk-th-sortable' ).removeClass( 'tsosk-sort-asc tsosk-sort-desc' ).attr( 'aria-sort', 'none' );
		$th.addClass( 'asc' === dir ? 'tsosk-sort-asc' : 'tsosk-sort-desc' ).attr( 'aria-sort', 'asc' === dir ? 'ascending' : 'descending' );

		var value = function ( tr ) {
			var $tr = $( tr );
			switch ( col ) {
				case 'url':
					return String( $tr.find( '.tsosk-404-select' ).data( 'source' ) || '' ).toLowerCase();
				case 'hits':
					return parseInt( $tr.attr( 'data-hits' ), 10 ) || 0;
				case 'last':
					return parseInt( $tr.attr( 'data-last' ), 10 ) || 0;
				case 'covered':
					return parseInt( $tr.attr( 'data-covered' ), 10 ) || 0;
				case 'ref':
					return $.trim( $tr.find( '.tsosk-404-col-ref' ).text() ).toLowerCase();
				case 'ip':
					return $.trim( $tr.find( '.tsosk-404-col-ip' ).text() ).toLowerCase();
				default:
					return '';
			}
		};
		var $body = $( '#tsosk-404-table tbody' );
		var rows  = $body.children( 'tr' ).get();
		rows.sort( function ( a, b ) {
			var va = value( a );
			var vb = value( b );
			var diff = numeric ? va - vb : String( va ).localeCompare( String( vb ), undefined, { numeric: true } );
			if ( 'desc' === dir ) {
				diff = -diff;
			}
			return diff || ( ( parseInt( $( a ).attr( 'data-index' ), 10 ) || 0 ) - ( parseInt( $( b ).attr( 'data-index' ), 10 ) || 0 ) );
		} );
		$.each( rows, function ( i, row ) {
			$body.append( row );
		} );
	}
	$( document ).on( 'click', '#tsosk-404-table th.tsosk-th-sortable', function () {
		tsosk404Sort( $( this ) );
	} );
	$( document ).on( 'keydown', '#tsosk-404-table th.tsosk-th-sortable', function ( e ) {
		if ( 'Enter' === e.key || ' ' === e.key ) {
			e.preventDefault();
			tsosk404Sort( $( this ) );
		}
	} );

	// 404 Monitor: only rows not hidden by the live filter count for selection.
	function tsosk404Boxes() {
		return $( '#tsosk-404-table tbody tr' ).not( '.tsosk-404-hidden' ).find( '.tsosk-404-select' );
	}

	function tsosk404UpdateCount() {
		var $count = $( '#tsosk-404-count' );
		if ( ! $count.length ) {
			return;
		}
		var total = $( '#tsosk-404-table tbody tr' ).length;
		var shown = $( '#tsosk-404-table tbody tr' ).not( '.tsosk-404-hidden' ).length;
		var text  = shown ? String( $count.data( 'template' ) ) : String( $count.data( 'empty' ) );
		$count.text( text.replace( '{shown}', shown ).replace( '{total}', total ) );
	}

	$( document ).on( 'input search', '#tsosk-404-search', function () {
		var q = String( $( this ).val() || '' ).trim().toLowerCase();
		$( '#tsosk-404-table tbody tr' ).each( function () {
			var $tr   = $( this );
			var match = ! q || $tr.text().toLowerCase().indexOf( q ) !== -1 || String( $tr.find( '.tsosk-404-select' ).data( 'source' ) || '' ).toLowerCase().indexOf( q ) !== -1;
			$tr.toggleClass( 'tsosk-404-hidden', ! match );
			if ( ! match ) {
				// Never leave hidden rows selected: bulk actions must only touch what is visible.
				$tr.find( '.tsosk-404-select' ).prop( 'checked', false );
			}
		} );
		tsosk404UpdateCount();
		tsosk404SyncSelectAll();
	} );
	$( tsosk404UpdateCount );

	function tsosk404SyncSelectAll() {
		var $rows    = tsosk404Boxes();
		var $checked = $rows.filter( ':checked' );
		$( '#tsosk-404-select-all' ).prop( 'checked', $rows.length > 0 && $checked.length === $rows.length );
	}

	function tsoskVisibleRuleBoxes() {
		return $( '#tsosk-redirects-table tbody tr' ).not( '.tsosk-row-hidden' ).find( '.tsosk-redirect-select' );
	}

	function tsoskRulesCompare( sort ) {
		var num = function ( el, key ) {
			return parseInt( $( el ).attr( 'data-' + key ), 10 ) || 0;
		};
		return function ( a, b ) {
			var diff = 0;
			switch ( sort ) {
				case 'hits_desc':
					diff = num( b, 'hits' ) - num( a, 'hits' );
					break;
				case 'hits_asc':
					diff = num( a, 'hits' ) - num( b, 'hits' );
					break;
				case 'last_desc':
					diff = num( b, 'last-hit' ) - num( a, 'last-hit' );
					break;
				case 'last_asc':
					diff = num( a, 'last-hit' ) - num( b, 'last-hit' );
					break;
				case 'source_az':
					diff = String( $( a ).attr( 'data-source' ) ).localeCompare( String( $( b ).attr( 'data-source' ) ) );
					break;
				default:
					break;
			}
			// Ties (and the default order) keep the real evaluation order.
			return diff || ( num( a, 'index' ) - num( b, 'index' ) );
		};
	}

	function tsoskRuleMatchesFilter( $row, filter ) {
		var status = parseInt( $row.attr( 'data-status' ), 10 ) || 0;
		switch ( filter ) {
			case 'enabled':
				return '1' === String( $row.attr( 'data-enabled' ) );
			case 'disabled':
				return '1' !== String( $row.attr( 'data-enabled' ) );
			case 'gone':
				return 410 === status || 451 === status;
			case 'redirect':
				return status >= 300 && status < 400;
			case 'pattern':
				return 'exact' !== String( $row.attr( 'data-match' ) );
			default:
				return true;
		}
	}

	function tsoskRulesApply() {
		var $table = $( '#tsosk-redirects-table' );
		if ( ! $table.length ) {
			return;
		}
		var query  = String( $( '#tsosk-redirect-search' ).val() || '' ).trim().toLowerCase();
		var filter = String( $( '#tsosk-redirect-filter' ).val() || 'all' );
		var sort   = String( $( '#tsosk-redirect-sort' ).val() || 'default' );
		var $body  = $table.children( 'tbody' );
		var rows   = $body.children( 'tr' ).get();

		rows.sort( tsoskRulesCompare( sort ) );
		$.each( rows, function ( i, row ) {
			$body.append( row );
		} );

		var shown = 0;
		$( rows ).each( function () {
			var $row = $( this );
			var hay  = String( $row.attr( 'data-search' ) || '' ).toLowerCase();
			var ok   = ( '' === query || -1 !== hay.indexOf( query ) ) && tsoskRuleMatchesFilter( $row, filter );
			$row.toggleClass( 'tsosk-row-hidden', ! ok );
			if ( ok ) {
				shown++;
			} else {
				// A hidden row must never stay selected: a bulk action would hit it unseen.
				$row.find( '.tsosk-redirect-select' ).prop( 'checked', false );
			}
		} );

		var viewActive = 'default' !== sort || '' !== query || 'all' !== filter;
		$table.toggleClass( 'tsosk-rules-view-active', viewActive );
		$( '#tsosk-redirect-no-match' ).prop( 'hidden', shown > 0 || ! rows.length );
		if ( tsosk.i18n.redirects_showing ) {
			$( '#tsosk-redirect-count' ).text( tsosk.i18n.redirects_showing.replace( '%1$d', String( shown ) ).replace( '%2$d', String( rows.length ) ) );
		}
		tsosk404SyncRuleSelectAll();
	}

	$( document ).on( 'input change', '#tsosk-redirect-search, #tsosk-redirect-filter, #tsosk-redirect-sort', tsoskRulesApply );

	$( function () {
		tsoskRulesApply();
	} );

	$( document ).on( 'click', '#tsosk-redirect-select-visible', function () {
		tsoskVisibleRuleBoxes().prop( 'checked', true );
		tsosk404SyncRuleSelectAll();
	} );

	$( document ).on( 'click', '#tsosk-redirect-select-none', function () {
		$( '#tsosk-redirects-table .tsosk-redirect-select' ).prop( 'checked', false );
		tsosk404SyncRuleSelectAll();
	} );

	$( document ).on( 'click', '#tsosk-404-select-all-btn', function () {
		tsosk404Boxes().prop( 'checked', true );
		tsosk404SyncSelectAll();
	} );

	$( document ).on( 'click', '#tsosk-404-select-none-btn', function () {
		tsosk404Boxes().prop( 'checked', false );
		tsosk404SyncSelectAll();
	} );

	// Rules with no traffic for N months (or never hit and older than N months).
	$( document ).on( 'click', '#tsosk-redirect-select-unused', function () {
		var months = parseInt( $( '#tsosk-redirect-unused-months' ).val(), 10 );
		if ( ! months || months < 1 ) {
			months = 6;
		}
		var cutoff = Math.floor( Date.now() / 1000 ) - months * 30 * 86400;
		var count  = 0;
		var $msg   = $( '#tsosk-redirect-bulk-msg' );
		$( '#tsosk-redirects-table .tsosk-redirect-select' ).prop( 'checked', false );
		tsoskVisibleRuleBoxes().each( function () {
			var $row    = $( this ).closest( 'tr' );
			var hits    = parseInt( $row.attr( 'data-hits' ), 10 ) || 0;
			var last    = parseInt( $row.attr( 'data-last-hit' ), 10 ) || 0;
			var created = parseInt( $row.attr( 'data-created' ), 10 ) || 0;
			var unused  = 0 === hits ? ( 0 === created || created < cutoff ) : ( last > 0 && last < cutoff );
			if ( unused ) {
				$( this ).prop( 'checked', true );
				count++;
			}
		} );
		tsosk404SyncRuleSelectAll();
		if ( count && tsosk.i18n.redirects_unused_selected ) {
			showMsg( $msg, tsosk.i18n.redirects_unused_selected.replace( '%1$d', String( count ) ).replace( '%2$d', String( months ) ), 'ok' );
		} else {
			showMsg( $msg, tsosk.i18n.redirects_unused_none || tsosk.i18n.done, 'ok' );
		}
	} );

	// Shift+click selects the whole range between two checkboxes (both tables).
	var tsoskLastClicked = {};
	$( document ).on( 'click', '#tsosk-redirects-table .tsosk-redirect-select, #tsosk-404-table .tsosk-404-select', function ( e ) {
		var is404 = $( this ).hasClass( 'tsosk-404-select' );
		var key   = is404 ? '404' : 'rules';
		var $all  = is404 ? tsosk404Boxes() : tsoskVisibleRuleBoxes();
		var idx   = $all.index( this );
		if ( e.shiftKey && undefined !== tsoskLastClicked[ key ] && tsoskLastClicked[ key ] < $all.length && idx > -1 ) {
			var from = Math.min( idx, tsoskLastClicked[ key ] );
			var to   = Math.max( idx, tsoskLastClicked[ key ] );
			$all.slice( from, to + 1 ).prop( 'checked', $( this ).prop( 'checked' ) );
		}
		tsoskLastClicked[ key ] = idx;
		if ( is404 ) {
			tsosk404SyncSelectAll();
		} else {
			tsosk404SyncRuleSelectAll();
		}
	} );

	function tsoskSelectedRuleIds() {
		var ids = [];
		$( '#tsosk-redirects-table .tsosk-redirect-select:checked' ).each( function () {
			var id = String( $( this ).data( 'id' ) || '' );
			if ( id ) {
				ids.push( id );
			}
		} );
		return ids;
	}

	$( document ).on( 'click', '.tsosk-redirect-bulk-toggle', function () {
		var $btn = $( this );
		var $msg = $( '#tsosk-redirect-bulk-msg' );
		var ids  = tsoskSelectedRuleIds();
		if ( ! ids.length ) {
			showMsg( $msg, tsosk.i18n.redirects_select_rules || tsosk.i18n.error, 'error' );
			return;
		}
		var originalText = $btn.text();
		$btn.prop( 'disabled', true ).text( tsosk.i18n.running );
		ajaxPost( {
			action : 'tsosk_redirect_bulk_toggle',
			data   : { nonce: $btn.data( 'nonce' ), ids: ids, enabled: 1 === parseInt( $btn.data( 'enabled' ), 10 ) ? 1 : 0 },
			success: function ( r ) {
				if ( r.success ) {
					showMsg( $msg, ( r.data && r.data.message ) || tsosk.i18n.done, 'ok' );
					setTimeout( function () {
						window.location.reload();
					}, 700 );
				} else {
					showMsg( $msg, r.data || tsosk.i18n.error, 'error' );
					$btn.prop( 'disabled', false ).text( originalText );
				}
			},
			error: function () {
				showMsg( $msg, tsosk.i18n.error, 'error' );
				$btn.prop( 'disabled', false ).text( originalText );
			}
		} );
	} );

	$( document ).on( 'click', '.tsosk-redirect-move-btn', function () {
		var $btn = $( this );
		var $msg = $( '#tsosk-redirect-bulk-msg' );
		$( '.tsosk-redirect-move-btn' ).prop( 'disabled', true );
		ajaxPost( {
			action : 'tsosk_redirect_move',
			data   : { nonce: $btn.data( 'nonce' ), redirect_id: $btn.data( 'id' ), direction: $btn.data( 'dir' ) },
			success: function ( r ) {
				if ( r.success ) {
					window.location.reload();
				} else {
					showMsg( $msg, r.data || tsosk.i18n.error, 'error' );
					$( '.tsosk-redirect-move-btn' ).prop( 'disabled', false );
				}
			},
			error: function () {
				showMsg( $msg, tsosk.i18n.error, 'error' );
				$( '.tsosk-redirect-move-btn' ).prop( 'disabled', false );
			}
		} );
	} );

	$( document ).on( 'click', '#tsosk-redirect-export', function () {
		var $btn = $( this );
		var $msg = $( '#tsosk-redirect-io-msg' );
		$btn.prop( 'disabled', true );
		ajaxPost( {
			action : 'tsosk_redirect_export',
			data   : { nonce: $btn.data( 'nonce' ) },
			success: function ( r ) {
				$btn.prop( 'disabled', false );
				if ( ! r.success || ! r.data || 'string' !== typeof r.data.csv ) {
					showMsg( $msg, ( 'string' === typeof r.data && r.data ) || tsosk.i18n.error, 'error' );
					return;
				}
				var blob = new window.Blob( [ '\ufeff' + r.data.csv ], { type: 'text/csv;charset=utf-8' } );
				var url  = window.URL.createObjectURL( blob );
				var a    = document.createElement( 'a' );
				a.href     = url;
				a.download = r.data.filename || 'tsosk-redirects.csv';
				document.body.appendChild( a );
				a.click();
				document.body.removeChild( a );
				setTimeout( function () {
					window.URL.revokeObjectURL( url );
				}, 1000 );
				showMsg( $msg, tsosk.i18n.redirects_export_done || tsosk.i18n.done, 'ok' );
			},
			error: function () {
				$btn.prop( 'disabled', false );
				showMsg( $msg, tsosk.i18n.error, 'error' );
			}
		} );
	} );

	$( document ).on( 'change', '#tsosk-redirect-import-file', function () {
		var file = this.files && this.files[ 0 ];
		if ( ! file || ! window.FileReader ) {
			return;
		}
		var reader = new window.FileReader();
		reader.onload = function () {
			$( '#tsosk-redirect-import-text' ).val( String( reader.result || '' ).replace( /^\ufeff/, '' ) );
		};
		reader.readAsText( file );
	} );

	$( document ).on( 'click', '#tsosk-redirect-import', function () {
		var $btn = $( this );
		var $msg = $( '#tsosk-redirect-io-msg' );
		var csv  = String( $( '#tsosk-redirect-import-text' ).val() || '' ).trim();
		if ( '' === csv ) {
			showMsg( $msg, tsosk.i18n.redirects_import_empty || tsosk.i18n.error, 'error' );
			return;
		}
		var originalText = $btn.text();
		$btn.prop( 'disabled', true ).text( tsosk.i18n.running );
		ajaxPost( {
			action : 'tsosk_redirect_import',
			data   : { nonce: $btn.data( 'nonce' ), csv: csv },
			success: function ( r ) {
				if ( r.success ) {
					showMsg( $msg, ( r.data && r.data.message ) || tsosk.i18n.done, 'ok' );
					if ( r.data && r.data.created ) {
						setTimeout( function () {
							window.location.reload();
						}, 1500 );
						return;
					}
				} else {
					showMsg( $msg, r.data || tsosk.i18n.error, 'error' );
				}
				$btn.prop( 'disabled', false ).text( originalText );
			},
			error: function () {
				showMsg( $msg, tsosk.i18n.error, 'error' );
				$btn.prop( 'disabled', false ).text( originalText );
			}
		} );
	} );

	// Redirect Rules list: select several rules and delete them in one go.
	function tsosk404SyncRuleSelectAll() {
		var $rows    = tsoskVisibleRuleBoxes();
		var $checked = $rows.filter( ':checked' );
		$( '#tsosk-redirect-select-all' ).prop( 'checked', $rows.length > 0 && $checked.length === $rows.length );
	}

	$( document ).on( 'change', '#tsosk-redirect-select-all', function () {
		tsoskVisibleRuleBoxes().prop( 'checked', $( this ).prop( 'checked' ) );
	} );

	$( document ).on( 'change', '#tsosk-redirects-table .tsosk-redirect-select', tsosk404SyncRuleSelectAll );

	$( document ).on( 'click', '#tsosk-redirect-delete-selected', function () {
		var $btn = $( this );
		var ids  = tsoskSelectedRuleIds();
		var $msg = $( '#tsosk-redirect-bulk-msg' );
		if ( ! ids.length ) {
			showMsg( $msg, tsosk.i18n.redirects_select_rules || tsosk.i18n.error, 'error' );
			return;
		}
		if ( tsosk.i18n.redirects_confirm_delete_selected && ! window.confirm( tsosk.i18n.redirects_confirm_delete_selected.replace( '%1$d', String( ids.length ) ) ) ) {
			return;
		}
		var originalText = $btn.text();
		$btn.prop( 'disabled', true ).text( tsosk.i18n.running );

		ajaxPost( {
			action : 'tsosk_redirect_delete_selected',
			data   : { nonce: $btn.data( 'nonce' ), ids: ids },
			success: function ( r ) {
				if ( r.success ) {
					showMsg( $msg, ( r.data && r.data.message ) || tsosk.i18n.done, 'ok' );
					setTimeout( function () {
						window.location.reload();
					}, 700 );
				} else {
					showMsg( $msg, r.data || tsosk.i18n.error, 'error' );
					$btn.prop( 'disabled', false ).text( originalText );
				}
			},
			error: function () {
				showMsg( $msg, tsosk.i18n.error, 'error' );
				$btn.prop( 'disabled', false ).text( originalText );
			}
		} );
	} );

	$( document ).on( 'click', '.tsosk-404-create-redirect', function () {
		resetRedirectForm();
		$( '#tsosk-redirect-source' ).val( $( this ).data( 'source' ) );
		tsosk404FocusRedirectForm();
	} );

	$( document ).on( 'change', '#tsosk-404-select-all', function () {
		tsosk404Boxes().prop( 'checked', $( this ).prop( 'checked' ) );
	} );

	$( document ).on( 'change', '#tsosk-404-table .tsosk-404-select', function () {
		var $rows    = tsosk404Boxes();
		var $checked = $rows.filter( ':checked' );
		$( '#tsosk-404-select-all' ).prop( 'checked', $rows.length > 0 && $checked.length === $rows.length );
	} );

	$( document ).on( 'click', '#tsosk-404-prefill-selected', function () {
		var $checked = $( '#tsosk-404-table .tsosk-404-select:checked' );
		if ( ! $checked.length ) {
			window.alert( tsosk.i18n.redirects_select_404 || tsosk.i18n.error );
			return;
		}
		var sources        = [];
		var skippedCovered = 0;
		var $prefillMsg    = $( '#tsosk-404-msg' );
		var $formMsg       = $( '#tsosk-redirect-msg' );
		$checked.each( function () {
			var $row   = $( this );
			var source = String( $row.data( 'source' ) || '' );
			if ( ! source ) {
				return;
			}
			// Already covered by an enabled rule: saving would only fail as a duplicate.
			if ( $row.data( 'covered' ) ) {
				skippedCovered++;
				$row.prop( 'checked', false );
				return;
			}
			sources.push( source );
		} );
		if ( ! sources.length ) {
			if ( skippedCovered ) {
				showMsg( $prefillMsg, tsosk.i18n.redirects_all_covered || tsosk.i18n.error, 'error' );
			}
			return;
		}
		tsosk404SetPrefillQueue( sources.slice() );
		tsosk404PrefillFromQueue( sources.length );
		if ( skippedCovered && tsosk.i18n.redirects_skip_covered ) {
			var note = tsosk.i18n.redirects_skip_covered.replace( '%1$d', String( skippedCovered ) );
			showMsg( $formMsg, sources.length > 1 ? $formMsg.text() + ' ' + note : note, 'ok' );
		}
	} );

	// Bulk: one exact rule per selected URL (410, or 301 to one target). Covered URLs are skipped.
	function tsosk404Bulk( mode, $btn ) {
		var paths = [];
		$( '#tsosk-404-table .tsosk-404-select:checked' ).each( function () {
			var source = String( $( this ).data( 'source' ) || '' );
			if ( source ) {
				paths.push( source );
			}
		} );
		if ( ! paths.length ) {
			window.alert( tsosk.i18n.redirects_select_404 || tsosk.i18n.error );
			return;
		}
		var target = '';
		if ( 'redirect' === mode ) {
			target = String( $( '#tsosk-404-bulk-target' ).val() || '' ).trim();
			if ( '' === target ) {
				window.alert( tsosk.i18n.redirects_bulk_need_target || tsosk.i18n.error );
				return;
			}
		}
		var confirmText = 'gone' === mode ? tsosk.i18n.redirects_bulk_confirm_gone : tsosk.i18n.redirects_bulk_confirm_redirect;
		if ( confirmText && ! window.confirm( confirmText.replace( '%1$d', String( paths.length ) ) ) ) {
			return;
		}

		var $msg         = $( '#tsosk-404-msg' );
		var originalText = $btn.text();
		$btn.prop( 'disabled', true ).text( tsosk.i18n.running );

		ajaxPost( {
			action : 'tsosk_404_bulk_rules',
			data   : { nonce: $btn.data( 'nonce' ), mode: mode, target: target, paths: paths },
			success: function ( r ) {
				if ( r.success ) {
					showMsg( $msg, ( r.data && r.data.message ) || tsosk.i18n.done, 'ok' );
					setTimeout( function () {
						window.location.reload();
					}, 1200 );
				} else {
					var text = r.data && 'object' === typeof r.data ? r.data.message : r.data;
					showMsg( $msg, text || tsosk.i18n.error, 'error' );
					$btn.prop( 'disabled', false ).text( originalText );
				}
			},
			error: function () {
				showMsg( $msg, tsosk.i18n.error, 'error' );
				$btn.prop( 'disabled', false ).text( originalText );
			}
		} );
	}

	$( document ).on( 'click', '#tsosk-404-bulk-gone', function () {
		tsosk404Bulk( 'gone', $( this ) );
	} );

	$( document ).on( 'click', '#tsosk-404-bulk-redirect', function () {
		tsosk404Bulk( 'redirect', $( this ) );
	} );

	// Suggested patterns: one 410 rule for a whole first-segment prefix (e.g. /en/, /ca/).
	$( document ).on( 'click', '.tsosk-404-prefix-gone', function () {
		var $btn   = $( this );
		var prefix = String( $btn.data( 'prefix' ) || '' );
		if ( ! prefix ) {
			return;
		}
		if ( tsosk.i18n.redirects_prefix_confirm && ! window.confirm( tsosk.i18n.redirects_prefix_confirm.replace( '%1$s', '/' + prefix + '/' ) ) ) {
			return;
		}
		var $msg         = $( '#tsosk-404-msg' );
		var originalText = $btn.text();
		$btn.prop( 'disabled', true ).text( tsosk.i18n.running );

		ajaxPost( {
			action : 'tsosk_404_prefix_gone',
			data   : { nonce: $btn.data( 'nonce' ), prefix: prefix },
			success: function ( r ) {
				if ( r.success ) {
					showMsg( $msg, ( r.data && r.data.message ) || tsosk.i18n.done, 'ok' );
					setTimeout( function () {
						window.location.reload();
					}, 900 );
				} else {
					var text = r.data && 'object' === typeof r.data ? r.data.message : r.data;
					showMsg( $msg, text || tsosk.i18n.error, 'error' );
					$btn.prop( 'disabled', false ).text( originalText );
				}
			},
			error: function () {
				showMsg( $msg, tsosk.i18n.error, 'error' );
				$btn.prop( 'disabled', false ).text( originalText );
			}
		} );
	} );

	$( document ).on( 'click', '.tsosk-404-prefix-prefill', function () {
		var prefix = String( $( this ).data( 'prefix' ) || '' );
		if ( ! prefix ) {
			return;
		}
		resetRedirectForm();
		$( '#tsosk-redirect-match-type' ).val( 'regex' );
		$( '#tsosk-redirect-source' ).val( '^/' + prefix + '(/|$)' );
		tsosk404FocusRedirectForm();
	} );

	$( document ).on( 'click', '#tsosk-404-clear', function () {
		var $btn = $( this );
		var $msg = $( '#tsosk-404-msg' );

		$btn.prop( 'disabled', true ).text( tsosk.i18n.running );

		ajaxPost( {
			action : 'tsosk_404_clear',
			data   : { nonce: $btn.data( 'nonce' ) },
			success: function ( r ) {
				if ( r.success ) {
					showMsg( $msg, ( r.data && r.data.message ) || tsosk.i18n.done, 'ok' );
					$( '#tsosk-404-select-all' ).prop( 'checked', false );
					$( '#tsosk-404-table tbody tr' ).fadeOut( 300, function () {
						$( this ).remove();
					} );
					$btn.fadeOut( 300 );
				} else {
					showMsg( $msg, r.data || tsosk.i18n.error, 'error' );
					$btn.prop( 'disabled', false ).text( tsosk.i18n.clear_404_log );
				}
			},
			error: function () {
				showMsg( $msg, tsosk.i18n.error, 'error' );
				$btn.prop( 'disabled', false ).text( tsosk.i18n.clear_404_log );
			}
		} );
	} );

	$( document ).on( 'click', '#tsosk-404-delete-selected', function () {
		var $btn     = $( this );
		var $checked = $( '#tsosk-404-table .tsosk-404-select:checked' );
		if ( ! $checked.length ) {
			window.alert( tsosk.i18n.redirects_select_404 || tsosk.i18n.error );
			return;
		}
		var paths = [];
		$checked.each( function () {
			var source = String( $( this ).data( 'source' ) || '' );
			if ( source ) {
				paths.push( source );
			}
		} );
		if ( ! paths.length ) {
			return;
		}

		var $msg         = $( '#tsosk-404-msg' );
		var originalText = $btn.text();

		$btn.prop( 'disabled', true ).text( tsosk.i18n.running );

		ajaxPost( {
			action : 'tsosk_404_delete_selected',
			data   : { nonce: $btn.data( 'nonce' ), paths: paths },
			success: function ( r ) {
				if ( r.success ) {
					showMsg( $msg, ( r.data && r.data.message ) || tsosk.i18n.done, 'ok' );
					$checked.each( function () {
						$( this ).closest( 'tr' ).fadeOut( 300, function () {
							$( this ).remove();
						} );
					} );
					$( '#tsosk-404-select-all' ).prop( 'checked', false );
					$btn.prop( 'disabled', false ).text( originalText );
				} else {
					showMsg( $msg, r.data || tsosk.i18n.error, 'error' );
					$btn.prop( 'disabled', false ).text( originalText );
				}
			},
			error: function () {
				showMsg( $msg, tsosk.i18n.error, 'error' );
				$btn.prop( 'disabled', false ).text( originalText );
			}
		} );
	} );

	// ── File Integrity ────────────────────────────────────────────────────

	$( document ).on( 'click', '#tsosk-fi-scan, #tsosk-fi-force-scan', function () {
		var $btn   = $( this );
		var force  = $btn.data( 'force' ) ? 1 : 0;
		var nonce  = $btn.data( 'nonce' );
		var $msg   = $( '#tsosk-fi-msg' );
		var $prog  = $( '#tsosk-fi-progress' );
		var $bar   = $( '#tsosk-fi-bar' );
		var $label = $( '#tsosk-fi-progress-label' );
		var $res   = $( '#tsosk-fi-results' );

		$( '#tsosk-fi-scan, #tsosk-fi-force-scan' ).prop( 'disabled', true );
		$prog.show();
		$bar.css( 'width', '10%' );
		$label.text( tsosk.i18n.fi_connecting );

		var progInterval = setInterval( function () {
			var cur = parseFloat( $bar.css( 'width' ) ) / parseFloat( $bar.parent().css( 'width' ) ) * 100;
			if ( cur < 85 ) {
				$bar.css( 'width', Math.min( cur + 8, 85 ) + '%' );
			}
		}, 600 );

		$.ajax( {
			url    : tsosk.ajax_url,
			type   : 'POST',
			timeout: 120000,
			data   : { action: 'tsosk_fi_scan', nonce: nonce, force: force },
			success: function ( r ) {
				clearInterval( progInterval );
				$bar.css( 'width', '100%' );
				setTimeout( function () { $prog.fadeOut( 300 ); }, 600 );

				if ( r.success ) {
					$res.html( r.data.html || tsosk.i18n.fi_no_html );
					var issues = ( typeof r.data.n_issues === 'number' )
						? r.data.n_issues
						: ( ( r.data.modified || [] ).length + ( r.data.missing || [] ).length );
					if ( issues === 0 ) {
						showMsg( $msg, tsosk.i18n.fi_clean, 'ok' );
					} else {
						showMsg( $msg, issues + ' ' + tsosk.i18n.fi_issues, 'warn' );
					}
				} else {
					showMsg( $msg, r.data || tsosk.i18n.error, 'error' );
				}
				$( '#tsosk-fi-scan, #tsosk-fi-force-scan' ).prop( 'disabled', false );
			},
			error: function ( xhr ) {
				clearInterval( progInterval );
				$prog.fadeOut( 300 );
				var msg = ( xhr.statusText === 'timeout' )
					? tsosk.i18n.fi_timeout
					: tsosk.i18n.error;
				showMsg( $msg, msg, 'error' );
				$( '#tsosk-fi-scan, #tsosk-fi-force-scan' ).prop( 'disabled', false );
			}
		} );
	} );

	$( document ).on( 'click', '.tsosk-fi-view', function () {
		var $btn = $( this );
		var $row = $btn.closest( 'tr' );
		var $old = $row.next( '.tsosk-fi-view-row' );
		if ( $old.length ) {
			$old.remove();
			return;
		}
		$btn.prop( 'disabled', true );
		ajaxPost( {
			action : 'tsosk_fi_view',
			data   : { nonce: $btn.data( 'nonce' ), file: $btn.data( 'file' ) },
			success: function ( r ) {
				$btn.prop( 'disabled', false );
				var $pre = $( '<pre class="tsosk-code" style="white-space:pre-wrap;word-break:break-all;margin:0;max-height:220px;overflow:auto;"></pre>' );
				$pre.text( r && r.success ? r.data.content : ( ( r && r.data ) || tsosk.i18n.error ) );
				var $cell = $( '<td></td>' ).attr( 'colspan', $row.children().length ).append( $pre );
				$row.after( $( '<tr class="tsosk-fi-view-row"></tr>' ).append( $cell ) );
			},
			error: function () {
				$btn.prop( 'disabled', false );
			}
		} );
	} );

	// After ignoring / un-ignoring a file the server sends back the results (without the ignored files) and the
	// "Ignored Files" card, so the lists and counters are right at once and a file is never shown in both.
	function tsoskFiApplyIgnoreChange( data, $msg ) {
		var d = ( data && 'object' === typeof data ) ? data : { message: data };
		if ( d.html ) {
			$( '#tsosk-fi-results' ).html( d.html );
		}
		$( '#tsosk-fi-ignored-wrap' ).html( d.ignored_html || '' );
		showMsg( $msg, d.message || tsosk.i18n.done, 'ok' );
	}

	$( document ).on( 'click', '.tsosk-fi-ignore', function () {
		var $btn  = $( this );
		var file  = $btn.data( 'file' );
		var nonce = $btn.data( 'nonce' );
		var $msg  = $( '#tsosk-fi-msg' );

		$btn.prop( 'disabled', true ).text( tsosk.i18n.running );

		ajaxPost( {
			action : 'tsosk_fi_ignore',
			data   : { nonce: nonce, file: file },
			success: function ( r ) {
				if ( r.success ) {
					tsoskFiApplyIgnoreChange( r.data, $msg );
				} else {
					showMsg( $msg, r.data || tsosk.i18n.error, 'error' );
					$btn.prop( 'disabled', false ).text( tsosk.i18n.fi_ignore );
				}
			},
			error: function () {
				showMsg( $msg, tsosk.i18n.error, 'error' );
				$btn.prop( 'disabled', false ).text( tsosk.i18n.fi_ignore );
			}
		} );
	} );

	$( document ).on( 'click', '.tsosk-fi-unignore', function () {
		var $btn  = $( this );
		var file  = $btn.data( 'file' );
		var nonce = $btn.data( 'nonce' );
		var $msg  = $( '#tsosk-fi-msg' );

		$btn.prop( 'disabled', true ).text( tsosk.i18n.running );

		ajaxPost( {
			action : 'tsosk_fi_unignore',
			data   : { nonce: nonce, file: file },
			success: function ( r ) {
				if ( r.success ) {
					tsoskFiApplyIgnoreChange( r.data, $msg );
				} else {
					showMsg( $msg, r.data || tsosk.i18n.error, 'error' );
					$btn.prop( 'disabled', false ).text( tsosk.i18n.fi_remove );
				}
			},
			error: function () {
				showMsg( $msg, tsosk.i18n.error, 'error' );
				$btn.prop( 'disabled', false ).text( tsosk.i18n.fi_remove );
			}
		} );
	} );

	// ── Security Review ────────────────────────────────────────────────────

	$( document ).on( 'click', '#tsosk-security-save', function () {
		var $btn = $( this );
		var $msg = $( '#tsosk-security-msg' );
		var saveLabel = $btn.data( 'save-label' ) || $btn.text();
		var data = { nonce: $btn.data( 'nonce' ) };

		$( '[id^="tsosk-sec-"]' ).each( function () {
			var key = 'tsosk_security_' + $( this ).data( 'const' );
			data[ key ] = $( this ).prop( 'checked' ) ? 1 : 0;
		} );

		data.tsosk_security_disable_xmlrpc = $( '#tsosk-sec-disable-xmlrpc' ).prop( 'checked' ) ? 1 : 0;
		data.tsosk_security_disable_feeds  = $( '#tsosk-sec-disable-feeds' ).prop( 'checked' ) ? 1 : 0;

		$btn.prop( 'disabled', true ).text( tsosk.i18n.running );

		ajaxPost( {
			action : 'tsosk_security_save',
			data   : data,
			success: function ( r ) {
				if ( r.success ) {
					showMsg( $msg, r.data || tsosk.i18n.done, 'ok' );
				} else {
					showMsg( $msg, r.data || tsosk.i18n.error, 'error' );
				}
				$btn.prop( 'disabled', false ).text( saveLabel );
			},
			error: function () {
				showMsg( $msg, tsosk.i18n.error, 'error' );
				$btn.prop( 'disabled', false ).text( saveLabel );
			}
		} );
	} );

	$( document ).on( 'click', '#tsosk-security-save-alerts', function () {
		var $btn = $( this );
		var $msg = $( '#tsosk-security-alerts-msg' );
		var saveLabel = $btn.data( 'save-label' ) || $btn.text();
		var data = {
			nonce  : $btn.data( 'nonce' ),
			enabled: $( '#tsosk-sec-alerts-enabled' ).prop( 'checked' ) ? 1 : 0,
			email  : $( '#tsosk-sec-alerts-email' ).val()
		};

		$btn.prop( 'disabled', true ).text( tsosk.i18n.running );

		ajaxPost( {
			action : 'tsosk_security_save_alerts',
			data   : data,
			success: function ( r ) {
				if ( r.success ) {
					showMsg( $msg, r.data || tsosk.i18n.done, 'ok' );
				} else {
					showMsg( $msg, r.data || tsosk.i18n.error, 'error' );
				}
				$btn.prop( 'disabled', false ).text( saveLabel );
			},
			error: function () {
				showMsg( $msg, tsosk.i18n.error, 'error' );
				$btn.prop( 'disabled', false ).text( saveLabel );
			}
		} );
	} );

	$( document ).on( 'click', '.tsosk-security-revoke-app-password', function () {
		var $btn = $( this );
		var $msg = $( '#tsosk-security-app-passwords-msg' );
		var data = {
			nonce  : $btn.data( 'nonce' ),
			user_id: $btn.data( 'user-id' ),
			uuid   : $btn.data( 'uuid' )
		};

		$btn.prop( 'disabled', true ).text( tsosk.i18n.running );

		ajaxPost( {
			action : 'tsosk_security_revoke_app_password',
			data   : data,
			success: function ( r ) {
				if ( r.success ) {
					$btn.closest( 'tr' ).fadeOut( 300, function () { $( this ).remove(); } );
					showMsg( $msg, r.data || tsosk.i18n.done, 'ok' );
				} else {
					showMsg( $msg, r.data || tsosk.i18n.error, 'error' );
					$btn.prop( 'disabled', false ).text( tsosk.i18n.sec_revoke );
				}
			},
			error: function () {
				showMsg( $msg, tsosk.i18n.error, 'error' );
				$btn.prop( 'disabled', false ).text( tsosk.i18n.sec_revoke );
			}
		} );
	} );

	$( document ).on( 'click', '#tsosk-security-test-uploads-php', function () {
		var $btn = $( this );
		var $msg = $( '#tsosk-security-uploads-msg' );
		var data = { nonce: $btn.data( 'nonce' ) };

		$btn.prop( 'disabled', true ).text( tsosk.i18n.running );

		ajaxPost( {
			action : 'tsosk_security_test_uploads_php',
			data   : data,
			success: function ( r ) {
				$btn.prop( 'disabled', false ).text( tsosk.i18n.sec_test_now );
				if ( r.success ) {
					showMsg( $msg, r.data.message || tsosk.i18n.done, r.data.status === 'executed' ? 'error' : 'ok' );
					setTimeout( function () { window.location.reload(); }, 1200 );
				} else {
					showMsg( $msg, r.data || tsosk.i18n.error, 'error' );
				}
			},
			error: function () {
				showMsg( $msg, tsosk.i18n.error, 'error' );
				$btn.prop( 'disabled', false ).text( tsosk.i18n.sec_test_now );
			}
		} );
	} );

	$( document ).on( 'click', '#tsosk-security-protect-uploads', function () {
		var $btn = $( this );
		var $msg = $( '#tsosk-security-uploads-msg' );
		var data = { nonce: $btn.data( 'nonce' ) };

		$btn.prop( 'disabled', true ).text( tsosk.i18n.running );

		ajaxPost( {
			action : 'tsosk_security_protect_uploads',
			data   : data,
			success: function ( r ) {
				if ( r.success ) {
					showMsg( $msg, r.data || tsosk.i18n.done, 'ok' );
					setTimeout( function () { window.location.reload(); }, 1200 );
				} else {
					showMsg( $msg, r.data || tsosk.i18n.error, 'error' );
					$btn.prop( 'disabled', false ).text( tsosk.i18n.sec_enable_protection );
				}
			},
			error: function () {
				showMsg( $msg, tsosk.i18n.error, 'error' );
				$btn.prop( 'disabled', false ).text( tsosk.i18n.sec_enable_protection );
			}
		} );
	} );

	$( document ).on( 'click', '#tsosk-security-revoke-all-app-passwords', function () {
		if ( ! window.confirm( tsosk.i18n.sec_revoke_all_confirm ) ) {
			return;
		}
		var $btn = $( this );
		var $msg = $( '#tsosk-security-app-passwords-msg' );
		var data = { nonce: $btn.data( 'nonce' ) };

		$btn.prop( 'disabled', true ).text( tsosk.i18n.running );

		ajaxPost( {
			action : 'tsosk_security_revoke_all_app_passwords',
			data   : data,
			success: function ( r ) {
				if ( r.success ) {
					showMsg( $msg, r.data || tsosk.i18n.done, 'ok' );
					setTimeout( function () { window.location.reload(); }, 1200 );
				} else {
					showMsg( $msg, r.data || tsosk.i18n.error, 'error' );
					$btn.prop( 'disabled', false ).text( tsosk.i18n.sec_revoke_all );
				}
			},
			error: function () {
				showMsg( $msg, tsosk.i18n.error, 'error' );
				$btn.prop( 'disabled', false ).text( tsosk.i18n.sec_revoke_all );
			}
		} );
	} );

	// ── Hidden WordPress Profiles ─────────────────────────────────────────
	var tsoskHpPresets = {
		performance: [
			'disable_wp_cron', 'concatenate_scripts', 'disable_emojis', 'disable_embeds'
		],
		content: [
			'limit_revisions', 'slow_autosave', 'empty_trash'
		],
		privacy: [
			'close_comments', 'disable_emojis', 'disable_embeds'
		]
	};

	$( document ).on( 'click', '[data-tsosk-hp-preset]', function () {
		var preset = $( this ).data( 'tsosk-hp-preset' );
		var fields = preset === 'clear' ? [] : ( tsoskHpPresets[ preset ] || [] );
		$( '[data-hp-field]' ).each( function () {
			var field = $( this ).data( 'hp-field' );
			var isRt  = field.indexOf( 'rt_' ) === 0;
			var key   = isRt ? field.slice( 3 ) : field;
			var match = false;
			fields.forEach( function ( f ) {
				if ( f === key || ( isRt && f === key ) || ( ! isRt && f === field ) ) {
					match = true;
				}
			} );
			if ( preset === 'clear' ) {
				if ( $( this ).is( ':checkbox' ) ) {
					$( this ).prop( 'checked', false );
				}
			} else if ( $( this ).is( ':checkbox' ) ) {
				$( this ).prop( 'checked', match );
			}
		} );
	} );

	$( document ).on( 'click', '#tsosk-hp-save', function () {
		var $btn = $( this );
		var $msg = $( '#tsosk-hp-msg' );
		var $panel = $( '#tsosk-hp-panel' );
		var saveLabel = $btn.data( 'save-label' ) || $btn.text();
		var data = { nonce: $btn.data( 'nonce' ) };

		$panel.find( 'input[name^="tsosk_hp_"]' ).each( function () {
			var $el = $( this );
			var name = $el.attr( 'name' );
			if ( ! name ) {
				return;
			}
			if ( 'checkbox' === $el.attr( 'type' ) ) {
				data[ name ] = $el.prop( 'checked' ) ? 1 : 0;
			} else if ( 'number' === $el.attr( 'type' ) ) {
				data[ name ] = $el.val();
			}
		} );

		$btn.prop( 'disabled', true ).text( tsosk.i18n.running );

		ajaxPost( {
			action : 'tsosk_hidden_profiles_save',
			data   : data,
			success: function ( r ) {
				if ( r.success ) {
					showMsg( $msg, r.data || tsosk.i18n.done, 'ok' );
					setTimeout( function () { window.location.reload(); }, 900 );
				} else {
					showMsg( $msg, r.data || tsosk.i18n.error, 'error' );
					$btn.prop( 'disabled', false ).text( saveLabel );
				}
			},
			error: function ( xhr ) {
				var errMsg = tsosk.i18n.error;
				if ( xhr && xhr.responseText === '0' ) {
					errMsg = tsosk.i18n.error + ' (session expired — reload the page and try again)';
				}
				showMsg( $msg, errMsg, 'error' );
				$btn.prop( 'disabled', false ).text( saveLabel );
			}
		} );
	} );


	// ── Login Protection ──────────────────────────────────────────────────

	// Save settings
	$( document ).on( 'click', '#tsosk-lp-save', function () {
		var $btn  = $( this );
		var $msg  = $( '#tsosk-lp-msg' );
		var nonce = $btn.data( 'nonce' );
		var data  = {
			nonce           : nonce,
			custom_url      : $( '#tsosk-lp-custom-url' ).prop( 'checked' ) ? 1 : 0,
			login_slug      : $( '#tsosk-lp-slug' ).val(),
			brute_force     : $( '#tsosk-lp-brute' ).prop( 'checked' ) ? 1 : 0,
			block_forbidden_usernames: $( '#tsosk-lp-block-forbidden' ).prop( 'checked' ) ? 1 : 0,
			max_attempts    : $( '#tsosk-lp-max' ).val(),
			lockout_window  : $( '#tsosk-lp-window' ).val(),
			lockout_duration: $( '#tsosk-lp-duration' ).val(),
			notify_email    : $( '#tsosk-lp-notify' ).prop( 'checked' ) ? 1 : 0,
			notify_address  : $( '#tsosk-lp-notify-addr' ).val(),
			whitelist_ips   : $( '#tsosk-lp-whitelist' ).val(),
			login_maintenance: $( '#tsosk-lp-maintenance' ).prop( 'checked' ) ? 1 : 0,
			login_maintenance_ips: $( '#tsosk-lp-maintenance-ips' ).val(),
			email_2fa       : $( '#tsosk-lp-2fa' ).prop( 'checked' ) ? 1 : 0,
			role_whitelist_ips: $( '#tsosk-lp-role-ips' ).val(),
			notify_mass_threshold: $( '#tsosk-lp-mass-threshold' ).val(),
			notify_mass_window: $( '#tsosk-lp-mass-window' ).val()
		};
		data.email_2fa_roles = [];
		$( 'input[name="email_2fa_roles[]"]:checked' ).each( function () {
			data.email_2fa_roles.push( $( this ).val() );
		} );

		$btn.prop( 'disabled', true ).text( tsosk.i18n.running );

		ajaxPost( {
			action : 'tsosk_lp_save',
			data   : data,
			success: function ( r ) {
				if ( r.success ) {
					showMsg( $msg, r.data, 'ok' );
				} else {
					showMsg( $msg, r.data, 'error' );
				}
				$btn.prop( 'disabled', false ).text( tsosk.i18n.save );
			},
			error: function () {
				showMsg( $msg, tsosk.i18n.error, 'error' );
				$btn.prop( 'disabled', false ).text( tsosk.i18n.save );
			}
		} );
	} );

	// ── Comment Anti-Spam ─────────────────────────────────────────────────

	$( document ).on( 'click', '#tsosk-cas-save', function () {
		var $btn  = $( this );
		var $msg  = $( '#tsosk-cas-msg' );
		var nonce = $btn.data( 'nonce' );

		$btn.prop( 'disabled', true ).text( tsosk.i18n.running );

		ajaxPost( {
			action : 'tsosk_cas_save',
			data   : {
				nonce                   : nonce,
				enabled                 : $( '#tsosk-cas-enabled' ).prop( 'checked' ) ? 1 : 0,
				learning_mode           : $( '#tsosk-cas-learning-mode' ).prop( 'checked' ) ? 1 : 0,
				protect_comments        : $( '#tsosk-cas-protect-comments' ).prop( 'checked' ) ? 1 : 0,
				protect_contact_forms   : $( '#tsosk-cas-protect-forms' ).prop( 'checked' ) ? 1 : 0,
				honeypot                : $( '#tsosk-cas-honeypot' ).prop( 'checked' ) ? 1 : 0,
				time_trap               : $( '#tsosk-cas-time-trap' ).prop( 'checked' ) ? 1 : 0,
				rate_limit              : $( '#tsosk-cas-rate-limit' ).prop( 'checked' ) ? 1 : 0,
				block_disposable_email  : $( '#tsosk-cas-disposable' ).prop( 'checked' ) ? 1 : 0,
				duplicate_check         : $( '#tsosk-cas-duplicate' ).prop( 'checked' ) ? 1 : 0,
				block_cyrillic          : $( '#tsosk-cas-cyrillic' ).prop( 'checked' ) ? 1 : 0,
				skip_logged_in          : $( '#tsosk-cas-skip-logged-in' ).prop( 'checked' ) ? 1 : 0,
				log_blocks              : $( '#tsosk-cas-log-blocks' ).prop( 'checked' ) ? 1 : 0,
				min_submit_seconds      : $( '#tsosk-cas-min-seconds' ).val(),
				max_submit_seconds      : $( '#tsosk-cas-max-seconds' ).val(),
				rate_limit_count        : $( '#tsosk-cas-rate-count' ).val(),
				rate_limit_window       : $( '#tsosk-cas-rate-window' ).val(),
				max_links               : $( '#tsosk-cas-max-links' ).val(),
				duplicate_window        : $( '#tsosk-cas-dup-window' ).val(),
				spam_action             : $( '#tsosk-cas-spam-action' ).val(),
				cloud_mode              : $( '#tsosk-cas-cloud-mode' ).val(),
				cleantalk_key           : $( '#tsosk-cas-cleantalk-key' ).val(),
				stopforumspam_enabled   : $( '#tsosk-cas-sfs' ).prop( 'checked' ) ? 1 : 0,
				sfs_min_confidence      : $( '#tsosk-cas-sfs-confidence' ).val(),
				abuseipdb_enabled       : $( '#tsosk-cas-abuseipdb' ).prop( 'checked' ) ? 1 : 0,
				abuseipdb_key           : $( '#tsosk-cas-abuseipdb-key' ).val(),
				abuseipdb_min_score     : $( '#tsosk-cas-abuseipdb-score' ).val(),
				abuseipdb_max_age_days  : $( '#tsosk-cas-abuseipdb-age' ).val(),
				honeypot_httpbl_enabled : $( '#tsosk-cas-httpbl' ).prop( 'checked' ) ? 1 : 0,
				honeypot_access_key     : $( '#tsosk-cas-httpbl-key' ).val(),
				honeypot_min_threat     : $( '#tsosk-cas-httpbl-threat' ).val(),
				block_keywords          : $( '#tsosk-cas-keywords' ).val(),
				block_urls              : $( '#tsosk-cas-urls' ).val(),
				custom_disposable_domains: $( '#tsosk-cas-domains' ).val(),
				whitelist_ips           : $( '#tsosk-cas-whitelist' ).val(),
				log_max                 : $( '#tsosk-cas-log-max' ).val(),
				alert_enabled           : $( '#tsosk-cas-alert-enabled' ).prop( 'checked' ) ? 1 : 0,
				alert_email             : $( '#tsosk-cas-alert-email' ).val(),
				alert_threshold         : $( '#tsosk-cas-alert-threshold' ).val(),
				alert_provider_errors   : $( '#tsosk-cas-alert-providers' ).prop( 'checked' ) ? 1 : 0,
				protect_reviews         : $( '#tsosk-cas-protect-reviews' ).prop( 'checked' ) ? 1 : 0,
				protect_registration    : $( '#tsosk-cas-protect-registration' ).prop( 'checked' ) ? 1 : 0,
				ban_enabled             : $( '#tsosk-cas-ban-enabled' ).prop( 'checked' ) ? 1 : 0,
				ban_threshold           : $( '#tsosk-cas-ban-threshold' ).val(),
				ban_hours               : $( '#tsosk-cas-ban-hours' ).val(),
				trust_returning         : $( '#tsosk-cas-trust-returning' ).prop( 'checked' ) ? 1 : 0,
				block_message           : $( '#tsosk-cas-block-message' ).val(),
				observe_rules           : $( '.tsosk-cas-observe:checked' ).map( function () { return this.value; } ).get()
			},
			success: function ( r ) {
				if ( r.success ) {
					showMsg( $msg, r.data, 'ok' );
				} else {
					showMsg( $msg, r.data, 'error' );
				}
				$btn.prop( 'disabled', false ).text( tsosk.i18n.save );
			},
			error: function () {
				showMsg( $msg, tsosk.i18n.error, 'error' );
				$btn.prop( 'disabled', false ).text( tsosk.i18n.save );
			}
		} );
	} );

	$( document ).on( 'click', '#tsosk-cas-clear-log', function () {
		var $btn  = $( this );
		var nonce = $btn.data( 'nonce' );

		$btn.prop( 'disabled', true );

		ajaxPost( {
			action : 'tsosk_cas_clear_log',
			data   : { nonce: nonce },
			success: function ( r ) {
				if ( r.success ) {
					window.location.reload();
				} else {
					$btn.prop( 'disabled', false );
				}
			},
			error: function () {
				$btn.prop( 'disabled', false );
			}
		} );
	} );

	$( document ).on( 'click', '#tsosk-cas-clear-learning-log', function () {
		var $btn  = $( this );
		var nonce = $btn.data( 'nonce' );

		$btn.prop( 'disabled', true );

		ajaxPost( {
			action : 'tsosk_cas_clear_learning_log',
			data   : { nonce: nonce },
			success: function ( r ) {
				if ( r.success ) {
					window.location.reload();
				} else {
					$btn.prop( 'disabled', false );
				}
			},
			error: function () {
				$btn.prop( 'disabled', false );
			}
		} );
	} );

	$( document ).on( 'click', '.tsosk-cas-test-provider', function () {
		var $btn = $( this );
		var $msg = $( '#tsosk-cas-test-msg' );

		$btn.prop( 'disabled', true );
		ajaxPost( {
			action : 'tsosk_cas_test_provider',
			data   : { nonce: $btn.data( 'nonce' ), provider: $btn.data( 'provider' ) },
			success: function ( r ) {
				$msg.attr( 'class', 'tsosk-msg tsosk-msg--' + ( r.success ? 'ok' : 'error' ) ).text( r.data ).show();
				$btn.prop( 'disabled', false );
			},
			error: function () {
				$msg.attr( 'class', 'tsosk-msg tsosk-msg--error' ).text( tsosk.i18n.error ).show();
				$btn.prop( 'disabled', false );
			}
		} );
	} );

	$( document ).on( 'click', '.tsosk-cas-allow-ip', function () {
		var $btn = $( this );

		if ( ! window.confirm( $btn.data( 'confirm' ) ) ) {
			return;
		}

		$btn.prop( 'disabled', true );
		ajaxPost( {
			action : 'tsosk_cas_allow_ip',
			data   : { nonce: $btn.data( 'nonce' ), ip: $btn.data( 'ip' ), log: $btn.data( 'log' ) },
			success: function ( r ) {
				if ( r.success ) {
					window.location.reload();
				} else {
					$btn.prop( 'disabled', false );
				}
			},
			error: function () {
				$btn.prop( 'disabled', false );
			}
		} );
	} );

	// Comment anti-spam: sub-tabs (remembered for the browser session).
	function casShowTab( tab ) {
		var $tab = $( '.tsosk-cas-tab[data-tab="' + tab + '"]' );
		if ( ! $tab.length ) {
			return;
		}
		$( '.tsosk-cas-tab' ).removeClass( 'nav-tab-active' ).attr( 'aria-selected', 'false' );
		$tab.addClass( 'nav-tab-active' ).attr( 'aria-selected', 'true' );
		$( '.tsosk-cas-panel' ).prop( 'hidden', true );
		$( '#tsosk-cas-panel-' + tab ).prop( 'hidden', false );
		try {
			window.sessionStorage.setItem( 'tsosk_cas_tab', tab );
		} catch ( e ) {
			// Storage unavailable: the tab just is not remembered.
		}
	}

	$( document ).on( 'click', '.tsosk-cas-tab', function ( e ) {
		e.preventDefault();
		casShowTab( $( this ).data( 'tab' ) );
	} );

	$( function () {
		if ( ! $( '.tsosk-cas-tabs' ).length ) {
			return;
		}
		var saved = '';
		try {
			saved = window.sessionStorage.getItem( 'tsosk_cas_tab' ) || '';
		} catch ( e ) {
			saved = '';
		}
		if ( saved ) {
			casShowTab( saved );
		}
	} );

	// Redirects: sub-tabs (remembered for the browser session).
	function rdShowTab( tab ) {
		var $tab = $( '.tsosk-rd-tab[data-tab="' + tab + '"]' );
		if ( ! $tab.length ) {
			return;
		}
		$( '.tsosk-rd-tab' ).removeClass( 'nav-tab-active' ).attr( 'aria-selected', 'false' );
		$tab.addClass( 'nav-tab-active' ).attr( 'aria-selected', 'true' );
		$( '.tsosk-rd-panel' ).prop( 'hidden', true );
		$( '#tsosk-rd-panel-' + tab ).prop( 'hidden', false );
		try {
			window.sessionStorage.setItem( 'tsosk_rd_tab', tab );
		} catch ( e ) {
			// Storage unavailable: the tab just is not remembered.
		}
	}

	$( document ).on( 'click', '.tsosk-rd-tab', function ( e ) {
		e.preventDefault();
		rdShowTab( $( this ).data( 'tab' ) );
	} );

	$( function () {
		if ( ! $( '.tsosk-rd-tabs' ).length ) {
			return;
		}
		var saved = '';
		try {
			saved = window.sessionStorage.getItem( 'tsosk_rd_tab' ) || '';
		} catch ( e ) {
			saved = '';
		}
		if ( saved ) {
			rdShowTab( saved );
		}
	} );

	$( document ).on( 'click', '#tsosk-cas-test-alert', function () {
		var $btn = $( this );
		var $msg = $( '#tsosk-cas-alert-msg' );

		$btn.prop( 'disabled', true );
		ajaxPost( {
			action : 'tsosk_cas_test_alert',
			data   : { nonce: $btn.data( 'nonce' ) },
			success: function ( r ) {
				$msg.attr( 'class', 'tsosk-msg tsosk-msg--' + ( r.success ? 'ok' : 'error' ) ).text( r.data ).show();
				$btn.prop( 'disabled', false );
			},
			error: function () {
				$msg.attr( 'class', 'tsosk-msg tsosk-msg--error' ).text( tsosk.i18n.error ).show();
				$btn.prop( 'disabled', false );
			}
		} );
	} );

	// Generate slug
	$( document ).on( 'click', '#tsosk-lp-generate', function () {
		var $btn  = $( this );
		var nonce = $( '#tsosk-lp-save' ).data( 'nonce' );

		$btn.prop( 'disabled', true );

		ajaxPost( {
			action : 'tsosk_lp_generate_slug',
			data   : { nonce: nonce },
			success: function ( r ) {
				if ( r.success && r.data && r.data.slug ) {
					$( '#tsosk-lp-slug' ).val( r.data.slug ).trigger( 'focus' );
				}
				$btn.prop( 'disabled', false );
			},
			error: function () { $btn.prop( 'disabled', false ); }
		} );
	} );

	// Add my IP to whitelist
	$( document ).on( 'click', '#tsosk-lp-add-my-ip', function () {
		var ip      = $( this ).data( 'ip' );
		var $area   = $( '#tsosk-lp-whitelist' );
		var current = $area.val().trim();
		$area.val( current ? current + '\n' + ip : ip );
		$( this ).prop( 'disabled', true );
	} );

	// Unlock specific IP
	$( document ).on( 'click', '.tsosk-lp-unlock', function () {
		var $btn  = $( this );
		var ip    = $btn.data( 'ip' );
		var idx   = $btn.data( 'idx' );
		var nonce = $btn.data( 'nonce' );
		var $msg  = $( '#tsosk-lp-log-msg' );

		$btn.prop( 'disabled', true ).text( tsosk.i18n.running );

		ajaxPost( {
			action : 'tsosk_lp_unlock',
			data   : { nonce: nonce, ip: ip, idx: idx },
			success: function ( r ) {
				if ( r.success ) {
					$btn.closest( 'tr' ).find( '.tsosk-badge-warn' ).first()
						.removeClass( 'tsosk-badge-warn' )
						.text( tsosk.i18n.expired || 'Expired' );
					$btn.closest( 'tr' ).removeClass( 'tsosk-row-warn' );
					$btn.closest( 'td' ).html( '<span style="color:#ccc">&mdash;</span>' );
					showMsg( $msg, r.data, 'ok' );
				} else {
					showMsg( $msg, r.data || tsosk.i18n.error, 'error' );
					$btn.prop( 'disabled', false ).text( tsosk.i18n.lp_unlock );
				}
			},
			error: function () {
				showMsg( $msg, tsosk.i18n.error, 'error' );
				$btn.prop( 'disabled', false ).text( tsosk.i18n.lp_unlock );
			}
		} );
	} );

	// Unlock all
	$( document ).on( 'click', '#tsosk-lp-unlock-all', function () {
		var $btn  = $( this );
		var nonce = $btn.data( 'nonce' );
		var $msg  = $( '#tsosk-lp-log-msg' );

		if ( ! confirm( tsosk.i18n.lp_unlock_all_confirm ) ) { return; }

		$btn.prop( 'disabled', true ).text( tsosk.i18n.running );

		ajaxPost( {
			action : 'tsosk_lp_unlock_all',
			data   : { nonce: nonce },
			success: function ( r ) {
				if ( r.success ) {
					showMsg( $msg, r.data, 'ok' );
					$( '#tsosk-lp-log-table .tsosk-badge-warn' ).each( function () {
						$( this ).removeClass( 'tsosk-badge-warn' ).text( tsosk.i18n.expired || 'Expired' );
					} );
					$( '#tsosk-lp-log-table tr.tsosk-row-warn' ).removeClass( 'tsosk-row-warn' );
					$( '.tsosk-lp-unlock' ).closest( 'td' ).html( '<span style="color:#ccc">&mdash;</span>' );
					$btn.fadeOut( 300 );
				} else {
					showMsg( $msg, r.data || tsosk.i18n.error, 'error' );
					$btn.prop( 'disabled', false ).text( tsosk.i18n.lp_unlock_all );
				}
			},
			error: function () {
				showMsg( $msg, tsosk.i18n.error, 'error' );
				$btn.prop( 'disabled', false ).text( tsosk.i18n.lp_unlock_all );
			}
		} );
	} );

	// Clear log
	$( document ).on( 'click', '#tsosk-lp-clear-log', function () {
		var $btn  = $( this );
		var nonce = $btn.data( 'nonce' );
		var $msg  = $( '#tsosk-lp-log-msg' );

		if ( ! confirm( tsosk.i18n.lp_clear_log_confirm ) ) { return; }

		$btn.prop( 'disabled', true ).text( tsosk.i18n.running );

		ajaxPost( {
			action : 'tsosk_lp_clear_log',
			data   : { nonce: nonce },
			success: function ( r ) {
				if ( r.success ) {
					showMsg( $msg, r.data, 'ok' );
					$( '#tsosk-lp-log-table tbody' ).empty();
					$btn.fadeOut( 300 );
				} else {
					showMsg( $msg, r.data || tsosk.i18n.error, 'error' );
					$btn.prop( 'disabled', false ).text( tsosk.i18n.lp_clear_log );
				}
			},
			error: function () {
				showMsg( $msg, tsosk.i18n.error, 'error' );
				$btn.prop( 'disabled', false ).text( tsosk.i18n.lp_clear_log );
			}
		} );
	} );

	// Reset attempt counter for IP
	$( document ).on( 'click', '.tsosk-lp-reset-counter', function () {
		var $btn  = $( this );
		var ip    = $btn.data( 'ip' );
		var nonce = $btn.data( 'nonce' );
		var $msg  = $( '#tsosk-lp-msg' );

		$btn.prop( 'disabled', true ).text( tsosk.i18n.running );

		ajaxPost( {
			action : 'tsosk_lp_unlock',
			data   : { nonce: nonce, ip: ip, reset_attempts_only: 1 },
			success: function ( r ) {
				if ( r.success ) {
					$btn.closest( 'tr' ).fadeOut( 300, function () { $( this ).remove(); } );
					showMsg( $msg, r.data, 'ok' );
				} else {
					showMsg( $msg, r.data || tsosk.i18n.error, 'error' );
					$btn.prop( 'disabled', false ).text( tsosk.i18n.lp_reset );
				}
			},
			error: function () {
				showMsg( $msg, tsosk.i18n.error, 'error' );
				$btn.prop( 'disabled', false ).text( tsosk.i18n.lp_reset );
			}
		} );
	} );


	// ── Options Editor ─────────────────────────────────────────────────────


	var tsosk_oe = {
		lastSearch     : '',
		currentPage    : 1,
		totalPages     : 1,
		sortCol        : 'option_name',
		sortDir        : 'ASC',
		showProtected  : false,
		exactSearch    : false,
		autoOpen       : false,
		readOnly       : false,
	};

	// Tab switching
	$( document ).on( 'click', '.tsosk-oe-tab-btn', function () {
		var tab = $( this ).data( 'tab' );
		$( '.tsosk-oe-tab-btn' ).removeClass( 'is-active' );
		$( this ).addClass( 'is-active' );
		$( '.tsosk-oe-panel' ).hide();
		$( '#tsosk-oe-panel-' + tab ).show();
		$( '#tsosk-oe-editor' ).hide();
		// Re-trigger search when returning to Browse tab if table is empty
		if ( tab === 'list' ) {
			var $tbody = $( '#tsosk-oe-tbody' );
			if ( ! $tbody.find( 'tr' ).length || $tbody.find( 'td[colspan]' ).length ) {
				tsosk_oe_search( tsosk_oe.lastSearch || '', tsosk_oe.currentPage || 1 );
			}
		}
	} );

	// Auto-load all options when Browse tab is first visible
	var tsosk_oe_search_seq = 0;
	function tsosk_oe_search( search, page ) {
		tsosk_oe.lastSearch  = search;
		tsosk_oe.currentPage = page || 1;
		var nonce    = $( '#tsosk-oe-nonce' ).val();
		var $msg     = $( '#tsosk-oe-search-msg' );
		var $spinner = $( '#tsosk-oe-tbody' );
		var reqId    = ++tsosk_oe_search_seq;

		$spinner.html( '<tr><td colspan="6" style="text-align:center;padding:14px;color:#666;"><span class="spinner is-active" style="float:none;margin:0 8px 0 0;"></span>' + tsosk.i18n.loading + '</td></tr>' );

		ajaxPost( {
			action : 'tsosk_oe_search',
			data   : {
				nonce            : nonce,
				search           : search,
				page             : tsosk_oe.currentPage,
				sort_col         : tsosk_oe.sortCol,
				sort_dir         : tsosk_oe.sortDir,
				filter_type      : $( '#tsosk-oe-filter-type' ).val() || '',
				filter_autoload  : $( '#tsosk-oe-filter-autoload' ).val() || '',
				min_size_kb      : $( '#tsosk-oe-min-size' ).val() || 0,
				show_protected   : tsosk_oe.showProtected ? 1 : 0,
				exact            : tsosk_oe.exactSearch ? 1 : 0,
			},
			success: function ( r ) {
				if ( reqId !== tsosk_oe_search_seq ) {
					return;
				}
				if ( r.success ) {
					tsosk_oe.totalPages = r.data.total_pages;
					tsosk_oe_render_table( r.data );
					showMsg( $msg, r.data.total + ' ' + tsosk.i18n.oe_options, 'ok' );
				} else {
					showMsg( $msg, r.data || tsosk.i18n.error, 'error' );
				}
			},
			error: function () {
				if ( reqId !== tsosk_oe_search_seq ) {
					return;
				}
				showMsg( $msg, tsosk.i18n.error, 'error' );
			}
		} );
	}

	var tsosk_oe_search_timer = null;
	function tsosk_oe_schedule_search() {
		clearTimeout( tsosk_oe_search_timer );
		tsosk_oe_search_timer = setTimeout( function () {
			tsosk_oe_search( $( '#tsosk-oe-search' ).val().trim(), 1 );
		}, 350 );
	}

	// Auto-load on page ready (always load when editor is present)
	$( function () {
		if ( ! $( '#tsosk-oe-nonce' ).length ) {
			return;
		}
		var initialSearch = '';
		var autoOpen      = false;
		if ( typeof URLSearchParams !== 'undefined' ) {
			var params = new URLSearchParams( window.location.search );
			var oeParam = params.get( 'oe_search' );
			if ( oeParam ) {
				initialSearch = oeParam;
				$( '#tsosk-oe-search' ).val( initialSearch );
			}
			if ( '1' === params.get( 'oe_protected' ) ) {
				tsosk_oe.showProtected = true;
				var $protBtn = $( '#tsosk-oe-toggle-protected' );
				if ( $protBtn.length ) {
					$protBtn.attr( 'aria-pressed', 'true' );
					$protBtn.text( tsosk.i18n.oe_hide_protected || $protBtn.text() );
					$protBtn.addClass( 'button-primary' );
				}
			}
			if ( '1' === params.get( 'oe_exact' ) ) {
				tsosk_oe.exactSearch = true;
				autoOpen = true;
			}
		}
		tsosk_oe.autoOpen = autoOpen;
		tsosk_oe_search( initialSearch, 1 );
	} );

	$( document ).on( 'input', '#tsosk-oe-search', function () {
		tsosk_oe_schedule_search();
	} );
	// Filter dropdowns auto-trigger search
	$( document ).on( 'change', '#tsosk-oe-filter-type', function () {
		tsosk_oe_search( $( '#tsosk-oe-search' ).val().trim(), 1 );
	} );
	$( document ).on( 'change', '#tsosk-oe-filter-autoload', function () {
		tsosk_oe_search( $( '#tsosk-oe-search' ).val().trim(), 1 );
	} );
	$( document ).on( 'input', '#tsosk-oe-min-size', function () {
		tsosk_oe_schedule_search();
	} );
	$( document ).on( 'click', '#tsosk-oe-toggle-protected', function () {
		tsosk_oe.showProtected = ! tsosk_oe.showProtected;
		var $btn = $( this );
		$btn.attr( 'aria-pressed', tsosk_oe.showProtected ? 'true' : 'false' );
		$btn.text( tsosk_oe.showProtected ? tsosk.i18n.oe_hide_protected : tsosk.i18n.oe_show_protected );
		$btn.toggleClass( 'button-primary', tsosk_oe.showProtected );
		tsosk_oe_search( $( '#tsosk-oe-search' ).val().trim(), 1 );
	} );
	// Clear all filters
	$( document ).on( 'click', '#tsosk-oe-clear-filters', function () {
		$( '#tsosk-oe-search' ).val( '' );
		$( '#tsosk-oe-filter-type' ).val( '' );
		$( '#tsosk-oe-filter-autoload' ).val( '' );
		$( '#tsosk-oe-min-size' ).val( '' );
		tsosk_oe.sortCol = 'option_name';
		tsosk_oe.sortDir = 'ASC';
		$( '.tsosk-oe-sortable .tsosk-sort-icon' ).text( '' );
		$( '.tsosk-oe-sortable[data-col="option_name"] .tsosk-sort-icon' ).text( '▲' );
		tsosk_oe_search( '', 1 );
	} );

	// Sortable column headers
	$( document ).on( 'click', '.tsosk-oe-sortable', function () {
		var col = $( this ).data( 'col' );
		if ( tsosk_oe.sortCol === col ) {
			tsosk_oe.sortDir = tsosk_oe.sortDir === 'ASC' ? 'DESC' : 'ASC';
		} else {
			tsosk_oe.sortCol = col;
			tsosk_oe.sortDir = 'ASC';
		}
		// Update icons on all sortable headers
		$( '.tsosk-oe-sortable .tsosk-sort-icon' ).text( '' );
		$( this ).find( '.tsosk-sort-icon' ).text( tsosk_oe.sortDir === 'ASC' ? '▲' : '▼' );
		// Highlight active column
		$( '.tsosk-oe-sortable' ).css( 'color', '' );
		$( this ).css( 'color', '#2271b1' );
		tsosk_oe_search( tsosk_oe.lastSearch, 1 );
	} );

	function tsosk_oe_render_table( data ) {
		var $tbody = $( '#tsosk-oe-tbody' );
		var nonce  = $( '#tsosk-oe-nonce' ).val();
		var items  = data.items || [];

		$tbody.empty();
		if ( ! items.length ) {
			$tbody.append( '<tr><td colspan="6" style="text-align:center;color:#646970;">' + tsosk.i18n.oe_no_results + '</td></tr>' );
			$( '#tsosk-oe-pagination-top, #tsosk-oe-pagination-bottom' ).html( '' );
			return;
		}

		$.each( items, function ( i, item ) {
			var isCaution   = !! item.caution;
			var isProtected = !! item.protected;
			var sizeStr     = item.size > 1024 ? ( ( item.size / 1024 ).toFixed( 1 ) + ' KB' ) : ( item.size + ' B' );
			var typeColor   = { serialized: '#7c3aed', json: '#0369a1', integer: '#0f766e', text: '#374151' };
			var tc          = typeColor[ item.type ] || '#374151';
			var alColor     = item.autoload === 'yes' || item.autoload === 'on' || item.autoload === 'auto-on' || item.autoload === 'auto' ? '#d97706' : '#6b7280';

			var badge_al    = '<span style="background:' + ( item.autoload === 'yes' || item.autoload === 'on' || item.autoload === 'auto-on' || item.autoload === 'auto' ? '#fef3c7' : '#f3f4f6' ) + ';color:' + alColor + ';padding:2px 7px;border-radius:10px;font-size:11px;">' + item.autoload + '</span>';
			var badge_type  = '<span style="background:#f3f4f6;color:' + tc + ';padding:2px 7px;border-radius:10px;font-size:11px;">' + item.type + '</span>';

			var actions = '';
			var $actionsWrap = $( '<div></div>' );
			if ( isProtected ) {
				$actionsWrap.append(
					$( '<button type="button" class="button button-small tsosk-oe-edit-btn"></button>' )
						.attr( { 'data-name': item.name, 'data-protected': '1', 'data-caution': '0', 'data-nonce': nonce } )
						.text( tsosk.i18n.oe_view )
				);
			} else {
				$actionsWrap.append(
					$( '<button type="button" class="button button-small tsosk-oe-edit-btn"></button>' )
						.attr( { 'data-name': item.name, 'data-protected': '0', 'data-caution': isCaution ? '1' : '0', 'data-nonce': nonce } )
						.text( tsosk.i18n.oe_edit )
				);
				$actionsWrap.append( ' ' );
				$actionsWrap.append(
					$( '<button type="button" class="button button-small button-link-delete tsosk-oe-delete-btn"></button>' )
						.attr( { 'data-name': item.name, 'data-nonce': nonce } )
						.text( tsosk.i18n.oe_delete )
				);
			}
			actions = $actionsWrap.html();

			var $tr = $( '<tr>' + ( isProtected ? ' class="tsosk-oe-protected"' : '' ) + '>' );
			var nameCell = $( '<td style="word-break:break-all;font-family:monospace;font-size:12px;color:#1d2327;">' );
			nameCell.append( $( '<span>' ).text( item.name ) );
			if ( isProtected ) {
				nameCell.append( ' ' ).append( $( '<span class="tsosk-badge tsosk-badge-warn" style="font-size:10px;vertical-align:middle;">' ).text( tsosk.i18n.oe_protected ) );
			}
			$tr.append( nameCell );
			$tr.append( $( '<td style="font-size:12px;color:#374151;">' ).text( sizeStr ) );
			$tr.append( $( '<td>' ).html( badge_al ) );
			$tr.append( $( '<td>' ).html( badge_type ) );
			$tr.append( $( '<td style="font-size:12px;color:#374151;max-width:200px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;">' ).text( item.preview ) );
			$tr.append( $( '<td class="tsosk-actions">' ).html( actions ) );
			$tbody.append( $tr );
		} );

		tsosk_oe_render_pagination( data );

		if ( tsosk_oe.autoOpen && items.length === 1 ) {
			tsosk_oe.autoOpen = false;
			$tbody.find( '.tsosk-oe-edit-btn' ).first().trigger( 'click' );
		}
	}

	function tsosk_oe_render_pagination( data ) {
		var pg  = data.page;
		var tot = data.total_pages;
		var html = '';
		if ( tot <= 1 ) {
			$( '#tsosk-oe-pagination-top, #tsosk-oe-pagination-bottom' ).html( '' );
			return;
		}
		html += '<span style="font-size:12px;color:#666;">' + tsosk.i18n.oe_page + ' ' + pg + ' ' + tsosk.i18n.oe_of + ' ' + tot + ' — ' + data.total + ' ' + tsosk.i18n.oe_options + '</span> ';
		if ( pg > 1 ) { html += '<button class="tsosk-oe-page-btn" data-page="' + (pg-1) + '">&#8592;</button>'; }
		var start = Math.max( 1, pg - 2 ), end = Math.min( tot, pg + 2 );
		for ( var i = start; i <= end; i++ ) {
			var cls = i === pg ? ' is-current' : '';
			html += '<button class="tsosk-oe-page-btn' + cls + '" data-page="' + i + '">' + i + '</button>';
		}
		if ( pg < tot ) { html += '<button class="tsosk-oe-page-btn" data-page="' + (pg+1) + '">&#8594;</button>'; }
		$( '#tsosk-oe-pagination-top, #tsosk-oe-pagination-bottom' ).html( html );
	}

	$( document ).on( 'click', '.tsosk-oe-page-btn', function () {
		var pg = parseInt( $( this ).data( 'page' ), 10 );
		if ( pg ) { tsosk_oe_search( tsosk_oe.lastSearch, pg ); }
	} );

	// Edit
	$( document ).on( 'click', '.tsosk-oe-edit-btn', function () {
		var $btn      = $( this );
		var name      = $btn.data( 'name' );
		var caution   = $btn.data( 'caution' );
		var isProtected = !! $btn.data( 'protected' );
		var nonce     = $btn.data( 'nonce' );
		var label     = isProtected ? tsosk.i18n.oe_view : tsosk.i18n.oe_edit;
		$btn.prop( 'disabled', true ).text( tsosk.i18n.running );
		ajaxPost( {
			action : 'tsosk_oe_get',
			data   : { nonce: nonce, name: name },
			success: function ( r ) {
				$btn.prop( 'disabled', false ).text( label );
				if ( ! r.success ) { alert( r.data || tsosk.i18n.error ); return; }
				tsosk_oe_open_editor( r.data, !! caution );
			},
			error: function () { $btn.prop( 'disabled', false ).text( label ); }
		} );
	} );

	function tsosk_oe_open_editor( data, caution ) {
		tsosk_oe.editingName = data.name;
		tsosk_oe.rawValue    = data.raw;
		tsosk_oe.prettyValue = data.pretty;
		tsosk_oe.readOnly    = !! data.protected;
		$( '#tsosk-oe-editing-name' ).text( data.name );
		$( '#tsosk-oe-editing-type' ).text( data.type );
		$( '#tsosk-oe-editing-autoload' ).val( ( data.autoload === 'yes' || data.autoload === 'on' || data.autoload === 'auto-on' || data.autoload === 'auto' ) ? 'yes' : 'no' );
		$( '#tsosk-oe-caution-banner' ).toggle( caution && ! tsosk_oe.readOnly );
		$( '#tsosk-oe-protected-banner' ).toggle( tsosk_oe.readOnly );
		$( '#tsosk-oe-serialized-note' ).toggle( data.type === 'serialized' );
		$( '#tsosk-oe-json-note' ).toggle( data.type === 'json' );
		$( '#tsosk-oe-raw-preview' ).hide();
		$( '#tsosk-oe-toggle-view' ).text( tsosk.i18n.oe_raw );
		if ( data.type === 'serialized' ) {
			$( '#tsosk-oe-value' ).val( data.raw );
			$( '#tsosk-oe-raw-preview' ).text( data.pretty ).show();
		} else {
			$( '#tsosk-oe-value' ).val( data.pretty );
		}
		$( '#tsosk-oe-value' ).prop( 'readonly', tsosk_oe.readOnly );
		$( '#tsosk-oe-editing-autoload' ).prop( 'disabled', tsosk_oe.readOnly );
		$( '#tsosk-oe-save-btn' ).prop( 'disabled', tsosk_oe.readOnly ).toggle( ! tsosk_oe.readOnly );
		$( '#tsosk-oe-save-msg' ).text( '' ).hide();
		$( '#tsosk-oe-editor' ).show();
		$( 'html, body' ).animate( { scrollTop: $( '#tsosk-oe-editor' ).offset().top - 60 }, 200 );
		if ( ! tsosk_oe.readOnly ) {
			$( '#tsosk-oe-value' ).trigger( 'focus' );
		}
	}

	$( document ).on( 'click', '#tsosk-oe-toggle-view', function () {
		var $pre = $( '#tsosk-oe-raw-preview' );
		if ( $pre.is( ':visible' ) ) { $pre.hide(); $( this ).text( tsosk.i18n.oe_raw ); }
		else { $pre.show(); $( this ).text( tsosk.i18n.oe_pretty ); }
	} );

	// Save
	$( document ).on( 'click', '#tsosk-oe-save-btn', function () {
		var $btn = $( this ), $msg = $( '#tsosk-oe-save-msg' );
		$btn.prop( 'disabled', true ).text( tsosk.i18n.running );
		ajaxPost( {
			action : 'tsosk_oe_save',
			data   : { nonce: $btn.data( 'nonce' ), name: tsosk_oe.editingName, value: $( '#tsosk-oe-value' ).val(), autoload: $( '#tsosk-oe-editing-autoload' ).val() },
			success: function ( r ) {
				if ( r.success ) { showMsg( $msg, r.data, 'ok' ); tsosk_oe_search( tsosk_oe.lastSearch, tsosk_oe.currentPage ); }
				else { showMsg( $msg, r.data, 'error' ); }
				$btn.prop( 'disabled', false ).text( tsosk.i18n.oe_save );
			},
			error: function () { showMsg( $msg, tsosk.i18n.error, 'error' ); $btn.prop( 'disabled', false ).text( tsosk.i18n.oe_save ); }
		} );
	} );

	$( document ).on( 'click', '#tsosk-oe-cancel-btn', function () {
		$( '#tsosk-oe-editor' ).hide();
		$( '#tsosk-oe-value' ).prop( 'readonly', false );
		$( '#tsosk-oe-editing-autoload' ).prop( 'disabled', false );
		$( '#tsosk-oe-save-btn' ).prop( 'disabled', false ).show();
	} );

	// Delete
	$( document ).on( 'click', '.tsosk-oe-delete-btn', function () {
		var $btn = $( this ), name = $btn.data( 'name' ), nonce = $btn.data( 'nonce' );
		var $msg = $( '#tsosk-oe-search-msg' );
		if ( ! confirm( tsosk.i18n.oe_confirm_del ) ) { return; }
		$btn.prop( 'disabled', true ).text( tsosk.i18n.running );
		ajaxPost( {
			action : 'tsosk_oe_delete',
			data   : { nonce: nonce, name: name },
			success: function ( r ) {
				if ( r.success ) { $btn.closest( 'tr' ).fadeOut( 300, function () { $( this ).remove(); } ); showMsg( $msg, r.data, 'ok' ); if ( tsosk_oe.editingName === name ) { $( '#tsosk-oe-editor' ).hide(); } }
				else { showMsg( $msg, r.data, 'error' ); $btn.prop( 'disabled', false ).text( tsosk.i18n.oe_delete ); }
			},
			error: function () { showMsg( $msg, tsosk.i18n.error, 'error' ); $btn.prop( 'disabled', false ).text( tsosk.i18n.oe_delete ); }
		} );
	} );

	// Add new option — value type hints
	function tsosk_oe_update_add_hint() {
		var hints = {
			text       : tsosk.i18n.oe_add_hint_text,
			integer    : tsosk.i18n.oe_add_hint_integer,
			json       : tsosk.i18n.oe_add_hint_json,
			serialized : tsosk.i18n.oe_add_hint_serialized,
		};
		var type = $( '#tsosk-oe-new-value-type' ).val() || 'text';
		$( '#tsosk-oe-new-value-hint' ).text( hints[ type ] || hints.text );
	}
	$( document ).on( 'change', '#tsosk-oe-new-value-type', tsosk_oe_update_add_hint );
	$( function () {
		if ( $( '#tsosk-oe-new-value-type' ).length ) {
			tsosk_oe_update_add_hint();
		}
	} );

	// Add new option
	$( document ).on( 'click', '#tsosk-oe-add-btn', function () {
		var $btn = $( this ), $msg = $( '#tsosk-oe-add-msg' );
		var name = $( '#tsosk-oe-new-name' ).val().trim();
		if ( ! name ) { showMsg( $msg, tsosk.i18n.oe_no_results, 'error' ); $( '#tsosk-oe-new-name' ).trigger( 'focus' ); return; }
		$btn.prop( 'disabled', true ).text( tsosk.i18n.running );
		ajaxPost( {
			action : 'tsosk_oe_add',
			data   : {
				nonce      : $btn.data( 'nonce' ),
				name       : name,
				value      : $( '#tsosk-oe-new-value' ).val(),
				value_type : $( '#tsosk-oe-new-value-type' ).val() || 'text',
				autoload   : $( '#tsosk-oe-new-autoload' ).val(),
			},
			success: function ( r ) {
				if ( r.success ) {
					showMsg( $msg, r.data, 'ok' );
					$( '#tsosk-oe-new-name, #tsosk-oe-new-value' ).val( '' );
					$( '#tsosk-oe-new-value-type' ).val( 'text' );
					tsosk_oe_update_add_hint();
					tsosk_oe_search( '', 1 );
				} else {
					showMsg( $msg, r.data, 'error' );
				}
				$btn.prop( 'disabled', false ).text( tsosk.i18n.oe_add );
			},
			error: function () { showMsg( $msg, tsosk.i18n.error, 'error' ); $btn.prop( 'disabled', false ).text( tsosk.i18n.oe_add ); }
		} );
	} );


	// ── Slug Manager ──────────────────────────────────────────────────────

	var tsosk_sm = {
		lastSearch  : '',
		currentPage : 1,
		totalPages  : 1,
		bulkPreview : null,
	};

	// Long-slug threshold currently set in the toolbar (same value the audit lists were built with).
	function tsoskSmThreshold() {
		return Math.max( 10, Math.min( 200, parseInt( $( '#tsosk-sm-threshold' ).val(), 10 ) || 75 ) );
	}

	function tsoskSmBuildBulkTable( changes, cols ) {
		if ( ! changes || ! changes.length ) {
			return null;
		}
		var $table = $( '<table class="tsosk-sm-bulk-summary-table"></table>' );
		var $thead = $( '<thead><tr></tr></thead>' );
		cols.forEach( function ( col ) {
			$thead.find( 'tr' ).append( $( '<th></th>' ).text( col.label ) );
		} );
		var $tbody = $( '<tbody></tbody>' );
		changes.forEach( function ( row ) {
			var $tr = $( '<tr></tr>' );
			cols.forEach( function ( col ) {
				var val = typeof col.value === 'function' ? col.value( row ) : ( row[ col.key ] || '' );
				var $td = $( '<td></td>' );
				if ( col.code ) {
					$td.addClass( 'tsosk-code' );
				}
				$td.text( val );
				$tr.append( $td );
			} );
			$tbody.append( $tr );
		} );
		$table.append( $thead, $tbody );
		return $table;
	}

	function tsoskSmRenderBulkSummary( $summary, data, mode ) {
		$summary.empty().show();
		var title = mode === 'preview'
			? ( tsosk.i18n.sm_bulk_preview_title || 'Bulk slug fix preview' )
			: ( tsosk.i18n.done || 'Done' );
		$summary.append( $( '<p><strong></strong>' ).text( title ) );
		if ( data.message ) {
			$summary.append( $( '<p></p>' ).text( data.message ) );
		}

		var changeCols = [
			{ label: tsosk.i18n.sm_bulk_col_post || 'Post', value: function ( row ) { return row.title || ( '#' + row.id ); } },
			{ label: tsosk.i18n.sm_bulk_col_before || 'Before', key: 'old_slug', code: true },
			{ label: tsosk.i18n.sm_bulk_col_after || 'After', key: 'new_slug', code: true },
		];
		var $changeTable = tsoskSmBuildBulkTable( data.changes || [], changeCols );
		if ( $changeTable ) {
			$summary.append( $changeTable );
		}

		var skipped = data.skipped || [];
		if ( skipped.length && Array.isArray( skipped ) && skipped[0] && skipped[0].reason ) {
			var skipCols = [
				{ label: tsosk.i18n.sm_bulk_col_post || 'Post', value: function ( row ) { return row.title || ( '#' + row.id ); } },
				{ label: tsosk.i18n.sm_bulk_col_reason || 'Reason', key: 'reason' },
			];
			var $skipTable = tsoskSmBuildBulkTable( skipped, skipCols );
			if ( $skipTable ) {
				$summary.append( $( '<p><strong></strong>' ).text( tsosk.i18n.sm_bulk_col_skipped || 'Skipped' ) );
				$summary.append( $skipTable );
			}
		}

		if ( data.errors && data.errors.length ) {
			var $errors = $( '<p class="description"></p>' );
			data.errors.forEach( function ( err ) {
				$errors.append( document.createTextNode( err ) ).append( '<br>' );
			} );
			$summary.append( $errors );
		}

		if ( data.redirect && tsosk.i18n.sm_redirect_note ) {
			$summary.append( $( '<p class="description"></p>' ).text( tsosk.i18n.sm_redirect_note ) );
		}

		if ( mode === 'preview' && ( data.changes || [] ).length ) {
			var $actions = $( '<div class="tsosk-sm-bulk-preview-actions"></div>' );
			$actions.append(
				$( '<button type="button" class="button button-primary" id="tsosk-sm-bulk-confirm"></button>' )
					.text( tsosk.i18n.sm_bulk_confirm_btn || 'Confirm changes' )
			);
			$actions.append(
				$( '<button type="button" class="button" id="tsosk-sm-bulk-preview-cancel"></button>' )
					.text( tsosk.i18n.cancel || 'Cancel' )
			);
			$summary.append( $actions );
		}

		$( 'html, body' ).animate( { scrollTop: $summary.offset().top - 80 }, 200 );
	}

	// ── Checkbox helpers ──────────────────────────────────────────────────

	$( document ).on( 'change', '.tsosk-sm-check-all', function () {
		var $table = $( this ).closest( 'table' );
		$table.find( '.tsosk-sm-row-check' ).prop( 'checked', $( this ).prop( 'checked' ) );
	} );

	$( document ).on( 'click', '#tsosk-sm-select-all-long', function () {
		$( '.tsosk-sm-row-check' ).prop( 'checked', true );
		$( '.tsosk-sm-check-all' ).prop( 'checked', true );
	} );

	$( document ).on( 'click', '#tsosk-sm-deselect-all-long', function () {
		$( '.tsosk-sm-row-check' ).prop( 'checked', false );
		$( '.tsosk-sm-check-all' ).prop( 'checked', false );
	} );

	// ── Edit / rename panel ───────────────────────────────────────────────

	$( document ).on( 'click', '.tsosk-sm-edit-btn', function () {
		var $btn     = $( this );
		var id       = $btn.data( 'id' );
		var title    = $btn.data( 'title' );
		var slug     = $btn.data( 'slug' );
		var len      = $btn.data( 'len' );
		var editLink = $btn.data( 'editLink' ) || $btn.data( 'edit-link' ) || '';

		$( '#tsosk-sm-rename-post-id' ).val( id );
		$( '#tsosk-sm-rename-title' ).text( title || tsosk.i18n.no_title );
		if ( editLink ) {
			$( '#tsosk-sm-rename-edit-link' ).attr( 'href', editLink ).show();
		} else {
			$( '#tsosk-sm-rename-edit-link' ).hide();
		}
		$( '#tsosk-sm-rename-current' ).text( slug );
		$( '#tsosk-sm-rename-len' ).text( len );
		$( '#tsosk-sm-rename-new' ).val( slug );
		$( '#tsosk-sm-rename-new-len' ).text( len + ' ' + tsosk.i18n.sm_chars );
		$( '#tsosk-sm-rename-msg' ).text( '' ).removeClass( 'is-error' ).hide();
		$( '#tsosk-sm-rename-urls' ).empty().hide();

		$( '#tsosk-sm-rename-panel' ).show();
		$( 'html, body' ).animate(
			{ scrollTop: $( '#tsosk-sm-rename-panel' ).offset().top - 60 }, 200
		);
		$( '#tsosk-sm-rename-new' ).trigger( 'focus' ).trigger( 'select' );
	} );

	// Live character count while typing
	$( document ).on( 'input', '#tsosk-sm-rename-new', function () {
		var len = $( this ).val().length;
		var $lbl = $( '#tsosk-sm-rename-new-len' );
		var thr   = tsoskSmThreshold();
		var color = len > thr ? '#b45309' : ( len > Math.round( thr * 0.6 ) ? '#646970' : '#2271b1' );
		$lbl.text( len + ' ' + tsosk.i18n.sm_chars ).css( 'color', color );
	} );

	$( document ).on( 'click', '#tsosk-sm-rename-cancel', function () {
		$( '#tsosk-sm-rename-panel' ).hide();
	} );

	$( document ).on( 'click', '#tsosk-sm-rename-save', function () {
		var $btn      = $( this );
		var $msg      = $( '#tsosk-sm-rename-msg' );
		var nonce     = $btn.data( 'nonce' );
		var postId    = $( '#tsosk-sm-rename-post-id' ).val();
		var newSlug   = $( '#tsosk-sm-rename-new' ).val().trim();
		var doRedir   = $( '#tsosk-sm-rename-redirect' ).prop( 'checked' ) ? 1 : 0;

		if ( ! newSlug ) {
			showMsg( $msg, tsosk.i18n.error, 'error' );
			return;
		}

		$btn.prop( 'disabled', true ).text( tsosk.i18n.running );

		ajaxPost( {
			action : 'tsosk_sm_rename',
			data   : { nonce: nonce, post_id: postId, new_slug: newSlug, auto_redirect: doRedir },
			success: function ( r ) {
				if ( r.success ) {
					// The server reports the slug WordPress really saved (it may differ from what was typed).
					var saved = String( r.data.new_slug );
					var thr   = tsoskSmThreshold();
					showMsg( $msg, r.data.message, 'ok' );
					// Update the row in the table.
					var $row = $( '#tsosk-sm-row-' + postId );
					$row.find( '.tsosk-sm-slug-col a' ).text( saved ).attr( { href: r.data.new_permalink, title: saved } );
					$row.find( 'td[data-label]' ).has( 'span[style*="font-weight:600"]' ).find( 'span' ).first()
						.text( saved.length ).css( 'color', saved.length > thr ? '#b45309' : '' );
					$row.toggleClass( 'tsosk-row-warn', saved.length > thr );
					$( '#tsosk-sm-rename-current' ).text( saved );
					$( '#tsosk-sm-rename-len' ).text( saved.length );
					$( '#tsosk-sm-rename-new' ).val( saved );
					$( '#tsosk-sm-rename-new-len' ).text( saved.length + ' ' + tsosk.i18n.sm_chars );
					// Keep the Rename buttons in sync so reopening the panel shows the new slug.
					$( '#tsosk-sm-row-' + postId + ' .tsosk-sm-edit-btn, #tsosk-sm-tr-' + postId + ' .tsosk-sm-edit-btn' )
						.attr( { 'data-slug': saved, 'data-len': saved.length } )
						.data( { slug: saved, len: saved.length } );
					// Also update search results row if present
					$( '#tsosk-sm-tr-' + postId + ' .tsosk-sm-slug-cell a' ).text( saved ).attr( { href: r.data.new_permalink, title: saved } );
					$( '#tsosk-sm-tr-' + postId + ' .tsosk-sm-len-cell' ).text( saved.length )
						.attr( 'style', saved.length > thr ? 'font-weight:600;color:#b45309;' : '' );
					// Show exactly which URL moved where.
					if ( r.data.old_permalink && tsosk.i18n.sm_url_moved ) {
						$( '#tsosk-sm-rename-urls' )
							.text( tsosk.i18n.sm_url_moved.replace( '%1$s', r.data.old_permalink ).replace( '%2$s', r.data.new_permalink ) )
							.show();
					}
				} else {
					showMsg( $msg, r.data, 'error' );
				}
				$btn.prop( 'disabled', false ).text( tsosk.i18n.sm_save_slug );
			},
			error: function () {
				showMsg( $msg, tsosk.i18n.error, 'error' );
				$btn.prop( 'disabled', false ).text( tsosk.i18n.sm_save_slug );
			}
		} );
	} );

	// ── Bulk Fix ──────────────────────────────────────────────────────────

	$( document ).on( 'click', '#tsosk-sm-bulk-fix', function () {
		var $btn    = $( this );
		var $msg    = $( '#tsosk-sm-bulk-msg' );
		var nonce   = $btn.data( 'nonce' );
		var ids     = $( '.tsosk-sm-row-check:checked' ).map( function () {
			return $( this ).val();
		} ).get();

		if ( ids.length === 0 ) {
			showMsg( $msg, tsosk.i18n.sm_no_posts, 'error' );
			return;
		}

		var doRedir   = $( '#tsosk-sm-auto-redirect' ).prop( 'checked' ) ? 1 : 0;
		var threshold = parseInt( $( '#tsosk-sm-threshold' ).val(), 10 ) || 75;

		tsosk_sm.bulkPreview = { ids: ids, threshold: threshold, doRedir: doRedir, nonce: nonce };

		$btn.prop( 'disabled', true ).text( tsosk.i18n.running );
		showMsg( $msg, '', '' );

		ajaxPost( {
			action : 'tsosk_sm_bulk_preview',
			data   : { nonce: nonce, post_ids: ids, threshold: threshold, auto_redirect: doRedir },
			success: function ( r ) {
				if ( r.success ) {
					var data = r.data || {};
					var $summary = $( '#tsosk-sm-bulk-summary' );
					if ( $summary.length ) {
						tsoskSmRenderBulkSummary( $summary, data, 'preview' );
					}
					if ( ! ( data.changes || [] ).length ) {
						showMsg( $msg, data.message || tsosk.i18n.sm_no_posts, 'error' );
					}
				} else {
					showMsg( $msg, r.data, 'error' );
				}
			},
			error: function () {
				showMsg( $msg, tsosk.i18n.error, 'error' );
			},
			complete: function () {
				$btn.prop( 'disabled', false ).text( tsosk.i18n.sm_bulk_fix );
			}
		} );
	} );

	$( document ).on( 'click', '#tsosk-sm-bulk-preview-cancel', function () {
		tsosk_sm.bulkPreview = null;
		$( '#tsosk-sm-bulk-summary' ).empty().hide();
		$( '#tsosk-sm-bulk-msg' ).empty();
	} );

	$( document ).on( 'click', '#tsosk-sm-bulk-confirm', function () {
		var preview = tsosk_sm.bulkPreview;
		if ( ! preview || ! preview.ids || ! preview.ids.length ) {
			return;
		}

		var $btn  = $( '#tsosk-sm-bulk-fix' );
		var $msg  = $( '#tsosk-sm-bulk-msg' );
		var $conf = $( this );

		$conf.prop( 'disabled', true );
		$btn.prop( 'disabled', true ).text( tsosk.i18n.running );

		ajaxPost( {
			action : 'tsosk_sm_bulk_fix',
			data   : {
				nonce         : preview.nonce,
				post_ids      : preview.ids,
				threshold     : preview.threshold,
				auto_redirect : preview.doRedir,
			},
			success: function ( r ) {
				if ( r.success ) {
					var data    = r.data || {};
					var message = data.message || tsosk.i18n.done;
					showMsg( $msg, message, 'ok' );

					var $summary = $( '#tsosk-sm-bulk-summary' );
					if ( $summary.length ) {
						tsoskSmRenderBulkSummary( $summary, data, 'result' );
					}

					( data.changes || [] ).forEach( function ( row ) {
						var $slugCell = $( '#tsosk-sm-row-' + row.id + ' .tsosk-sm-slug-col a' );
						if ( $slugCell.length ) {
							$slugCell.text( row.new_slug ).attr( 'title', row.new_slug );
						}
						$( '#tsosk-sm-row-' + row.id ).removeClass( 'tsosk-row-warn' );
						$( '#tsosk-sm-row-' + row.id + ' .tsosk-sm-row-check' ).prop( 'checked', false );
					} );
					tsosk_sm.bulkPreview = null;
				} else {
					showMsg( $msg, r.data, 'error' );
				}
			},
			error: function () {
				showMsg( $msg, tsosk.i18n.error, 'error' );
			},
			complete: function () {
				$conf.prop( 'disabled', false );
				$btn.prop( 'disabled', false ).text( tsosk.i18n.sm_bulk_fix );
			}
		} );
	} );

	// ── Search & Edit tab ─────────────────────────────────────────────────

	var tsosk_sm_search_seq = 0;
	function tsosk_sm_search( q, page ) {
		tsosk_sm.lastSearch  = q;
		tsosk_sm.currentPage = page || 1;
		var nonce     = $( '#tsosk-sm-search-btn' ).data( 'nonce' );
		var $msg      = $( '#tsosk-sm-search-msg' );
		var postType  = $( '#tsosk-sm-post-type' ).val();
		var reqId     = ++tsosk_sm_search_seq;

		$( '#tsosk-sm-search-btn, #tsosk-sm-load-all' ).prop( 'disabled', true );
		$( '#tsosk-sm-search-placeholder' ).hide();

		ajaxPost( {
			action : 'tsosk_sm_search',
			data   : { nonce: nonce, q: q, post_type: postType, page: tsosk_sm.currentPage },
			success: function ( r ) {
				if ( reqId !== tsosk_sm_search_seq ) {
					return;
				}
				if ( r.success ) {
					tsosk_sm.totalPages = r.data.total_pages;
					tsosk_sm_render_results( r.data );
					$( '#tsosk-sm-search-results' ).show();
				} else {
					showMsg( $msg, r.data || tsosk.i18n.error, 'error' );
				}
				$( '#tsosk-sm-search-btn, #tsosk-sm-load-all' ).prop( 'disabled', false );
			},
			error: function () {
				if ( reqId !== tsosk_sm_search_seq ) {
					return;
				}
				showMsg( $msg, tsosk.i18n.error, 'error' );
				$( '#tsosk-sm-search-btn, #tsosk-sm-load-all' ).prop( 'disabled', false );
			}
		} );
	}

	function tsosk_sm_render_results( data ) {
		var $tbody   = $( '#tsosk-sm-search-tbody' );
		var nonce    = $( '#tsosk-sm-search-btn' ).data( 'nonce' );
		var items    = data.items || [];

		$tbody.empty();

		if ( ! items.length ) {
			$tbody.append( '<tr><td colspan="6" style="text-align:center;color:#646970;">' +
				tsosk.i18n.sm_no_posts + '</td></tr>' );
			$( '#tsosk-sm-pagination-top, #tsosk-sm-pagination-bottom' ).empty();
			return;
		}

		var thr = tsoskSmThreshold();
		$.each( items, function ( i, item ) {
			var $tr = $( '<tr id="tsosk-sm-tr-' + item.id + '"></tr>' );
			var $titleCell = $( '<td></td>' ).attr( 'data-label', tsosk.i18n.sm_col_title || 'Title' );
			$titleCell.append( $( '<strong></strong>' ).text( item.title || tsosk.i18n.no_title ) );
			if ( item.edit_link ) {
				$titleCell.append( ' ' ).append(
					$( '<a target="_blank" rel="noopener noreferrer" class="tsosk-sm-edit-link"></a>' )
						.attr( 'href', item.edit_link )
						.text( tsosk.i18n.edit + ' ↗' )
				);
			}
			if ( item.date ) {
				$titleCell.append( $( '<span class="tsosk-sm-meta"></span>' ).text( item.date ) );
			}
			$tr.append( $titleCell );
			$tr.append( $( '<td class="tsosk-code" style="font-size:12px;"></td>' ).attr( 'data-label', tsosk.i18n.sm_col_type || 'Type' ).text( item.type ) );
			$tr.append( $( '<td></td>' ).attr( 'data-label', tsosk.i18n.sm_col_status || 'Status' ).text( item.status ) );
			var $slugLink = $( '<a target="_blank" rel="noopener noreferrer"></a>' )
				.attr( 'href', item.permalink )
				.attr( 'title', item.slug )
				.text( item.slug );
			var $slugCell = $( '<td class="tsosk-code tsosk-sm-slug-cell tsosk-sm-slug-col"></td>' ).attr( 'data-label', tsosk.i18n.sm_col_slug || 'Slug' ).append( $slugLink );
			if ( item.path && item.path !== item.slug ) {
				$slugCell.append( $( '<span class="tsosk-sm-meta"></span>' ).text( '/' + item.path + '/' ) );
			}
			$tr.append( $slugCell );
			$tr.append( $( '<td class="tsosk-sm-len-cell"></td>' ).attr( { 'data-label': tsosk.i18n.sm_col_chars || 'Chars', style: item.len > thr ? 'font-weight:600;color:#b45309;' : '' } ).text( item.len ) );
			var $btn = $( '<button type="button" class="button button-small tsosk-sm-edit-btn"></button>' )
				.text( tsosk.i18n.sm_rename )
				.data( {
					id       : item.id,
					title    : item.title,
					slug     : item.slug,
					len      : item.len,
					editLink : item.edit_link || '',
					nonce    : nonce,
				} );
			$tr.append( $( '<td></td>' ).attr( 'data-label', tsosk.i18n.sm_col_actions || 'Actions' ).append( $btn ) );
			$tbody.append( $tr );
		} );

		// Pagination
		$( '#tsosk-sm-pagination-top, #tsosk-sm-pagination-bottom' ).each( function () {
			tsosk_sm_render_pagination( $( this ), data );
		} );
	}

	function tsosk_sm_render_pagination( $el, data ) {
		$el.empty();
		if ( data.total_pages <= 1 ) { return; }

		$el.append( '<span style="font-size:12px;color:#646970;">' +
			tsosk.i18n.oe_page + ' ' + data.page + ' ' + tsosk.i18n.oe_of + ' ' + data.total_pages +
			' &mdash; ' + data.total + ' ' + tsosk.i18n.sm_total_items + '</span>' );

		if ( data.page > 1 ) {
			$el.append( ' <button class="tsosk-oe-page-btn tsosk-sm-page-btn" data-page="' +
				( data.page - 1 ) + '">&larr; ' + tsosk.i18n.previous + '</button>' );
		}
		if ( data.page < data.total_pages ) {
			$el.append( ' <button class="tsosk-oe-page-btn tsosk-sm-page-btn" data-page="' +
				( data.page + 1 ) + '">' + tsosk.i18n.next + ' &rarr;</button>' );
		}
	}

	// Threshold and post type filter the audit lists on the server, so reload with them in the URL.
	// On the Search tab only the post type applies, and it is applied through the search request.
	$( document ).on( 'change', '#tsosk-sm-threshold, #tsosk-sm-post-type', function () {
		if ( $( '#tsosk-sm-search-input' ).length ) {
			if ( 'tsosk-sm-post-type' === this.id && $( '#tsosk-sm-search-results' ).is( ':visible' ) ) {
				tsosk_sm_search( tsosk_sm.lastSearch, 1 );
			}
			return;
		}
		var url  = new window.URL( window.location.href );
		var type = String( $( '#tsosk-sm-post-type' ).val() || '' );
		if ( type ) {
			url.searchParams.set( 'sm_type', type );
		} else {
			url.searchParams.delete( 'sm_type' );
		}
		url.searchParams.set( 'sm_threshold', String( tsoskSmThreshold() ) );
		window.location.href = url.toString();
	} );

	$( document ).on( 'click', '.tsosk-sm-page-btn', function () {
		tsosk_sm_search( tsosk_sm.lastSearch, parseInt( $( this ).data( 'page' ), 10 ) );
	} );

	$( document ).on( 'click', '#tsosk-sm-search-btn', function () {
		tsosk_sm_search( $( '#tsosk-sm-search-input' ).val().trim(), 1 );
	} );

	$( document ).on( 'keydown', '#tsosk-sm-search-input', function ( e ) {
		if ( e.key === 'Enter' ) { tsosk_sm_search( $( this ).val().trim(), 1 ); }
	} );

	$( document ).on( 'click', '#tsosk-sm-load-all', function () {
		$( '#tsosk-sm-search-input' ).val( '' );
		tsosk_sm_search( '', 1 );
	} );

	$( function () {
		if ( $( '#tsosk-sm-search-btn' ).length && window.location.search.indexOf( 'sm_tab=search' ) !== -1 ) {
			tsosk_sm_search( '', 1 );
		}
	} );


	// ── Mobile tools menu ─────────────────────────────────────────────────────

	function tsoskMobileNavQuery() {
		return window.matchMedia( '(max-width: 782px)' );
	}

	function tsoskSetMobileNavOpen( open ) {
		var $wrap = $( '.tsosk-wrap' );
		var $toggle = $( '#tsosk-mobile-nav-toggle' );
		$wrap.toggleClass( 'tsosk-mobile-nav-open', open );
		if ( $toggle.length ) {
			$toggle.attr( 'aria-expanded', open ? 'true' : 'false' );
		}
	}

	$( document ).on( 'click', '#tsosk-mobile-nav-toggle', function () {
		if ( ! tsoskMobileNavQuery().matches ) {
			return;
		}
		var open = ! $( '.tsosk-wrap' ).hasClass( 'tsosk-mobile-nav-open' );
		tsoskSetMobileNavOpen( open );
	} );

	$( document ).on( 'click', '.tsosk-sidebar-tools .tsosk-nav-item', function () {
		if ( tsoskMobileNavQuery().matches ) {
			tsoskSetMobileNavOpen( false );
		}
	} );

	$( window ).on( 'resize.tsoskMobileNav', function () {
		if ( ! tsoskMobileNavQuery().matches ) {
			tsoskSetMobileNavOpen( false );
		}
	} );


	// ══ Sidebar Organiser ════════════════════════════════════════════════════

	( function () {
		var $sidebars    = $( '#tsosk-sidebars' );
		var $sidebar     = $( '#tsosk-sidebar-nav' );
		var $favSidebar  = $( '#tsosk-sidebar-favorites' );
		var $favList     = $( '#tsosk-favorites-list' );
		var $navList     = $( '#tsosk-nav-list' );
		var $editBar     = $( '#tsosk-sidebar-edit-bar' );
		var $actionsBar  = $( '#tsosk-sidebar-actions' );
		var $btnOrganise = $( '#tsosk-sidebar-organise' );
		var $btnSave     = $( '#tsosk-sidebar-save' );
		var $btnReset    = $( '#tsosk-sidebar-reset' );
		var $btnCancel   = $( '#tsosk-sidebar-cancel' );

		if ( ! $sidebar.length ) { return; }

		var nonce            = $sidebar.data( 'nonce' ) || $favSidebar.data( 'nonce' );
		var originalListHtml = null;
		var originalFavHtml  = null;
		var groupLabels      = tsosk.sidebar_groups || {};
		var groupOrder       = tsosk.sidebar_group_order || Object.keys( groupLabels );

		function rowSlug( $row ) {
			return $row.attr( 'data-slug' ) || '';
		}

		function destroyDragReorder() {
			if ( dragState ) {
				finishDrag( null, true );
			}
			$navList.find( '.tsosk-nav-edit-section-list' ).off( '.tsoskNavReorder' );
			$favList.off( '.tsoskNavReorder' );
			$( document ).off( '.tsoskNavReorder' );
			$( window ).off( '.tsoskNavReorder' );
			$( 'body > .tsosk-nav-drag-ghost' ).remove();
		}

		var dragState = null;

		function pointInRect( x, y, rect ) {
			return x >= rect.left && x <= rect.right && y >= rect.top && y <= rect.bottom;
		}

		function sectionGroupForList( $list ) {
			return $list.closest( '.tsosk-nav-edit-section' ).attr( 'data-group' ) || 'site';
		}

		function findTargetSectionList( clientX, clientY ) {
			var $target = null;

			$navList.find( '.tsosk-nav-edit-section' ).each( function () {
				var rect = this.getBoundingClientRect();
				if ( pointInRect( clientX, clientY, rect ) ) {
					$target = $( this ).find( '.tsosk-nav-edit-section-list' ).first();
					return false;
				}
			} );

			return $target;
		}

		function applyRowSection( $row, $list ) {
			if ( ! $row.length || ! $list || ! $list.length ) {
				return;
			}
			$row.attr( 'data-group', sectionGroupForList( $list ) );
		}

		function insertRowAtClientY( $list, $row, clientY ) {
			if ( ! $list.length || ! $row.length ) {
				return;
			}

			var inserted = false;

			$list.children( '.tsosk-nav-row' ).each( function () {
				var rect = this.getBoundingClientRect();
				if ( clientY < rect.top + ( rect.height / 2 ) ) {
					$( this ).before( $row );
					inserted = true;
					return false;
				}
			} );

			if ( ! inserted ) {
				$list.append( $row );
			}
		}

		function restoreRowOrigin( state ) {
			if ( ! state.$row || ! state.$row.length || ! state.$sourceList.length ) {
				return;
			}

			if ( state.originNext && document.contains( state.originNext ) ) {
				$( state.originNext ).before( state.$row );
				return;
			}

			state.$sourceList.append( state.$row );
		}

		function movePlaceholder( $list, clientY ) {
			if ( ! dragState || ! dragState.$placeholder ) {
				return;
			}
			var $placeholder = dragState.$placeholder;
			var $rows        = $list.children( '.tsosk-nav-row' );
			var inserted     = false;

			$rows.each( function () {
				var rect = this.getBoundingClientRect();
				var mid  = rect.top + ( rect.height / 2 );
				if ( clientY < mid ) {
					$( this ).before( $placeholder );
					inserted = true;
					return false;
				}
			} );

			if ( ! inserted ) {
				$list.append( $placeholder );
			}
		}

		function finishDrag( e, cancel ) {
			if ( ! dragState ) {
				return;
			}

			var state        = dragState;
			var clientY      = ( e && typeof e.clientY === 'number' ) ? e.clientY : state.lastClientY;
			var droppedOnFav = false;

			dragState = null;

			$( document ).off( '.tsoskNavReorder' );
			$( window ).off( '.tsoskNavReorder' );
			$navList.find( '.tsosk-nav-edit-section-list' ).removeClass( 'is-drop-hover' );
			$sidebars.removeClass( 'tsosk-nav-dragging' );
			$favList.removeClass( 'is-drop-target' );

			if ( state.$ghost && state.$ghost.length ) {
				state.$ghost.remove();
			}

			if ( state.$placeholder && state.$placeholder.length ) {
				state.$placeholder.remove();
			}

			if ( cancel || ! state.$row || ! state.$row.length ) {
				restoreRowOrigin( state );
				return;
			}

			if ( ! state.fromFavorites && $favList.length && typeof clientY === 'number' ) {
				droppedOnFav = pointInRect(
					e ? e.clientX : state.lastClientX,
					clientY,
					$favList[0].getBoundingClientRect()
				);
			}

			if ( state.fromFavorites ) {
				insertRowAtClientY( $favList, state.$row, clientY );
			} else {
				var $targetList = state.$targetList && state.$targetList.length
					? state.$targetList
					: state.$sourceList;

				if ( typeof clientY === 'number' ) {
					movePlaceholder( $targetList, clientY );
				}

				insertRowAtClientY( $targetList, state.$row, clientY );
				applyRowSection( state.$row, $targetList );
			}

			if ( droppedOnFav ) {
				addRowToFavorites( state.$row );
			}
		}

		function onDragMove( e ) {
			if ( ! dragState ) {
				return;
			}
			e.preventDefault();

			dragState.lastClientY = e.clientY;
			dragState.lastClientX = e.clientX;
			dragState.$ghost.css( 'top', ( e.clientY - dragState.offsetY ) + 'px' );

			if ( dragState.fromFavorites ) {
				movePlaceholder( $favList, e.clientY );
				return;
			}

			var $targetList = findTargetSectionList( e.clientX, e.clientY ) || dragState.$sourceList;
			dragState.$targetList = $targetList;
			$navList.find( '.tsosk-nav-edit-section-list' ).removeClass( 'is-drop-hover' );
			$targetList.addClass( 'is-drop-hover' );
			movePlaceholder( $targetList, e.clientY );

			if ( $favList.length ) {
				$favList.toggleClass(
					'is-drop-target',
					pointInRect( e.clientX, e.clientY, $favList[0].getBoundingClientRect() )
				);
			}
		}

		function onDragEnd( e ) {
			if ( ! dragState ) {
				return;
			}
			e.preventDefault();
			e.stopPropagation();
			finishDrag( e, false );
		}

		function startRowDrag( $list, $row, e, fromFavorites ) {
			if ( dragState ) {
				finishDrag( null, true );
			}

			e.preventDefault();
			e.stopPropagation();

			var rect         = $row[0].getBoundingClientRect();
			var originNext   = $row.next( '.tsosk-nav-row' )[0] || null;
			var $placeholder = $( '<div class="tsosk-sortable-placeholder" aria-hidden="true"></div>' );
			$placeholder.height( $row.outerHeight() );
			$row.before( $placeholder );
			$row.detach();

			var $ghost = $row.clone();
			$ghost.addClass( 'tsosk-nav-drag-ghost' );
			$ghost.find( '.tsosk-add-fav' ).remove();
			$( 'body' ).append( $ghost );
			$ghost.css( {
				position      : 'fixed',
				left          : rect.left + 'px',
				top           : rect.top + 'px',
				width         : rect.width + 'px',
				zIndex        : 100100,
				pointerEvents : 'none',
				margin        : 0
			} );

			dragState = {
				$row         : $row,
				$sourceList  : $list,
				$targetList  : $list,
				$placeholder : $placeholder,
				$ghost       : $ghost,
				offsetY      : e.clientY - rect.top,
				lastClientY  : e.clientY,
				lastClientX  : e.clientX,
				originNext   : originNext,
				fromFavorites: !! fromFavorites
			};

			$sidebars.addClass( 'tsosk-nav-dragging' );
			$favList.addClass( 'is-drop-target' );

			$( document )
				.on( 'pointermove.tsoskNavReorder mousemove.tsoskNavReorder touchmove.tsoskNavReorder', onDragMove );
			$( window )
				.on( 'pointerup.tsoskNavReorder pointercancel.tsoskNavReorder mouseup.tsoskNavReorder touchend.tsoskNavReorder', onDragEnd );
		}

		function initDragReorder() {
			$navList.find( '.tsosk-nav-edit-section-list' ).each( function () {
				var $list = $( this );
				$list.on( 'pointerdown.tsoskNavReorder', '.tsosk-drag-handle', function ( e ) {
					if ( ! $sidebars.hasClass( 'tsosk-editing' ) ) {
						return;
					}
					if ( 'mouse' === e.pointerType && 0 !== e.button ) {
						return;
					}
					var $row = $( this ).closest( '.tsosk-nav-row' );
					if ( ! $row.length ) {
						return;
					}
					startRowDrag( $list, $row, e, false );
				} );
			} );

			if ( ! $favList.length ) {
				return;
			}

			$favList.on( 'pointerdown.tsoskNavReorder', '.tsosk-drag-handle', function ( e ) {
				if ( ! $favSidebar.hasClass( 'tsosk-editing' ) ) {
					return;
				}
				if ( 'mouse' === e.pointerType && 0 !== e.button ) {
					return;
				}
				var $row = $( this ).closest( '.tsosk-nav-row' );
				if ( ! $row.length ) {
					return;
				}
				startRowDrag( $favList, $row, e, true );
			} );
		}

		function dedupeFavorite( $row ) {
			var slug = rowSlug( $row );
			if ( ! slug ) {
				$row.remove();
				return false;
			}
			var dupes = 0;
			$favList.find( '.tsosk-nav-row' ).each( function () {
				if ( rowSlug( $( this ) ) === slug ) {
					dupes += 1;
				}
			} );
			if ( dupes > 1 ) {
				$row.remove();
				return false;
			}
			$row.addClass( 'tsosk-fav-row' );
			$row.find( '.tsosk-hide-tab' ).remove();
			if ( ! $row.find( '.tsosk-remove-fav' ).length ) {
				$row.append(
					$( '<button type="button" class="tsosk-remove-fav"></button>' )
						.attr( 'title', tsosk.i18n.favorites_remove )
						.text( '✕' )
				);
			}
			updateFavoritesEmptyState();
			return true;
		}

		function updateFavoritesEmptyState() {
			var hasRows = $favList.find( '.tsosk-nav-row' ).length > 0;
			$favList.toggleClass( 'is-empty', ! hasRows );
		}

		function isFavoriteSlug( slug ) {
			var found = false;
			$favList.find( '.tsosk-nav-row' ).each( function () {
				if ( rowSlug( $( this ) ) === slug ) {
					found = true;
					return false;
				}
			} );
			return found;
		}

		function addRowToFavorites( $sourceRow ) {
			var slug = rowSlug( $sourceRow );
			if ( ! slug || isFavoriteSlug( slug ) ) {
				return false;
			}
			var $clone = $sourceRow.clone();
			$clone.removeClass( 'tsosk-dragging tsosk-drop-before tsosk-drop-after ui-sortable-helper' );
			$clone.find( '.tsosk-add-fav' ).remove();
			$favList.append( $clone );
			dedupeFavorite( $clone );
			return true;
		}

		function attachAddFavoriteButtons() {
			$navList.find( '.tsosk-nav-edit-section-list .tsosk-nav-row' ).each( function () {
				var $row = $( this );
				if ( $row.find( '.tsosk-add-fav' ).length ) {
					return;
				}
				$row.find( '.tsosk-hide-tab' ).before(
					$( '<button type="button" class="tsosk-add-fav" aria-label="★"></button>' )
						.attr( 'title', tsosk.i18n.favorites_add || 'Add to favorites' )
						.append( $( '<span class="dashicons dashicons-star-filled" aria-hidden="true"></span>' ) )
				);
			} );
		}

		/**
		 * Rebuild nav list into category blocks (all groups shown, including empty drop zones).
		 */
		function buildEditSections() {
			var buckets = {};

			groupOrder.forEach( function ( gid ) {
				buckets[ gid ] = [];
			} );

			$navList.find( '.tsosk-nav-row' ).each( function () {
				var $row = $( this );
				var gid  = $row.attr( 'data-group' ) || 'site';
				if ( ! buckets[ gid ] ) {
					buckets[ gid ] = [];
				}
				buckets[ gid ].push( $row );
			} );

			$navList.empty();

			groupOrder.forEach( function ( gid ) {
				var title = groupLabels[ gid ] || gid;
				var $sec  = $( '<div class="tsosk-nav-edit-section"></div>' ).attr( 'data-group', gid );
				$sec.append( $( '<div class="tsosk-nav-edit-section-title"></div>' ).text( title ) );
				var $list = $( '<div class="tsosk-nav-edit-section-list"></div>' );
				( buckets[ gid ] || [] ).forEach( function ( $row ) {
					$list.append( $row );
				} );
				$sec.append( $list );
				$navList.append( $sec );
			} );

			Object.keys( buckets ).forEach( function ( gid ) {
				if ( -1 !== groupOrder.indexOf( gid ) ) {
					return;
				}
				var title = groupLabels[ gid ] || gid;
				var $sec  = $( '<div class="tsosk-nav-edit-section"></div>' ).attr( 'data-group', gid );
				$sec.append( $( '<div class="tsosk-nav-edit-section-title"></div>' ).text( title ) );
				var $list = $( '<div class="tsosk-nav-edit-section-list"></div>' );
				buckets[ gid ].forEach( function ( $row ) {
					$list.append( $row );
				} );
				$sec.append( $list );
				$navList.append( $sec );
			} );
		}

		function getTabGroups() {
			var groups = {};

			$navList.find( '.tsosk-nav-edit-section' ).each( function () {
				var groupId = $( this ).attr( 'data-group' ) || 'site';
				$( this ).find( '.tsosk-nav-row' ).each( function () {
					var slug = rowSlug( $( this ) );
					if ( slug ) {
						groups[ slug ] = groupId;
					}
				} );
			} );

			return groups;
		}

		/* ── snapshot of current order ─────────────────────────────── */
		function getOrder() {
			var order = [];
			$navList.find( '.tsosk-nav-edit-section' ).each( function () {
				$( this ).find( '.tsosk-nav-row' ).each( function () {
					var slug = rowSlug( $( this ) );
					if ( slug ) {
						order.push( slug );
					}
				} );
			} );
			if ( order.length ) {
				return order;
			}
			return $navList.find( '.tsosk-nav-row' ).map( function () {
				return rowSlug( $( this ) );
			} ).get().filter( Boolean );
		}
		function getHidden() {
			return $navList.find( '.tsosk-nav-row.tsosk-nav-hidden' ).map( function () {
				return rowSlug( $( this ) );
			} ).get().filter( Boolean );
		}

		function getFavorites() {
			return $favList.find( '.tsosk-nav-row' ).map( function () {
				return rowSlug( $( this ) );
			} ).get().filter( Boolean );
		}

		/* ── Enter edit mode ────────────────────────────────────────── */
		$btnOrganise.on( 'click', function () {
			originalListHtml = $navList.html();
			originalFavHtml  = $favList.html();
			$sidebars.addClass( 'tsosk-editing' );
			$favSidebar.addClass( 'tsosk-editing' );
			$actionsBar.hide();
			$editBar.show();
			buildEditSections();
			attachAddFavoriteButtons();
			initDragReorder();
			updateFavoritesEmptyState();
		} );

		$( document ).on( 'click', '.tsosk-add-fav', function ( e ) {
			e.preventDefault();
			e.stopPropagation();
			if ( ! $sidebars.hasClass( 'tsosk-editing' ) ) {
				return;
			}
			addRowToFavorites( $( this ).closest( '.tsosk-nav-row' ) );
		} );

		/* ── Cancel edit mode ───────────────────────────────────────── */
		$btnCancel.on( 'click', function () {
			exitEditMode( false );
		} );

		function exitEditMode( keepChanges ) {
			destroyDragReorder();
			if ( ! keepChanges ) {
				if ( null !== originalListHtml ) {
					$navList.html( originalListHtml );
				}
				if ( null !== originalFavHtml ) {
					$favList.html( originalFavHtml );
				}
			}
			$sidebars.removeClass( 'tsosk-editing' );
			$favSidebar.removeClass( 'tsosk-editing' );
			$editBar.hide();
			$actionsBar.show();
			originalListHtml = null;
			originalFavHtml  = null;
			updateFavoritesEmptyState();
		}

		/* ── Save ───────────────────────────────────────────────────── */
		$btnSave.on( 'click', function () {
			var $btn = $( this );
			$btn.prop( 'disabled', true ).text( '…' );

			ajaxPost( {
				action : 'tsosk_save_sidebar_order',
				data   : {
					nonce         : nonce,
					order_json    : JSON.stringify( getOrder() ),
					groups_json   : JSON.stringify( getTabGroups() ),
					hidden_json   : JSON.stringify( getHidden() ),
					favorites_json: JSON.stringify( getFavorites() )
				},
				success: function ( r ) {
					if ( r.success ) {
						// Reload so PHP rebuilds grouped sidebar from saved flat order.
						window.location.reload();
						return;
					} else {
						alert( ( r.data || tsosk.i18n.error ) );
					}
					$btn.prop( 'disabled', false ).text( tsosk.i18n.sidebar_save );
				},
				error: function () {
					alert( tsosk.i18n.error );
					$btn.prop( 'disabled', false ).text( tsosk.i18n.sidebar_save );
				}
			} );
		} );

		/* ── Reset to default ───────────────────────────────────────── */
		$btnReset.on( 'click', function () {
			var $btn = $( this );
			$btn.prop( 'disabled', true );

			ajaxPost( {
				action : 'tsosk_reset_sidebar_order',
				data   : { nonce: nonce },
				success: function ( r ) {
					if ( r.success ) {
						window.location.reload();
					} else {
						alert( r.data || tsosk.i18n.error );
						$btn.prop( 'disabled', false );
					}
				},
				error: function () {
					alert( tsosk.i18n.error );
					$btn.prop( 'disabled', false );
				}
			} );
		} );

		/* ── Remove from favorites ──────────────────────────────────── */
		$( document ).on( 'click', '.tsosk-remove-fav', function ( e ) {
			e.preventDefault();
			e.stopPropagation();
			if ( ! $favSidebar.hasClass( 'tsosk-editing' ) ) {
				return;
			}
			$( this ).closest( '.tsosk-nav-row' ).remove();
			updateFavoritesEmptyState();
		} );

		/* ── Hide / show tab toggle ─────────────────────────────────── */
		$( document ).on( 'click', '.tsosk-hide-tab', function ( e ) {
			e.preventDefault();
			e.stopPropagation();
			var $row    = $( this ).closest( '.tsosk-nav-row' );
			var hidden  = $row.hasClass( 'tsosk-nav-hidden' );
			if ( hidden ) {
				$row.removeClass( 'tsosk-nav-hidden' );
				$( this ).attr( 'title', tsosk.i18n.sidebar_hide ).text( '✕' );
			} else {
				$row.addClass( 'tsosk-nav-hidden' );
				$( this ).attr( 'title', tsosk.i18n.sidebar_show ).text( '＋' );
			}
		} );

		updateFavoritesEmptyState();

	} )();


	// ── Media Footprint & Image Sizes Audit ───────────────────────────────────

	// Footprint scan: runs in short server batches; "Resume" continues an interrupted scan.
	function tsoskFootprintRun( $btn, start ) {
		var $main = $( '#tsosk-media-footprint-scan' );
		var $msg  = $( '#tsosk-media-footprint-msg' );
		var $prog = $( '#tsosk-media-footprint-progress' );
		var $out  = $( '#tsosk-media-footprint-results' );
		var nonce = $btn.data( 'nonce' );
		var label = tsosk.i18n.media_footprint_scan || 'Scan uploads folder';
		var fails = 0;

		function finish() {
			$main.prop( 'disabled', false ).text( label );
			$( '#tsosk-media-footprint-resume' ).prop( 'disabled', false );
		}

		function tick( first ) {
			ajaxPost( {
				action : 'tsosk_media_footprint_scan',
				data   : { nonce: nonce, start: first ? 1 : 0 },
				success: function ( r ) {
					fails = 0;
					if ( ! r.success ) {
						showMsg( $msg, r.data || tsosk.i18n.error, 'error' );
						finish();
						return;
					}
					if ( r.data.done ) {
						$( '#tsosk-media-footprint-resume-note' ).remove();
						if ( r.data.html ) {
							$out.html( r.data.html );
						}
						$prog.text( '' );
						showMsg( $msg, r.data.message || tsosk.i18n.done, 'ok' );
						finish();
						return;
					}
					if ( r.data.progress ) {
						$prog.text( r.data.progress );
					}
					tick( false );
				},
				error: function () {
					// The batch position is stored on the server: retry, then offer Resume instead of starting over.
					fails++;
					if ( fails <= 2 ) {
						setTimeout( function () { tick( false ); }, 1500 * fails );
						return;
					}
					showMsg( $msg, tsosk.i18n.media_footprint_interrupted || tsosk.i18n.error, 'error' );
					finish();
					if ( ! $( '#tsosk-media-footprint-resume' ).length ) {
						$main.after( $( '<button type="button" class="button" id="tsosk-media-footprint-resume"></button>' )
							.attr( 'data-nonce', nonce )
							.text( tsosk.i18n.media_resume || 'Resume' ) );
					}
				}
			} );
		}

		$main.prop( 'disabled', true ).text( tsosk.i18n.running );
		$( '#tsosk-media-footprint-resume' ).prop( 'disabled', true );
		showMsg( $msg, '', '' );
		tick( start );
	}

	$( document ).on( 'click', '#tsosk-media-footprint-scan', function () {
		tsoskFootprintRun( $( this ), true );
	} );

	$( document ).on( 'click', '#tsosk-media-footprint-resume', function () {
		tsoskFootprintRun( $( this ), false );
	} );

	$( document ).on( 'click', '#tsosk-media-hygiene-scan', function () {
		var $btn = $( this );
		var $msg = $( '#tsosk-media-hygiene-msg' );
		var $out = $( '#tsosk-media-hygiene-results' );

		$btn.prop( 'disabled', true ).text( tsosk.i18n.running );
		showMsg( $msg, '', '' );

		ajaxPost( {
			action : 'tsosk_media_hygiene_scan',
			data   : { nonce: $btn.data( 'nonce' ) },
			success: function ( r ) {
				if ( r.success && r.data && r.data.html ) {
					$out.html( r.data.html );
					showMsg( $msg, r.data.message || tsosk.i18n.done, 'ok' );
				} else {
					showMsg( $msg, r.data || tsosk.i18n.error, 'error' );
				}
				$btn.prop( 'disabled', false ).text( tsosk.i18n.media_hygiene_scan || 'Scan removable folders' );
			},
			error: function () {
				showMsg( $msg, tsosk.i18n.error, 'error' );
				$btn.prop( 'disabled', false ).text( tsosk.i18n.media_hygiene_scan || 'Scan removable folders' );
			}
		} );
	} );

	$( document ).on( 'click', '.tsosk-media-hygiene-delete', function () {
		var $btn = $( this );
		var $msg = $( '#tsosk-media-hygiene-msg' );
		var $out = $( '#tsosk-media-hygiene-results' );
		var $quarantineOut = $( '#tsosk-media-quarantine-results' );
		var label = $btn.data( 'label' ) || '';
		var confirmMsg = tsosk.i18n.media_hygiene_delete_confirm || 'Move this folder to quarantine?';

		if ( label ) {
			confirmMsg = label + '\n\n' + confirmMsg;
		}
		if ( ! window.confirm( confirmMsg ) ) {
			return;
		}

		$btn.prop( 'disabled', true );
		showMsg( $msg, tsosk.i18n.running, '' );

		ajaxPost( {
			action : 'tsosk_media_hygiene_delete',
			data   : {
				nonce     : $btn.data( 'nonce' ),
				folder_id : $btn.data( 'folder-id' )
			},
			success: function ( r ) {
				if ( r.success ) {
					if ( r.data && r.data.html ) {
						$out.html( r.data.html );
					}
					if ( r.data && r.data.quarantine_html ) {
						$quarantineOut.html( r.data.quarantine_html );
					}
					showMsg( $msg, r.data.message || tsosk.i18n.done, 'ok' );
				} else {
					showMsg( $msg, r.data || tsosk.i18n.error, 'error' );
					$btn.prop( 'disabled', false );
				}
			},
			error: function () {
				showMsg( $msg, tsosk.i18n.error, 'error' );
				$btn.prop( 'disabled', false );
			}
		} );
	} );

	$( document ).on( 'click', '.tsosk-media-quarantine-restore', function () {
		var $btn = $( this );
		var $msg = $( '#tsosk-media-hygiene-msg' );
		var $out = $( '#tsosk-media-quarantine-results' );

		if ( ! window.confirm( tsosk.i18n.media_quarantine_restore_confirm || 'Restore this folder?' ) ) {
			return;
		}

		$btn.prop( 'disabled', true );
		showMsg( $msg, tsosk.i18n.running, '' );

		ajaxPost( {
			action : 'tsosk_media_quarantine_restore',
			data   : {
				nonce    : $btn.data( 'nonce' ),
				entry_id : $btn.data( 'entry-id' )
			},
			success: function ( r ) {
				if ( r.success ) {
					if ( r.data && r.data.html ) {
						$out.html( r.data.html );
					}
					showMsg( $msg, r.data.message || tsosk.i18n.done, 'ok' );
				} else {
					showMsg( $msg, r.data || tsosk.i18n.error, 'error' );
					$btn.prop( 'disabled', false );
				}
			},
			error: function () {
				showMsg( $msg, tsosk.i18n.error, 'error' );
				$btn.prop( 'disabled', false );
			}
		} );
	} );

	$( document ).on( 'click', '.tsosk-media-quarantine-purge', function () {
		var $btn = $( this );
		var $msg = $( '#tsosk-media-hygiene-msg' );
		var $out = $( '#tsosk-media-quarantine-results' );
		var label = $btn.data( 'label' ) || '';
		var confirmMsg = tsosk.i18n.media_quarantine_purge_confirm || 'Permanently delete this folder now?';

		if ( label ) {
			confirmMsg = label + '\n\n' + confirmMsg;
		}
		if ( ! window.confirm( confirmMsg ) ) {
			return;
		}

		$btn.prop( 'disabled', true );
		showMsg( $msg, tsosk.i18n.running, '' );

		ajaxPost( {
			action : 'tsosk_media_quarantine_purge',
			data   : {
				nonce    : $btn.data( 'nonce' ),
				entry_id : $btn.data( 'entry-id' )
			},
			success: function ( r ) {
				if ( r.success ) {
					if ( r.data && r.data.html ) {
						$out.html( r.data.html );
					}
					showMsg( $msg, r.data.message || tsosk.i18n.done, 'ok' );
				} else {
					showMsg( $msg, r.data || tsosk.i18n.error, 'error' );
					$btn.prop( 'disabled', false );
				}
			},
			error: function () {
				showMsg( $msg, tsosk.i18n.error, 'error' );
				$btn.prop( 'disabled', false );
			}
		} );
	} );

	$( document ).on( 'click', '#tsosk-image-sizes-scan', function () {
		var $btn = $( this );
		var $msg = $( '#tsosk-image-sizes-scan-msg' );
		var $out = $( '#tsosk-image-sizes-results' );

		$btn.prop( 'disabled', true ).text( tsosk.i18n.running );
		showMsg( $msg, '', '' );

		ajaxPost( {
			action : 'tsosk_image_sizes_audit_scan',
			data   : { nonce: $btn.data( 'nonce' ) },
			success: function ( r ) {
				if ( r.success && r.data && r.data.html ) {
					$out.html( r.data.html );
					showMsg( $msg, r.data.message || tsosk.i18n.done, 'ok' );
				} else {
					showMsg( $msg, r.data || tsosk.i18n.error, 'error' );
				}
				$btn.prop( 'disabled', false ).text( tsosk.i18n.image_sizes_scan || 'Run image sizes audit' );
			},
			error: function () {
				showMsg( $msg, tsosk.i18n.error, 'error' );
				$btn.prop( 'disabled', false ).text( tsosk.i18n.image_sizes_scan || 'Run image sizes audit' );
			}
		} );
	} );

	$( document ).on( 'click', '#tsosk-image-sizes-save', function () {
		var $btn      = $( this );
		var $msg      = $( '#tsosk-image-sizes-save-msg' );
		var disabled  = [];

		$( '.tsosk-img-audit-size-toggle:not(:checked)' ).each( function () {
			var name = $( this ).data( 'name' );
			if ( name ) {
				disabled.push( name );
			}
		} );

		$btn.prop( 'disabled', true ).text( tsosk.i18n.running );
		ajaxPost( {
			action : 'tsosk_image_sizes_audit_save',
			data   : { nonce: $btn.data( 'nonce' ), disabled: disabled },
			success: function ( r ) {
				if ( r.success && r.data && r.data.html ) {
					// The button is re-rendered with the results, so the message goes to the fresh copy.
					$( '#tsosk-image-sizes-results' ).html( r.data.html );
					showMsg( $( '#tsosk-image-sizes-save-msg' ), r.data.message || tsosk.i18n.done, 'ok' );
					return;
				}
				showMsg( $msg, r.success ? ( ( r.data && r.data.message ) || r.data || tsosk.i18n.done ) : ( r.data || tsosk.i18n.error ), r.success ? 'ok' : 'error' );
				$btn.prop( 'disabled', false ).text( tsosk.i18n.image_sizes_save || 'Save image size settings' );
			},
			error: function () {
				showMsg( $msg, tsosk.i18n.error, 'error' );
				$btn.prop( 'disabled', false ).text( tsosk.i18n.image_sizes_save || 'Save image size settings' );
			}
		} );
	} );

	$( document ).on( 'click', '#tsosk-image-sizes-quarantine', function () {
		var $btn  = $( this );
		var $msg  = $( '#tsosk-image-sizes-delete-msg' );
		var $out  = $( '#tsosk-image-sizes-results' );
		var $qout = $( '#tsosk-image-sizes-quarantine-results' );
		var sizes = [];
		var btnLabel = tsosk.i18n.image_sizes_quarantine || 'Move files for selected sizes to quarantine';

		$( '.tsosk-img-audit-delete-checkbox:checked' ).each( function () {
			var name = $( this ).data( 'name' );
			if ( name ) {
				sizes.push( name );
			}
		} );

		if ( ! sizes.length ) {
			showMsg( $msg, tsosk.i18n.image_sizes_quarantine_none || 'Select at least one size first.', 'error' );
			return;
		}

		var confirmMsg = ( tsosk.i18n.image_sizes_quarantine_confirm || 'Move the existing files for %1$d selected image size(s) to quarantine? They will be kept for 30 days and can be restored, or deleted permanently at any time. Continue?' ).replace( '%1$d', String( sizes.length ) );
		if ( ! window.confirm( confirmMsg ) ) {
			return;
		}

		$btn.prop( 'disabled', true ).text( tsosk.i18n.running );
		showMsg( $msg, '', '' );

		// The server first reports content that still links to these sizes; the request is repeated once confirmed.
		function send( confirmRefs ) {
			ajaxPost( {
				action : 'tsosk_image_sizes_audit_quarantine',
				data   : { nonce: $btn.data( 'nonce' ), sizes: sizes, confirm_refs: confirmRefs ? 1 : 0 },
				success: function ( r ) {
					if ( r.success && r.data && r.data.needs_confirm ) {
						if ( window.confirm( r.data.message ) ) {
							send( true );
							return;
						}
						$btn.prop( 'disabled', false ).text( btnLabel );
						return;
					}
					if ( r.success ) {
						if ( r.data && r.data.html ) {
							$out.html( r.data.html );
						}
						if ( r.data && r.data.quarantine_html ) {
							$qout.html( r.data.quarantine_html );
						}
						showMsg( $( '#tsosk-image-sizes-delete-msg' ), ( r.data && r.data.message ) || tsosk.i18n.done, 'ok' );
						$btn.prop( 'disabled', false ).text( btnLabel );
					} else {
						showMsg( $msg, r.data || tsosk.i18n.error, 'error' );
						$btn.prop( 'disabled', false ).text( btnLabel );
					}
				},
				error: function () {
					showMsg( $msg, tsosk.i18n.error, 'error' );
					$btn.prop( 'disabled', false ).text( btnLabel );
				}
			} );
		}
		send( false );
	} );

	$( document ).on( 'click', '.tsosk-img-adopt', function () {
		var $btn = $( this );
		var from = String( $btn.data( 'from' ) );
		var to   = String( $btn.data( 'to' ) );
		var confirmMsg = ( tsosk.i18n.image_sizes_adopt_confirm || 'Make the existing files of "%2$s" (%1$d images) available as "%3$s"? No file is moved, copied or deleted. Continue?' )
			.replace( '%1$d', String( $btn.data( 'files' ) ) )
			.replace( /%2\$s/g, from )
			.replace( /%3\$s/g, to );
		if ( ! window.confirm( confirmMsg ) ) {
			return;
		}
		var label = $btn.text();
		$btn.prop( 'disabled', true ).text( tsosk.i18n.running );
		ajaxPost( {
			action : 'tsosk_image_sizes_audit_adopt',
			data   : { nonce: $btn.data( 'nonce' ), from: from, to: to },
			success: function ( r ) {
				if ( r.success && r.data && r.data.html ) {
					$( '#tsosk-image-sizes-results' ).html( r.data.html );
					showMsg( $( '#tsosk-image-sizes-save-msg' ), r.data.message || tsosk.i18n.done, 'ok' );
					return;
				}
				$btn.prop( 'disabled', false ).text( label );
				window.alert( r.success ? ( ( r.data && r.data.message ) || tsosk.i18n.done ) : ( r.data || tsosk.i18n.error ) );
			},
			error: function () {
				$btn.prop( 'disabled', false ).text( label );
				window.alert( tsosk.i18n.error );
			}
		} );
	} );

	$( document ).on( 'click', '.tsosk-img-quarantine-restore', function () {
		var $btn = $( this );
		var $msg = $( '#tsosk-image-sizes-delete-msg' );
		var $out = $( '#tsosk-image-sizes-quarantine-results' );

		if ( ! window.confirm( tsosk.i18n.image_sizes_quarantine_restore_confirm || 'Restore these quarantined files to their original locations?' ) ) {
			return;
		}

		$btn.prop( 'disabled', true );
		showMsg( $msg, tsosk.i18n.running, '' );

		ajaxPost( {
			action : 'tsosk_image_sizes_audit_quarantine_restore',
			data   : {
				nonce    : $btn.data( 'nonce' ),
				entry_id : $btn.data( 'entry-id' )
			},
			success: function ( r ) {
				if ( r.success ) {
					if ( r.data && r.data.quarantine_html ) {
						$out.html( r.data.quarantine_html );
					}
					if ( r.data && r.data.quarantine_card_html ) {
						$( '#tsosk-isa-quarantine-card' ).replaceWith( r.data.quarantine_card_html );
					}
					showMsg( $msg, ( r.data && r.data.message ) || tsosk.i18n.done, 'ok' );
				} else {
					showMsg( $msg, r.data || tsosk.i18n.error, 'error' );
					$btn.prop( 'disabled', false );
				}
			},
			error: function () {
				showMsg( $msg, tsosk.i18n.error, 'error' );
				$btn.prop( 'disabled', false );
			}
		} );
	} );

	$( document ).on( 'click', '.tsosk-img-quarantine-purge', function () {
		var $btn      = $( this );
		var $msg      = $( '#tsosk-image-sizes-delete-msg' );
		var $out      = $( '#tsosk-image-sizes-quarantine-results' );
		var label     = $btn.data( 'label' ) || '';
		var confirmMsg = tsosk.i18n.image_sizes_quarantine_purge_confirm || 'Permanently delete these quarantined files now? This cannot be undone.';

		if ( label ) {
			confirmMsg = label + '\n\n' + confirmMsg;
		}
		if ( ! window.confirm( confirmMsg ) ) {
			return;
		}

		$btn.prop( 'disabled', true );
		showMsg( $msg, tsosk.i18n.running, '' );

		ajaxPost( {
			action : 'tsosk_image_sizes_audit_quarantine_purge',
			data   : {
				nonce    : $btn.data( 'nonce' ),
				entry_id : $btn.data( 'entry-id' )
			},
			success: function ( r ) {
				if ( r.success ) {
					if ( r.data && r.data.quarantine_html ) {
						$out.html( r.data.quarantine_html );
					}
					if ( r.data && r.data.quarantine_card_html ) {
						$( '#tsosk-isa-quarantine-card' ).replaceWith( r.data.quarantine_card_html );
					}
					showMsg( $msg, ( r.data && r.data.message ) || tsosk.i18n.done, 'ok' );
				} else {
					showMsg( $msg, r.data || tsosk.i18n.error, 'error' );
					$btn.prop( 'disabled', false );
				}
			},
			error: function () {
				showMsg( $msg, tsosk.i18n.error, 'error' );
				$btn.prop( 'disabled', false );
			}
		} );
	} );

	// ── Server Files ──────────────────────────────────────────────────────

	$( document ).on( 'click', '.tsosk-sf-save', function () {
		var $btn    = $( this );
		var key     = $btn.data( 'key' );
		var nonce   = $btn.data( 'nonce' );
		var content = $( '#tsosk-sf-content-' + key ).val();
		var $msg    = $( '.tsosk-sf-msg-' + key );

		$btn.prop( 'disabled', true ).text( tsosk.i18n.running );

		ajaxPost( {
			action : 'tsosk_sf_save',
			data   : { nonce: nonce, key: key, content: content },
			success: function ( r ) {
				if ( r.success ) {
					showMsg( $msg, r.data, 'ok' );
				} else {
					showMsg( $msg, r.data || tsosk.i18n.error, 'error' );
				}
				$btn.prop( 'disabled', false ).text( tsosk.i18n.save );
			},
			error: function () {
				showMsg( $msg, tsosk.i18n.error, 'error' );
				$btn.prop( 'disabled', false );
			}
		} );
	} );


	// Sitemap review: the table is drawn without HTTP calls, then verified in the background.
	function tsoskSitemapCheck( refresh ) {
		var $card = $( '#tsosk-sf-sitemaps' );
		if ( ! $card.length ) {
			return;
		}
		var $btn = $( '#tsosk-sf-sitemaps-recheck' ).prop( 'disabled', true );
		ajaxPost( {
			action : 'tsosk_sf_sitemap_check',
			data   : { nonce: $card.data( 'nonce' ), refresh: refresh ? '1' : '0' },
			success: function ( r ) {
				if ( r.success && r.data && typeof r.data.html === 'string' ) {
					$( '#tsosk-sf-sitemaps-body' ).html( r.data.html );
				}
				$btn.prop( 'disabled', false );
			},
			error: function () {
				$btn.prop( 'disabled', false );
			}
		} );
	}
	$( function () {
		tsoskSitemapCheck( false );
	} );
	$( document ).on( 'click', '#tsosk-sf-sitemaps-recheck', function () {
		tsoskSitemapCheck( true );
	} );

	$( document ).on( 'click', '.tsosk-sf-previous', function () {
		var $btn = $( this );
		var key  = $btn.data( 'key' );
		var $msg = $( '.tsosk-sf-msg-' + key );

		$btn.prop( 'disabled', true );
		ajaxPost( {
			action : 'tsosk_sf_previous',
			data   : { nonce: $btn.data( 'nonce' ), key: key },
			success: function ( r ) {
				if ( r.success ) {
					$( '#tsosk-sf-content-' + key ).val( r.data.content );
					showMsg( $msg, r.data.message, 'ok' );
				} else {
					showMsg( $msg, r.data || tsosk.i18n.error, 'error' );
				}
				$btn.prop( 'disabled', false );
			},
			error: function () {
				showMsg( $msg, tsosk.i18n.error, 'error' );
				$btn.prop( 'disabled', false );
			}
		} );
	} );

	// Put the editor back to the content saved on the server (the textarea's original value).
	$( document ).on( 'click', '.tsosk-sf-discard', function () {
		var $btn  = $( this );
		var key   = $btn.data( 'key' );
		var $area = $( '#tsosk-sf-content-' + key );
		if ( ! $area.length ) {
			return;
		}
		$area.val( $area.prop( 'defaultValue' ) );
		showMsg( $( '.tsosk-sf-msg-' + key ), $btn.attr( 'data-done' ), 'ok' );
	} );

	// Insert the security-headers block into the .htaccess editor (nothing is saved until "Save Changes").
	$( document ).on( 'click', '.tsosk-sf-headers', function () {
		var $btn  = $( this );
		var key   = $btn.data( 'key' );
		var $msg  = $( '.tsosk-sf-msg-' + key );
		var $area = $( '#tsosk-sf-content-' + key );
		var block = String( $btn.attr( 'data-block' ) || '' );
		var cur   = String( $area.val() || '' );

		if ( cur.indexOf( '# BEGIN TSOSK Security Headers' ) !== -1 ) {
			showMsg( $msg, $btn.attr( 'data-exists' ), 'error' );
			return;
		}
		var wp = cur.indexOf( '# BEGIN WordPress' );
		if ( wp !== -1 ) {
			cur = cur.slice( 0, wp ) + block + '\n\n' + cur.slice( wp );
		} else {
			cur = ( cur.replace( /\s+$/, '' ) ? cur.replace( /\s+$/, '' ) + '\n\n' : '' ) + block + '\n';
		}
		$area.val( cur ).trigger( 'focus' );
		showMsg( $msg, $btn.attr( 'data-done' ), 'ok' );
	} );


	// ── Slow Query Monitor ────────────────────────────────────────────────────

	var tsosk_sq = { page: 1, total_pages: 1, lastSearch: '' };

	// Expand / collapse long SQL (and fingerprints) in tables.
	$( document ).on( 'click', '.tsosk-sq-sql-fold-btn', function () {
		var $btn   = $( this );
		var $wrap  = $btn.closest( '.tsosk-sq-sql-fold' );
		var open   = ! $wrap.hasClass( 'is-open' );
		$wrap.toggleClass( 'is-open', open );
		$wrap.find( '.tsosk-sq-sql-preview' ).prop( 'hidden', open );
		$wrap.find( '.tsosk-sq-sql-code--full' ).prop( 'hidden', ! open );
		$btn.attr( 'aria-expanded', open ? 'true' : 'false' );
		$btn.find( '.tsosk-sq-sql-fold-show' ).prop( 'hidden', open );
		$btn.find( '.tsosk-sq-sql-fold-hide' ).prop( 'hidden', ! open );
	} );

	function tsoskSqDupeTable( panel ) {
		return $( '#tsosk-sq-' + panel + '-dupe-table' );
	}

	function tsoskSqParseDupeJson( panel ) {
		var el = document.getElementById( 'tsosk-sq-' + panel + '-dupe-json' );
		if ( ! el || ! el.textContent ) {
			return null;
		}
		try {
			return JSON.parse( el.textContent );
		} catch ( e ) {
			return null;
		}
	}

	function tsoskSqOriginLabelEn( origin ) {
		origin = String( origin || '' );
		if ( origin.indexOf( 'plugin:' ) === 0 ) {
			return 'Plugin: ' + origin.slice( 7 );
		}
		if ( origin.indexOf( 'mu-plugin:' ) === 0 ) {
			return 'MU-plugin: ' + origin.slice( 10 );
		}
		if ( origin.indexOf( 'theme:' ) === 0 ) {
			return 'Theme: ' + origin.slice( 6 );
		}
		if ( origin === 'core' ) {
			return 'WordPress Core';
		}
		if ( origin === 'unknown' ) {
			return 'Unknown';
		}
		return origin || 'Unknown';
	}

	function tsoskSqMapLines( map, emptyLine, labelFn ) {
		var keys = map && typeof map === 'object' ? Object.keys( map ) : [];
		if ( ! keys.length ) {
			return [ emptyLine ];
		}
		var lines = [];
		keys.slice( 0, 8 ).forEach( function ( k ) {
			var label = labelFn ? labelFn( k ) : k;
			lines.push( '- ' + label + ' ×' + String( map[ k ] ) );
		} );
		return lines;
	}

	function tsoskSqBuildDupeReport( payload, selectedIds ) {
		var meta = ( payload && payload.meta ) ? payload.meta : {};
		var all  = ( payload && payload.rows ) ? payload.rows : [];
		var want = {};
		( selectedIds || [] ).forEach( function ( id ) { want[ String( id ) ] = true; } );
		var rows = all.filter( function ( r ) { return want[ String( r.id ) ]; } );
		var lines = [
			'# Duplicate database queries (TSO Swiss Knife — Slow Query Monitor)',
			'URL: ' + ( meta.url ? meta.url : '(unknown)' ),
			'Queries on page: ' + String( meta.query_count || 0 ) + ' · Duplicate patterns in this report: ' + String( rows.length ),
			'Origin detection: ' + ( meta.detect ? 'on' : 'off (turn on in Monitor Settings, then reload the page you are debugging)' ),
			''
		];
		if ( ! rows.length ) {
			lines.push( 'No duplicate patterns selected.' );
			return lines.join( '\n' ) + '\n';
		}
		rows.forEach( function ( row, idx ) {
			if ( idx >= 25 ) {
				return;
			}
			lines.push( '## ' + String( idx + 1 ) + '. ×' + String( row.count ) + ' · ' + Number( row.time_ms || 0 ).toFixed( 2 ) + ' ms total' );
			lines.push( 'SQL:' );
			lines.push( String( row.sql || '' ) );
			lines.push( '' );
			lines.push( 'Callers:' );
			lines = lines.concat( tsoskSqMapLines( row.callers, '- (none recorded)' ) );
			lines.push( '' );
			lines.push( 'Components:' );
			lines = lines.concat( tsoskSqMapLines( row.components, meta.detect ? '- (unknown)' : '- (enable Origin detection to attribute plugins)', tsoskSqOriginLabelEn ) );
			lines.push( '' );
			lines.push( 'Potential troublemakers:' );
			lines = lines.concat( tsoskSqMapLines( row.troublemakers, meta.detect ? '- (none identified beyond the callers above)' : '- (enable Origin detection)' ) );
			lines.push( '' );
		} );
		if ( rows.length > 25 ) {
			lines.push( '… and ' + String( rows.length - 25 ) + ' more patterns.' );
		}
		return lines.join( '\n' );
	}

	$( document ).on( 'change', '.tsosk-sq-dupe-pick-all', function () {
		var $table = $( this ).closest( 'table' );
		$table.find( '.tsosk-sq-dupe-pick' ).prop( 'checked', $( this ).prop( 'checked' ) );
	} );

	$( document ).on( 'change', '.tsosk-sq-dupe-pick', function () {
		var $table = $( this ).closest( 'table' );
		var $picks = $table.find( '.tsosk-sq-dupe-pick' );
		var allOn  = $picks.length && $picks.filter( ':checked' ).length === $picks.length;
		$table.find( '.tsosk-sq-dupe-pick-all' ).prop( 'checked', allOn );
	} );

	function tsoskSqCopyText( text, $msg, $fallback ) {
		var doneLabel = ( tsosk.i18n && tsosk.i18n.sq_copied ) ? tsosk.i18n.sq_copied : ( ( tsosk.i18n && tsosk.i18n.email_copied ) ? tsosk.i18n.email_copied : 'Copied' );
		function onCopied() {
			showMsg( $msg, doneLabel, 'ok' );
		}
		if ( ! text ) {
			showMsg( $msg, ( tsosk.i18n && tsosk.i18n.sq_copy_none ) ? tsosk.i18n.sq_copy_none : tsosk.i18n.error, 'error' );
			return;
		}
		if ( navigator.clipboard && navigator.clipboard.writeText ) {
			navigator.clipboard.writeText( text ).then( onCopied ).catch( function () {
				try {
					if ( $fallback && $fallback.length ) {
						$fallback.val( text ).prop( 'hidden', false ).trigger( 'select' );
						document.execCommand( 'copy' );
						$fallback.prop( 'hidden', true );
					}
					onCopied();
				} catch ( e ) {
					showMsg( $msg, tsosk.i18n.error, 'error' );
				}
			} );
			return;
		}
		try {
			if ( $fallback && $fallback.length ) {
				$fallback.val( text ).prop( 'hidden', false ).trigger( 'select' );
				document.execCommand( 'copy' );
				$fallback.prop( 'hidden', true );
			}
			onCopied();
		} catch ( e2 ) {
			showMsg( $msg, tsosk.i18n.error, 'error' );
		}
	}

	// Copy a Query Monitor–style duplicate report (English) for pasting into an AI chat.
	$( document ).on( 'click', '.tsosk-sq-copy-report', function () {
		var $btn  = $( this );
		var panel = $btn.data( 'dupe-panel' );
		var msgId = $btn.data( 'msg' );
		var $msg  = msgId ? $( '#' + msgId ) : $btn.siblings( '.tsosk-ajax-msg' ).first();

		if ( ! panel ) {
			showMsg( $msg, tsosk.i18n.error, 'error' );
			return;
		}

		var payload = tsoskSqParseDupeJson( String( panel ) );
		var ids     = [];
		tsoskSqDupeTable( String( panel ) ).find( '.tsosk-sq-dupe-pick:checked' ).each( function () {
			ids.push( String( $( this ).val() ) );
		} );
		if ( ! payload || ! payload.rows ) {
			showMsg( $msg, tsosk.i18n.error, 'error' );
			return;
		}
		if ( ! ids.length ) {
			showMsg( $msg, ( tsosk.i18n && tsosk.i18n.sq_copy_none ) ? tsosk.i18n.sq_copy_none : tsosk.i18n.error, 'error' );
			return;
		}
		tsoskSqCopyText( tsoskSqBuildDupeReport( payload, ids ), $msg, $() );
	} );

	function tsoskSqCopyPluginsSelected() {
		var out = [];
		$( '#tsosk-sq-copy-plugins .tsosk-sq-copy-plugin:checked' ).each( function () {
			var v = $( this ).val();
			if ( v ) {
				out.push( String( v ) );
			}
		} );
		return out;
	}

	$( document ).on( 'click', '#tsosk-sq-copy-plugins-tso', function ( e ) {
		e.preventDefault();
		$( '#tsosk-sq-copy-plugins .tsosk-sq-copy-plugin' ).each( function () {
			var slug = String( $( this ).val() || '' );
			$( this ).prop( 'checked', slug.indexOf( 'tso-' ) === 0 );
		} );
	} );

	$( document ).on( 'click', '#tsosk-sq-copy-plugins-none', function ( e ) {
		e.preventDefault();
		$( '#tsosk-sq-copy-plugins .tsosk-sq-copy-plugin' ).prop( 'checked', false );
	} );

	// Save settings
	$( document ).on( 'click', '#tsosk-sq-save', function () {
		var $btn  = $( this );
		var $msg  = $( '#tsosk-sq-settings-msg' );
		var nonce = $btn.data( 'nonce' );
		$btn.prop( 'disabled', true ).text( tsosk.i18n.running );
		ajaxPost( {
			action : 'tsosk_sq_save_settings',
			data   : {
				nonce        : nonce,
				enabled      : $( '#tsosk-sq-enabled' ).prop( 'checked' ) ? 1 : 0,
				threshold_ms : $( '#tsosk-sq-threshold' ).val(),
				max_entries  : $( '#tsosk-sq-max-entries' ).val(),
				exclude_ajax : $( '#tsosk-sq-exclude-ajax' ).prop( 'checked' ) ? 1 : 0,
				exclude_cron : $( '#tsosk-sq-exclude-cron' ).prop( 'checked' ) ? 1 : 0,
				show_admin_bar : $( '#tsosk-sq-show-admin-bar' ).prop( 'checked' ) ? 1 : 0,
				capture_origin : $( '#tsosk-sq-capture-origin' ).prop( 'checked' ) ? 1 : 0,
				copy_plugins : JSON.stringify( tsoskSqCopyPluginsSelected() ),
				ignore_patterns : $( '#tsosk-sq-ignore-patterns' ).val() || ''
			},
			success: function ( r ) {
				if ( r.success ) {
					showMsg( $msg, r.data.message, r.data.warn_savequeries ? 'warn' : 'ok' );
					setTimeout( function () { window.location.reload(); }, 1000 );
				} else {
					showMsg( $msg, r.data || tsosk.i18n.error, 'error' );
					$btn.prop( 'disabled', false ).text( tsosk.i18n.save );
				}
			},
			error: function () {
				showMsg( $msg, tsosk.i18n.error, 'error' );
				$btn.prop( 'disabled', false ).text( tsosk.i18n.save );
			}
		} );
	} );

	// Batch expand/collapse
	$( document ).on( 'click', '.tsosk-sq-batch-header', function ( e ) {
		if ( $( e.target ).closest( '.tsosk-sq-delete-batch' ).length ) { return; }
		var $body = $( this ).siblings( '.tsosk-sq-batch-body' );
		var $icon = $( this ).find( '.tsosk-sq-toggle-icon' );
		$body.toggleClass( 'open' );
		$icon.text( $body.hasClass( 'open' ) ? '▲' : '▼' );
	} );

	// Delete single batch
	$( document ).on( 'click', '.tsosk-sq-delete-batch', function ( e ) {
		e.stopPropagation();
		var $btn  = $( this );
		var id    = $btn.attr( 'data-id' ) || $btn.data( 'id' );
		var nonce = $btn.data( 'nonce' );
		var $msg  = $( '#tsosk-sq-log-msg' );
		if ( ! id ) { return; }
		if ( ! confirm( tsosk.i18n.sq_delete_confirm ) ) { return; }
		$btn.prop( 'disabled', true );
		ajaxPost( {
			action : 'tsosk_sq_delete_entry',
			data   : { nonce: nonce, id: id },
			success: function ( r ) {
				if ( r.success ) {
					$( '.tsosk-sq-batch[data-id="' + id + '"], #tsosk-sq-batch-' + id ).fadeOut( 300, function () { $( this ).remove(); } );
					showMsg( $msg, r.data, 'ok' );
				} else {
					showMsg( $msg, r.data || tsosk.i18n.error, 'error' );
					$btn.prop( 'disabled', false );
				}
			},
			error: function () {
				showMsg( $msg, tsosk.i18n.error, 'error' );
				$btn.prop( 'disabled', false );
			}
		} );
	} );

	// Clear all
	$( document ).on( 'click', '#tsosk-sq-clear-btn', function () {
		var $btn  = $( this );
		var nonce = $btn.data( 'nonce' );
		var $msg  = $( '#tsosk-sq-log-msg' );
		if ( ! confirm( tsosk.i18n.sq_clear_confirm ) ) { return; }
		$btn.prop( 'disabled', true );
		ajaxPost( {
			action : 'tsosk_sq_clear_log',
			data   : { nonce: nonce },
			success: function ( r ) {
				if ( r.success ) {
					showMsg( $msg, r.data, 'ok' );
					$( '#tsosk-sq-batches' ).empty();
					$btn.prop( 'disabled', false );
				} else {
					showMsg( $msg, r.data || tsosk.i18n.error, 'error' );
					$btn.prop( 'disabled', false );
				}
			},
			error: function () {
				showMsg( $msg, tsosk.i18n.error, 'error' );
				$btn.prop( 'disabled', false );
			}
		} );
	} );

	// Ignore SQL fingerprint pattern
	$( document ).on( 'click', '.tsosk-sq-ignore-pattern', function () {
		var $btn    = $( this );
		var nonce   = $btn.attr( 'data-nonce' );
		var pattern = $btn.attr( 'data-pattern' );
		var $msg    = $( '#tsosk-sq-pattern-msg' );
		var label   = $btn.text();
		if ( ! pattern ) { return; }
		if ( ! confirm( tsosk.i18n.sq_ignore_confirm || 'Ignore this SQL pattern?' ) ) { return; }
		$btn.prop( 'disabled', true ).text( tsosk.i18n.running );
		ajaxPost( {
			action : 'tsosk_sq_ignore_pattern',
			data   : { nonce: nonce, pattern: pattern },
			success: function ( r ) {
				if ( r.success ) {
					showMsg( $msg, ( r.data && r.data.message ) || tsosk.i18n.done, 'ok' );
					if ( r.data && r.data.patterns && $( '#tsosk-sq-ignore-patterns' ).length ) {
						$( '#tsosk-sq-ignore-patterns' ).val( r.data.patterns.join( '\n' ) );
					}
					$btn.closest( 'tr' ).fadeOut( 300, function () { $( this ).remove(); } );
				} else {
					showMsg( $msg, r.data || tsosk.i18n.error, 'error' );
					$btn.prop( 'disabled', false ).text( label );
				}
			},
			error: function () {
				showMsg( $msg, tsosk.i18n.error, 'error' );
				$btn.prop( 'disabled', false ).text( label );
			}
		} );
	} );

	// Search + pagination
	function tsosk_sq_load( page ) {
		tsosk_sq.page = page || 1;
		var nonce  = $( '#tsosk-sq-search-btn' ).data( 'nonce' );
		var search = $( '#tsosk-sq-search' ).val().trim();
		tsosk_sq.lastSearch = search;

		$( '#tsosk-sq-batches' ).html( '<p style="color:#646970;padding:12px;">' + tsosk.i18n.running + '…</p>' );

		ajaxPost( {
			action : 'tsosk_sq_get_log',
			data   : { nonce: nonce, page: tsosk_sq.page, search: search },
			success: function ( r ) {
				if ( ! r.success ) {
					$( '#tsosk-sq-batches' ).html( '<p style="color:#d63638;">' + ( r.data || tsosk.i18n.error ) + '</p>' );
					return;
				}
				tsosk_sq.total_pages = r.data.total_pages;
				tsosk_sq_render( r.data );
			},
			error: function () {
				$( '#tsosk-sq-batches' ).html( '<p style="color:#d63638;">' + tsosk.i18n.error + '</p>' );
			}
		} );
	}

	function tsosk_sq_render( data ) {
		var $wrap = $( '#tsosk-sq-batches' );
		$wrap.empty();

		if ( ! data.items || ! data.items.length ) {
			$wrap.html( '<p style="color:#646970;padding:8px 0;">' + tsosk.i18n.sq_no_results + '</p>' );
			$( '#tsosk-sq-pagination-top, #tsosk-sq-pagination-bot' ).empty();
			return;
		}

		var nonce = $( '#tsosk-sq-search-btn' ).data( 'nonce' );

		$.each( data.items, function ( i, batch ) {
			var maxTime = 0;
			$.each( batch.queries || [], function ( j, q ) {
				if ( parseFloat( q.time ) > maxTime ) { maxTime = parseFloat( q.time ); }
			} );
			var worstCls    = maxTime > 500 ? 'tsosk-sq-warn' : ( maxTime > 200 ? 'tsosk-sq-amber' : '' );
			var badgeCls    = batch.slow_count > 5 ? 'tsosk-badge-warn' : 'tsosk-badge-info';
			var batchId     = batch.id || ( 'tmp-' + i );
			var batchIdAttr = String( batchId ).replace( /"/g, '' );

			var $batch = $( '<div class="tsosk-sq-batch"></div>' )
				.attr( 'id', 'tsosk-sq-batch-' + batchIdAttr )
				.attr( 'data-id', batchIdAttr );

			var headerHtml = '<div class="tsosk-sq-batch-header" data-id="' + batchIdAttr + '">'
				+ '<span class="tsosk-badge ' + badgeCls + ' tsosk-sq-batch-badge">' + batch.slow_count + ' ' + tsosk.i18n.sq_slow + '</span>'
				+ '<span class="tsosk-sq-batch-url">' + $( '<span>' ).text( batch.url || '—' ).html() + '</span>'
				+ '<span class="tsosk-sq-batch-meta">' + new Date( batch.ts * 1000 ).toISOString().replace( 'T', ' ' ).slice( 0, 16 ) + ' UTC</span>'
				+ ( batch.load_ms > 0 ? '<span class="tsosk-sq-batch-meta tsosk-sq-batch-meta-muted">Page: ' + parseFloat( batch.load_ms ).toFixed(1) + ' ms</span>' : '' )
				+ '<span class="tsosk-sq-batch-worst ' + worstCls + '">Worst: ' + maxTime.toFixed(2) + ' ms</span>'
				+ '<button type="button" class="button button-small tsosk-sq-delete-batch tsosk-sq-delete-batch-btn" data-id="' + batchIdAttr + '" data-nonce="' + nonce + '">' + tsosk.i18n.delete + '</button>'
				+ '<span class="tsosk-sq-toggle-icon">▼</span>'
				+ '</div>';

			var bodyHtml = '<div class="tsosk-sq-batch-body">';
			$.each( batch.queries || [], function ( j, q ) {
				var t  = parseFloat( q.time );
				var tc = t > 500 ? 'tsosk-sq-warn' : ( t > 200 ? 'tsosk-sq-amber' : '' );
				var kw = ( q.sql || '' ).split( ' ' )[0].toUpperCase();
				var kwColors = { SELECT:'#2271b1', INSERT:'#16a34a', UPDATE:'#d97706', DELETE:'#d63638', CREATE:'#7c3aed', DROP:'#d63638' };
				var kwc = kwColors[kw] || '#374151';
				bodyHtml += '<div class="tsosk-sq-query-row">'
					+ '<div class="tsosk-sq-query-meta">'
					+ '<span class="tsosk-sq-query-time ' + tc + '">' + t.toFixed(3) + ' ms</span>'
					+ '<span class="tsosk-badge tsosk-sq-kw-badge" style="background:' + kwc + '20;color:' + kwc + ';">' + $('<span>').text(kw).html() + '</span>'
					+ '<span class="tsosk-sq-query-num">#' + (j+1) + '</span>'
					+ ( q.origin_label ? '<span class="tsosk-badge tsosk-sq-origin-badge">' + $('<span>').text(q.origin_label).html() + '</span>' : '' )
					+ '</div>'
					+ '<div class="tsosk-sq-query-sql">' + $('<span>').text(q.sql || '').html() + '</div>'
					+ ( q.caller ? '<div class="tsosk-sq-query-caller"><span class="tsosk-sq-caller-arrow">↳</span> ' + $('<span>').text(q.caller).html() + '</div>' : '' )
					+ '</div>';
			} );
			bodyHtml += '</div>';

			$batch.append( headerHtml ).append( bodyHtml );
			$wrap.append( $batch );
		} );

		// Pagination
		var pgHtml = '';
		if ( data.total_pages > 1 ) {
			pgHtml += '<span style="font-size:12px;color:#646970;">' + tsosk.i18n.sq_page + ' ' + data.page + ' ' + tsosk.i18n.sq_of + ' ' + data.total_pages + '</span> ';
			if ( data.page > 1 ) { pgHtml += '<button class="tsosk-oe-page-btn tsosk-sq-page-btn" data-page="' + (data.page-1) + '">&larr;</button>'; }
			for ( var p = Math.max(1,data.page-2); p <= Math.min(data.total_pages,data.page+2); p++ ) {
				pgHtml += '<button class="tsosk-oe-page-btn' + (p===data.page?' is-current':'') + ' tsosk-sq-page-btn" data-page="' + p + '">' + p + '</button>';
			}
			if ( data.page < data.total_pages ) { pgHtml += '<button class="tsosk-oe-page-btn tsosk-sq-page-btn" data-page="' + (data.page+1) + '">&rarr;</button>'; }
		}
		$( '#tsosk-sq-pagination-top, #tsosk-sq-pagination-bot' ).html( pgHtml );
	}

	$( document ).on( 'click', '.tsosk-sq-page-btn', function () {
		tsosk_sq_load( parseInt( $( this ).data( 'page' ), 10 ) );
	} );
	$( document ).on( 'click', '#tsosk-sq-search-btn', function () {
		tsosk_sq_load( 1 );
	} );
	$( document ).on( 'keydown', '#tsosk-sq-search', function ( e ) {
		if ( e.key === 'Enter' ) { tsosk_sq_load( 1 ); }
	} );

	// Slow Query Monitor: live SAVEQUERIES table filters (duplicates / slow / search).
	function tsosk_sq_apply_debug_filters() {
		var $filter = $( '#tsosk-sq-filter' );
		if ( ! $filter.length ) {
			return;
		}
		var q      = $filter.val().toLowerCase();
		var onlyDu = $( '#tsosk-sq-dupes-only' ).prop( 'checked' );
		var onlySl = $( '#tsosk-sq-slow-only' ).prop( 'checked' );
		var $rows  = $( '#tsosk-sq-table tbody .tsosk-sq-row' );
		var shown  = 0;
		$rows.each( function () {
			var $row  = $( this );
			var sql   = String( $row.attr( 'data-sql' ) || '' ).toLowerCase();
			// Prefer attr over .data() — jQuery coerces data-dupe="0" to number 0.
			var isDu  = String( $row.attr( 'data-dupe' ) || '0' ) === '1';
			var isSl  = String( $row.attr( 'data-slow' ) || '0' ) === '1';
			var hide  = ( q && sql.indexOf( q ) === -1 )
				|| ( onlyDu && ! isDu )
				|| ( onlySl && ! isSl );
			$row.toggleClass( 'tsosk-sq-hidden', hide );
			if ( ! hide ) {
				shown++;
			}
		} );
		var $count = $( '#tsosk-sq-count-shown' );
		if ( $count.length ) {
			$count.text( shown + ' / ' + $rows.length );
		}
	}

	$( document ).on( 'input', '#tsosk-sq-filter', tsosk_sq_apply_debug_filters );
	$( document ).on( 'change', '#tsosk-sq-dupes-only, #tsosk-sq-slow-only', tsosk_sq_apply_debug_filters );
	tsosk_sq_apply_debug_filters();


	// ── Search & Replace ───────────────────────────────────────────────────────

	var tsosk_sr_preview_data = null; // Cached preview results.

	function tsosk_sr_invalidate_preview() {
		tsosk_sr_preview_data = null;
		$( '#tsosk-sr-execute-btn, #tsosk-sr-cancel-btn' ).hide();
		$( '.tsosk-sr-execute-hint' ).hide();
	}

	$( document ).on( 'input change', '#tsosk-sr-search, #tsosk-sr-replace, #tsosk-sr-case, #tsosk-sr-regex', tsosk_sr_invalidate_preview );
	$( document ).on( 'change', '.tsosk-sr-table-cb', tsosk_sr_invalidate_preview );

	// Table selection helpers (act on the tables currently shown by the filter).
	function tsosk_sr_update_count() {
		var $count = $( '#tsosk-sr-table-count' );
		if ( ! $count.length ) {
			return;
		}
		var $all   = $( '.tsosk-sr-table-cb' );
		var shown  = $all.filter( function () { return ! $( this ).closest( 'label' ).hasClass( 'tsosk-sr-hidden' ); } ).length;
		var total  = $all.length;
		var sel    = $all.filter( ':checked' ).length;
		var text   = shown ? String( $count.data( 'template' ) ) : String( $count.data( 'empty' ) );
		$count.text( text.replace( '{shown}', shown ).replace( '{total}', total ).replace( '{selected}', sel ) );
	}
	function tsosk_sr_visible_cbs() {
		return $( '.tsosk-sr-table-cb' ).filter( function () { return ! $( this ).closest( 'label' ).hasClass( 'tsosk-sr-hidden' ); } );
	}
	$( document ).on( 'input search', '#tsosk-sr-table-filter', function () {
		var q = $.trim( $( this ).val() ).toLowerCase();
		$( '.tsosk-sr-table-cb' ).each( function () {
			var match = ! q || String( $( this ).val() ).toLowerCase().indexOf( q ) !== -1;
			$( this ).closest( 'label' ).toggleClass( 'tsosk-sr-hidden', ! match );
		} );
		tsosk_sr_update_count();
	} );
	$( document ).on( 'change', '.tsosk-sr-table-cb', tsosk_sr_update_count );
	$( tsosk_sr_update_count );
	$( document ).on( 'click', '#tsosk-sr-select-wp', function () {
		tsosk_sr_visible_cbs().each( function () {
			$( this ).prop( 'checked', $( this ).data( 'is-wp' ) === 1 || $( this ).data( 'is-wp' ) === '1' );
		} );
		tsosk_sr_update_count();
		tsosk_sr_invalidate_preview();
	} );
	$( document ).on( 'click', '#tsosk-sr-select-all', function () {
		tsosk_sr_visible_cbs().prop( 'checked', true );
		tsosk_sr_update_count();
		tsosk_sr_invalidate_preview();
	} );
	$( document ).on( 'click', '#tsosk-sr-select-none', function () {
		tsosk_sr_visible_cbs().prop( 'checked', false );
		tsosk_sr_update_count();
		tsosk_sr_invalidate_preview();
	} );

	// Collect selected tables
	function tsosk_sr_get_tables() {
		var tables = [];
		$( '.tsosk-sr-table-cb:checked' ).each( function () {
			tables.push( $( this ).val() );
		} );
		return tables;
	}

	// Collect form params
	function tsosk_sr_params() {
		return {
			nonce          : $( '#tsosk-sr-preview-btn' ).data( 'nonce' ),
			search         : $( '#tsosk-sr-search' ).val(),
			replace        : $( '#tsosk-sr-replace' ).val(),
			case_sensitive : $( '#tsosk-sr-case' ).prop( 'checked' ) ? 1 : 0,
			is_regex       : $( '#tsosk-sr-regex' ).prop( 'checked' ) ? 1 : 0,
			tables         : tsosk_sr_get_tables(),
		};
	}

	// ── Preview ──
	$( document ).on( 'click', '#tsosk-sr-preview-btn', function () {
		var $btn = $( this );
		var $msg = $( '#tsosk-sr-msg' );
		var params = tsosk_sr_params();

		if ( ! params.search ) {
			showMsg( $msg, tsosk.i18n.sr_empty_search, 'error' );
			return;
		}
		if ( ! params.tables.length ) {
			showMsg( $msg, tsosk.i18n.sr_no_tables, 'error' );
			return;
		}

		$btn.prop( 'disabled', true ).text( tsosk.i18n.running );
		$( '#tsosk-sr-execute-btn, #tsosk-sr-cancel-btn' ).hide();
		$( '.tsosk-sr-execute-hint' ).hide();
		$( '#tsosk-sr-preview-wrap' ).hide();
		tsosk_sr_preview_data = null;

		ajaxPost( {
			action : 'tsosk_sr_preview',
			data   : params,
			success: function ( r ) {
				$btn.prop( 'disabled', false ).text( '🔍 ' + tsosk.i18n.sr_preview_btn );
				if ( ! r.success ) {
					showMsg( $msg, r.data || tsosk.i18n.error, 'error' );
					return;
				}
				tsosk_sr_preview_data = r.data;
				tsosk_sr_render_preview( r.data );
				if ( r.data.total_rows > 0 ) {
					$( '#tsosk-sr-execute-btn' ).show();
					$( '#tsosk-sr-cancel-btn' ).show();
					$( '.tsosk-sr-execute-hint' ).show();
				}
				showMsg( $msg, '', '' );
			},
			error: function () {
				showMsg( $msg, tsosk.i18n.error, 'error' );
				$btn.prop( 'disabled', false ).text( '🔍 ' + tsosk.i18n.sr_preview_btn );
			}
		} );
	} );

	// True when at least one matching table holds visible content (posts, comments, terms…).
	function tsosk_sr_is_content_table( data, name ) {
		return $.inArray( name, data.content_tables || [] ) !== -1;
	}
	function tsosk_sr_has_content_match( data ) {
		var found = false;
		$.each( data.results || {}, function ( name ) {
			if ( tsosk_sr_is_content_table( data, name ) ) {
				found = true;
				return false;
			}
		} );
		return found;
	}

	// Preview warnings: sampled tables, skipped tables and untouched cells (all text is escaped).
	function tsosk_sr_append_warnings( $notice, data ) {
		var lines = [];
		if ( data.truncated && data.truncated.length ) {
			lines.push( tsosk.i18n.sr_truncated_note.replace( '%s', data.truncated.join( ', ' ) ) );
		}
		if ( data.skipped_tables && data.skipped_tables.length ) {
			lines.push( tsosk.i18n.sr_skipped_tables.replace( '%s', data.skipped_tables.join( ', ' ) ) );
		}
		if ( data.skipped_cells ) {
			lines.push( tsosk.i18n.sr_skipped_cells.replace( '%d', String( data.skipped_cells ) ) );
		}
		if ( ! $( '#tsosk-sr-replace' ).val() ) {
			lines.push( tsosk.i18n.sr_warn_empty_replace );
		}
		if ( data.total_rows && ! tsosk_sr_has_content_match( data ) ) {
			lines.push( tsosk.i18n.sr_warn_internal_only );
		}
		$.each( lines, function ( i, line ) {
			$notice.append( $( '<div style="margin-top:6px;"></div>' ).text( line ) );
		} );
	}

	// ── Render preview ──
	function tsosk_sr_render_preview( data ) {
		var $wrap   = $( '#tsosk-sr-preview-wrap' );
		var $notice = $( '#tsosk-sr-preview-notice' );
		var $body   = $( '#tsosk-sr-preview-body' );

		$body.empty();
		$wrap.show();
		if ( $wrap.length && $wrap[0].scrollIntoView ) {
			$wrap[0].scrollIntoView( { behavior: 'smooth', block: 'nearest' } );
		}

		if ( ! data.total_rows ) {
			$notice.html( '<strong>' + tsosk.i18n.sr_preview_none + '</strong>' );
			tsosk_sr_append_warnings( $notice, data );
			$notice.show();
			return;
		}

		var totalCells = 0;
		$.each( data.results, function ( tableName, rows ) {
			totalCells += rows.length;
		} );
		$notice.html(
			$( '<strong></strong>' ).text(
				tsosk.i18n.sr_found_summary.replace( '%1$s', String( data.total_rows ) ).replace( '%2$s', String( Object.keys( data.results ).length ) )
			).prop( 'outerHTML' ) + ' ' + tsosk.i18n.sr_confirm_hint
		);
		tsosk_sr_append_warnings( $notice, data );
		$notice.show();

		$.each( data.results, function ( tableName, rows ) {
			var $section = $( '<div class="tsosk-sr-table-section"></div>' );
			var $header  = $( '<div class="tsosk-sr-table-header"></div>' );
			$header.append( '<span class="tsosk-code" style="font-size:13px;">' + $( '<span>' ).text( tableName ).html() + '</span>' );
			$header.append( '<span class="tsosk-badge tsosk-badge-warn" style="font-size:11px;">' + rows.length + ' ' + tsosk.i18n.sr_rows + '</span>' );
			if ( tsosk_sr_is_content_table( data, tableName ) ) {
				$header.append( $( '<span class="tsosk-badge tsosk-badge-ok" style="font-size:11px;"></span>' ).text( tsosk.i18n.sr_badge_content ) );
			} else {
				$header.append( $( '<span class="tsosk-badge tsosk-badge-info" style="font-size:11px;"></span>' ).text( tsosk.i18n.sr_badge_internal ) );
			}
			$section.append( $header );

			$.each( rows, function ( i, row ) {
				if ( i >= 10 ) {
					// Show max 10 rows per table in preview for readability
					$section.append( '<div class="tsosk-sr-row" style="color:#8c8f94;font-size:12px;font-style:italic;">…' + ( rows.length - 10 ) + ' ' + tsosk.i18n.sr_more + '</div>' );
					return false;
				}
				var $row = $( '<div class="tsosk-sr-row"></div>' );
				$row.append( '<div style="font-size:11px;color:#8c8f94;margin-bottom:4px;">' + tsosk.i18n.sr_pk + ': <code>' + $( '<span>' ).text( String( row.pk ) ).html() + '</code></div>' );

				$.each( row.changes, function ( colName, diff ) {
					var $colWrap = $( '<div style="margin-bottom:6px;"></div>' );
					$colWrap.append( '<div class="tsosk-sr-col-label">' + $( '<span>' ).text( colName ).html() + ':</div>' );

					var $before = $( '<div></div>' );
					$before.append( '<span style="font-size:10px;color:#8c8f94;margin-right:4px;">BEFORE</span>' );
					$before.append( '<span class="tsosk-sr-diff-before">' + $( '<span>' ).text( diff.before ).html() + ( diff.before.length >= 300 ? '…' : '' ) + '</span>' );

					var $after = $( '<div style="margin-top:3px;"></div>' );
					$after.append( '<span style="font-size:10px;color:#8c8f94;margin-right:4px;">AFTER</span>' );
					$after.append( '<span class="tsosk-sr-diff-after">' + $( '<span>' ).text( diff.after ).html() + ( diff.after.length >= 300 ? '…' : '' ) + '</span>' );

					$colWrap.append( $before ).append( $after );
					$row.append( $colWrap );
				} );

				$section.append( $row );
			} );

			$body.append( $section );
		} );
	}

	// ── Execute ──
	$( document ).on( 'click', '#tsosk-sr-execute-btn', function () {
		var $btn = $( this );
		var $msg = $( '#tsosk-sr-msg' );

		if ( ! tsosk_sr_preview_data ) {
			showMsg( $msg, tsosk.i18n.sr_stale_preview, 'error' );
			return;
		}

		if ( ! $( '#tsosk-sr-replace' ).val() && ! confirm( tsosk.i18n.sr_confirm_empty_replace ) ) { return; }
		if ( ! tsosk_sr_has_content_match( tsosk_sr_preview_data ) && ! confirm( tsosk.i18n.sr_confirm_internal_only ) ) { return; }
		if ( ! confirm( tsosk.i18n.sr_confirm_exec ) ) { return; }
		if ( tsosk_sr_preview_data.has_backup && ! confirm( tsosk.i18n.sr_replace_backup_warn ) ) { return; }

		$btn.prop( 'disabled', true ).text( tsosk.i18n.running );
		$( '#tsosk-sr-preview-btn' ).prop( 'disabled', true );

		ajaxPost( {
			action : 'tsosk_sr_execute',
			data   : tsosk_sr_params(),
			success: function ( r ) {
				$btn.prop( 'disabled', false ).text( '⚡ ' + tsosk.i18n.sr_execute_btn );
				$( '#tsosk-sr-preview-btn' ).prop( 'disabled', false );
				if ( r.success ) {
					var warnings = ( r.data.errors || [] ).slice();
					if ( r.data.skipped_cells ) {
						warnings.push( tsosk.i18n.sr_skipped_cells.replace( '%d', String( r.data.skipped_cells ) ) );
					}
					showMsg( $msg, r.data.message, 'ok' );
					$( '#tsosk-sr-execute-btn, #tsosk-sr-cancel-btn' ).hide();
					$( '.tsosk-sr-execute-hint' ).hide();
					$( '#tsosk-sr-preview-wrap' ).hide();
					tsosk_sr_preview_data = null;
					if ( warnings.length ) {
						// Keep the page so the warnings can be read; the backup panel refreshes on the next load.
						var $warn = $( '<div class="tsosk-notice tsosk-notice-warn" style="margin-top:8px;"></div>' );
						$warn.append( $( '<strong></strong>' ).text( tsosk.i18n.sr_exec_warnings ) );
						$.each( warnings, function ( i, w ) {
							$warn.append( $( '<div></div>' ).text( String( w ) ) );
						} );
						$msg.after( $warn );
					} else {
						// Reload after 1.5s to refresh history
						setTimeout( function () { window.location.reload(); }, 1500 );
					}
				} else {
					showMsg( $msg, r.data || tsosk.i18n.error, 'error' );
				}
			},
			error: function () {
				showMsg( $msg, tsosk.i18n.error, 'error' );
				$btn.prop( 'disabled', false );
				$( '#tsosk-sr-preview-btn' ).prop( 'disabled', false );
			}
		} );
	} );

	// ── Cancel ──
	$( document ).on( 'click', '#tsosk-sr-cancel-btn', function () {
		tsosk_sr_invalidate_preview();
		$( '#tsosk-sr-preview-wrap' ).hide();
	} );

	// ── Restore automatic backup ──
	$( document ).on( 'click', '#tsosk-sr-backup-restore-btn', function () {
		var $btn     = $( this );
		var origText = $btn.text();
		var $msg     = $( '#tsosk-sr-backup-msg' );

		if ( ! confirm( tsosk.i18n.sr_backup_confirm_restore ) ) { return; }

		$btn.prop( 'disabled', true ).text( tsosk.i18n.loading );
		ajaxPost( {
			action : 'tsosk_sr_restore_backup',
			data   : { nonce: $btn.data( 'nonce' ) },
			success: function ( r ) {
				if ( r.success ) {
					showMsg( $msg, r.data.message, 'ok' );
					setTimeout( function () { window.location.reload(); }, 1500 );
				} else {
					showMsg( $msg, r.data || tsosk.i18n.error, 'error' );
					$btn.prop( 'disabled', false ).text( origText );
				}
			},
			error: function () {
				showMsg( $msg, tsosk.i18n.error, 'error' );
				$btn.prop( 'disabled', false ).text( origText );
			}
		} );
	} );

	// ── Activity History: undo one entry ──
	$( document ).on( 'click', '.tsosk-history-undo-btn', function () {
		var $btn = $( this );
		var $cell = $btn.closest( 'td' );
		if ( ! confirm( tsosk.i18n.history_undo_confirm ) ) { return; }
		$btn.prop( 'disabled', true ).text( tsosk.i18n.loading );
		ajaxPost( {
			action : 'tsosk_history_undo',
			data   : { nonce: $btn.data( 'nonce' ), id: $btn.data( 'id' ) },
			success: function ( r ) {
				if ( r.success ) {
					$cell.html( '<span class="tsosk-badge tsosk-badge-info">' + tsosk.i18n.history_reverted + '</span>' );
				} else {
					alert( r.data || tsosk.i18n.error );
					$btn.prop( 'disabled', false ).text( tsosk.i18n.undo );
				}
			},
			error: function () {
				alert( tsosk.i18n.error );
				$btn.prop( 'disabled', false ).text( tsosk.i18n.undo );
			}
		} );
	} );

	// ── Activity History: clear log ──
	$( document ).on( 'click', '#tsosk-history-clear', function () {
		var $btn = $( this );
		var $msg = $( '#tsosk-history-msg' );
		if ( ! confirm( tsosk.i18n.history_clear ) ) { return; }
		$btn.prop( 'disabled', true );
		ajaxPost( {
			action : 'tsosk_history_clear',
			data   : { nonce: $btn.data( 'nonce' ) },
			success: function ( r ) {
				if ( r.success ) {
					showMsg( $msg, r.data, 'ok' );
					setTimeout( function () { window.location.reload(); }, 800 );
				} else {
					showMsg( $msg, r.data || tsosk.i18n.error, 'error' );
					$btn.prop( 'disabled', false );
				}
			},
			error: function () {
				showMsg( $msg, tsosk.i18n.error, 'error' );
				$btn.prop( 'disabled', false );
			}
		} );
	} );

	$( document ).on( 'change', '#tsosk-history-log-all', function () {
		var on = $( this ).is( ':checked' );
		$( '#tsosk-history-modules' ).css( 'opacity', on ? '0.55' : '1' );
		if ( on ) {
			$( '.tsosk-history-module' ).prop( 'checked', true );
		}
	} );

	$( document ).on( 'click', '#tsosk-history-save-settings', function () {
		var $btn = $( this );
		var $msg = $( '#tsosk-history-settings-msg' );
		var modules = $( '.tsosk-history-module:checked' ).map( function () {
			return $( this ).val();
		} ).get();

		$btn.prop( 'disabled', true );
		ajaxPost( {
			action : 'tsosk_history_save',
			data   : {
				nonce   : $btn.data( 'nonce' ),
				log_all : $( '#tsosk-history-log-all' ).is( ':checked' ) ? 1 : 0,
				limit   : $( '#tsosk-history-limit' ).val(),
				modules : modules
			},
			success: function ( r ) {
				showMsg( $msg, r.success ? r.data : ( r.data || tsosk.i18n.error ), r.success ? 'ok' : 'error' );
				$btn.prop( 'disabled', false );
			},
			error: function () {
				showMsg( $msg, tsosk.i18n.error, 'error' );
				$btn.prop( 'disabled', false );
			}
		} );
	} );

	// ── Content Audit: remove broken shortcodes ──
	function tsoskCaRemoveShortcode( postId, shortcode, $btn ) {
		var $msg = $( '#tsosk-ca-shortcodes-msg' );
		// Lock every button of the table: two removals on the same post would read the same content
		// and the second save would silently undo the first.
		var $all = $( '#tsosk-ca-shortcodes-table button' ).add( $btn );
		$all.prop( 'disabled', true );
		ajaxPost( {
			action : 'tsosk_ca_remove_shortcode',
			data   : {
				nonce     : $btn.data( 'nonce' ),
				post_id   : postId,
				shortcode : shortcode || ''
			},
			success: function ( r ) {
				if ( r.success ) {
					showMsg( $msg, r.data.message || tsosk.i18n.done, 'ok' );
					setTimeout( function () { window.location.reload(); }, 900 );
				} else {
					showMsg( $msg, r.data || tsosk.i18n.error, 'error' );
					$all.prop( 'disabled', false );
				}
			},
			error: function () {
				showMsg( $msg, tsosk.i18n.error, 'error' );
				$all.prop( 'disabled', false );
			}
		} );
	}

	$( document ).on( 'click', '.tsosk-ca-remove-sc', function () {
		var $btn = $( this );
		if ( ! confirm( tsosk.i18n.ca_remove_sc_confirm ) ) { return; }
		tsoskCaRemoveShortcode( $btn.data( 'postId' ), $btn.data( 'shortcode' ), $btn );
	} );

	$( document ).on( 'click', '.tsosk-ca-remove-all-sc', function () {
		var $btn = $( this );
		if ( ! confirm( tsosk.i18n.ca_remove_all_confirm ) ) { return; }
		tsoskCaRemoveShortcode( $btn.data( 'postId' ), '', $btn );
	} );

	// ── Meta Editor ───────────────────────────────────────────────────────────
	var tsoskMe = { currentPage: 1, lastSearch: '', context: 'post', editingId: 0, editingContext: 'post' };
	var tsosk_me_search_seq = 0;

	function tsoskMeSearch( page ) {
		if ( ! $( '#tsosk-me-search-btn' ).length ) { return; }
		tsoskMe.currentPage = page || 1;
		var newContext      = $( '#tsosk-me-context' ).val() || 'post';
		if ( newContext !== tsoskMe.context ) {
			// Context changed: the open editor row belongs to the other table, so close it.
			tsoskMe.editingId = 0;
			$( '#tsosk-me-editor' ).hide();
		}
		tsoskMe.context     = newContext;
		tsoskMe.lastSearch  = $( '#tsosk-me-search' ).val().trim();
		var nonce    = $( '#tsosk-me-search-btn' ).data( 'nonce' );
		var $msg     = $( '#tsosk-me-search-msg' );
		var $tbody   = $( '#tsosk-me-tbody' );
		var reqId    = ++tsosk_me_search_seq;
		$tbody.html( '<tr><td colspan="5" style="text-align:center;">' + tsosk.i18n.loading + '</td></tr>' );
		ajaxPost( {
			action : 'tsosk_me_search',
			data   : {
				nonce     : nonce,
				context   : tsoskMe.context,
				search    : tsoskMe.lastSearch,
				object_id : $( '#tsosk-me-object-id' ).val() || 0,
				page      : tsoskMe.currentPage
			},
			success: function ( r ) {
				if ( reqId !== tsosk_me_search_seq ) {
					return;
				}
				if ( ! r.success ) {
					showMsg( $msg, r.data || tsosk.i18n.error, 'error' );
					$tbody.html( '<tr><td colspan="5">' + tsosk.i18n.oe_no_results + '</td></tr>' );
					return;
				}
				tsoskMeRender( r.data );
				showMsg( $msg, r.data.total + ' rows', 'ok' );
			},
			error: function () {
				if ( reqId !== tsosk_me_search_seq ) {
					return;
				}
				showMsg( $msg, tsosk.i18n.error, 'error' );
			}
		} );
	}

	function tsoskMeRender( data ) {
		var $tbody = $( '#tsosk-me-tbody' );
		var items  = data.items || [];
		$tbody.empty();
		if ( ! items.length ) {
			$tbody.append( '<tr><td colspan="5" style="text-align:center;color:#646970;">' + tsosk.i18n.oe_no_results + '</td></tr>' );
			$( '#tsosk-me-pagination' ).html( '' );
			return;
		}
		items.forEach( function ( row ) {
			var prot = row.protected ? ' <span class="tsosk-badge">' + tsosk.i18n.oe_protected + '</span>' : '';
			var $tr  = $( '<tr></tr>' );
			$tr.append( '<td>' + row.meta_id + '</td>' );
			$tr.append( '<td>' + row.object_id + '</td>' );
			$tr.append( '<td><code>' + $( '<span>' ).text( row.key ).html() + '</code>' + prot + '</td>' );
			$tr.append( '<td><code style="font-size:11px;">' + $( '<span>' ).text( row.preview ).html() + '</code></td>' );
			var $btn = $( '<button type="button" class="button button-small tsosk-me-edit">' + tsosk.i18n.oe_edit + '</button>' );
			$btn.data( 'meta', row );
			if ( row.protected ) { $btn.prop( 'disabled', true ); }
			$tr.append( $( '<td></td>' ).append( $btn ) );
			$tbody.append( $tr );
		} );
		var pg = data.total_pages || 1;
		var $pag = $( '#tsosk-me-pagination' );
		$pag.html( '' );
		if ( pg > 1 ) {
			for ( var p = 1; p <= pg; p++ ) {
				$pag.append( $( '<button type="button" class="button button-small tsosk-me-page">' + p + '</button>' ).data( 'page', p ) );
			}
		}
	}

	$( document ).on( 'click', '#tsosk-me-search-btn', function () { tsoskMeSearch( 1 ); } );
	$( document ).on( 'keydown', '#tsosk-me-search', function ( e ) {
		if ( e.key === 'Enter' ) { tsoskMeSearch( 1 ); }
	} );
	$( document ).on( 'change', '#tsosk-me-context', function () { tsoskMeSearch( 1 ); } );
	$( document ).on( 'click', '.tsosk-me-page', function () { tsoskMeSearch( $( this ).data( 'page' ) ); } );

	$( document ).on( 'click', '.tsosk-me-edit', function () {
		var row = $( this ).data( 'meta' );
		var nonce = $( '#tsosk-me-save' ).data( 'nonce' );
		ajaxPost( {
			action : 'tsosk_me_get',
			data   : { nonce: nonce, context: tsoskMe.context, meta_id: row.meta_id },
			success: function ( r ) {
				if ( r.success ) {
					tsoskMe.editingId      = r.data.meta_id;
					tsoskMe.editingContext = tsoskMe.context;
					$( '#tsosk-me-editor' ).show();
					$( '#tsosk-me-edit-key' ).text( r.data.key );
					$( '#tsosk-me-edit-object' ).text( r.data.object_id );
					$( '#tsosk-me-edit-value' ).val( r.data.value ).prop( 'disabled', r.data.protected );
					$( '#tsosk-me-save, #tsosk-me-delete' ).prop( 'disabled', r.data.protected );
					$( '#tsosk-me-edit-msg' ).hide().text( '' );
				} else {
					showMsg( $( '#tsosk-me-search-msg' ), r.data || tsosk.i18n.error, 'error' );
				}
			},
			error: function () {
				showMsg( $( '#tsosk-me-search-msg' ), tsosk.i18n.error, 'error' );
			}
		} );
	} );

	$( document ).on( 'click', '#tsosk-me-save', function () {
		var $msg = $( '#tsosk-me-edit-msg' );
		if ( ! tsoskMe.editingId ) { return; }
		ajaxPost( {
			action : 'tsosk_me_save',
			data   : {
				nonce   : $( this ).data( 'nonce' ),
				context : tsoskMe.editingContext,
				meta_id : tsoskMe.editingId,
				value   : $( '#tsosk-me-edit-value' ).val()
			},
			success: function ( r ) {
				showMsg( $msg, r.success ? r.data : ( r.data || tsosk.i18n.error ), r.success ? 'ok' : 'error' );
				if ( r.success ) { tsoskMeSearch( tsoskMe.currentPage ); }
			}
		} );
	} );

	$( document ).on( 'click', '#tsosk-me-delete', function () {
		if ( ! window.confirm( tsosk.i18n.oe_confirm_del ) ) { return; }
		var $msg = $( '#tsosk-me-edit-msg' );
		if ( ! tsoskMe.editingId ) { return; }
		ajaxPost( {
			action : 'tsosk_me_delete',
			data   : { nonce: $( this ).data( 'nonce' ), context: tsoskMe.editingContext, meta_id: tsoskMe.editingId },
			success: function ( r ) {
				showMsg( $msg, r.success ? r.data : ( r.data || tsosk.i18n.error ), r.success ? 'ok' : 'error' );
				if ( r.success ) {
					$( '#tsosk-me-editor' ).hide();
					tsoskMeSearch( tsoskMe.currentPage );
				}
			}
		} );
	} );

	$( document ).on( 'click', '#tsosk-me-add-btn', function () {
		var $msg = $( '#tsosk-me-add-msg' );
		ajaxPost( {
			action : 'tsosk_me_add',
			data   : {
				nonce     : $( this ).data( 'nonce' ),
				context   : tsoskMe.context,
				object_id : $( '#tsosk-me-add-object' ).val(),
				meta_key  : $( '#tsosk-me-add-key' ).val(),
				value     : $( '#tsosk-me-add-value' ).val()
			},
			success: function ( r ) {
				showMsg( $msg, r.success ? r.data : ( r.data || tsosk.i18n.error ), r.success ? 'ok' : 'error' );
				if ( r.success ) {
					// Show the new row: filter by the object it was added to and drop the text filter.
					$( '#tsosk-me-object-id' ).val( $( '#tsosk-me-add-object' ).val() );
					$( '#tsosk-me-search' ).val( '' );
					tsoskMeSearch( 1 );
				}
			}
		} );
	} );

	// ── Option Library preview ────────────────────────────────────────────────
	$( document ).on( 'click', '.tsosk-ol-preview', function ( e ) {
		e.preventDefault();
		e.stopPropagation();

		var $btn   = $( this );
		var $box   = $( '#tsosk-ol-preview-box' );
		var $msg   = $( '#tsosk-ol-preview-msg' );
		var name   = $btn.attr( 'data-name' ) || $btn.data( 'name' );
		var nonce  = $btn.attr( 'data-nonce' ) || $btn.data( 'nonce' );
		var label  = $btn.data( 'save-label' ) || $btn.text();

		if ( ! name || ! nonce || ! $box.length ) {
			showMsg( $msg, tsosk.i18n.error, 'error' );
			return;
		}

		$( '.tsosk-ol-option-row' ).removeClass( 'is-preview-active' );
		$btn.closest( '.tsosk-ol-option-row' ).addClass( 'is-preview-active' );

		$btn.prop( 'disabled', true ).text( tsosk.i18n.running );
		$box.show();
		$( '#tsosk-ol-preview-hint' ).hide();

		ajaxPost( {
			action : 'tsosk_ol_preview',
			data   : { nonce: nonce, name: name },
			success: function ( r ) {
				if ( r && r.success && r.data ) {
					$( '#tsosk-ol-preview-name' ).text( r.data.name );
					var meta = 'autoload: ' + r.data.autoload + ', ' + r.data.size + ' bytes';
					if ( r.data.protected ) {
						meta += ' — ' + ( tsosk.i18n.oe_protected || 'Protected' );
					}
					$( '#tsosk-ol-preview-meta' ).text( meta );
					$( '#tsosk-ol-preview-value' ).text( r.data.preview || '' );
					$( '#tsosk-ol-preview-edit' ).attr( 'href', r.data.edit_url || '#' );
					var loaded = tsosk.i18n.ol_preview_loaded || tsosk.i18n.done;
					showMsg( $msg, loaded, 'ok' );
					if ( $box[0] && $box[0].scrollIntoView ) {
						$box[0].scrollIntoView( { behavior: 'smooth', block: 'nearest' } );
					}
				} else {
					var err = ( r && r.data ) ? ( r.data.message || r.data ) : tsosk.i18n.error;
					showMsg( $msg, err, 'error' );
				}
				$btn.prop( 'disabled', false ).text( label );
			},
			error: function () {
				showMsg( $msg, tsosk.i18n.error, 'error' );
				$btn.prop( 'disabled', false ).text( label );
			}
		} );
	} );

	// ── Site Snapshot import ──────────────────────────────────────────────────
	function tsoskSnapshotRefreshEnvDiff( data ) {
		var $box   = $( '#tsosk-snapshot-env-diff' );
		var $tbody = $( '#tsosk-snapshot-env-diff-table tbody' );
		var cur    = ( typeof tsosk !== 'undefined' && tsosk.snapshot_current_env ) ? tsosk.snapshot_current_env : {};
		var i18n   = ( typeof tsosk !== 'undefined' && tsosk.i18n ) ? tsosk.i18n : {};

		$tbody.empty();
		if ( ! data || 'tsosk-site-snapshot' !== data.format ) {
			$box.prop( 'hidden', true );
			return;
		}

		var fields = [
			{ label: i18n.snapshot_env_site_url || 'Site URL', file: data.site_url || '', current: cur.site_url || '', kind: 'url' },
			{ label: i18n.snapshot_env_wp_version || 'WordPress version', file: data.wp_version || '', current: cur.wp_version || '', kind: 'text' },
			{ label: i18n.snapshot_env_plugin || 'Snapshot schema', file: String( data.version || '' ), current: String( cur.schema_version || '' ), kind: 'text' },
			{ label: i18n.snapshot_env_php || 'PHP version', file: data.php_version || '', current: cur.php_version || '', kind: 'text' },
			{ label: i18n.snapshot_env_locale || 'Locale', file: data.locale || '', current: cur.locale || '', kind: 'locale' }
		];

		fields.forEach( function ( f ) {
			if ( ! f.file && ! f.current ) {
				return;
			}
			var left  = String( f.file || '' );
			var right = String( f.current || '' );
			if ( 'url' === f.kind ) {
				left  = left.replace( /\/+$/, '' ).toLowerCase();
				right = right.replace( /\/+$/, '' ).toLowerCase();
			} else if ( 'locale' === f.kind ) {
				left  = left.toLowerCase().replace( /-/g, '_' );
				right = right.toLowerCase().replace( /-/g, '_' );
			}
			var diff = left !== right;
			var $tr  = $( '<tr></tr>' );
			if ( diff ) {
				$tr.addClass( 'tsosk-snapshot-env-diff-warn' );
			}
			$tr.append( $( '<td></td>' ).text( f.label ) );
			$tr.append( $( '<td></td>' ).text( f.file || '—' ) );
			$tr.append( $( '<td></td>' ).text( f.current || '—' ) );
			$tbody.append( $tr );
		} );

		if ( $tbody.children().length ) {
			$box.prop( 'hidden', false );
		} else {
			$box.prop( 'hidden', true );
		}
	}

	function tsoskSnapshotRefreshImportSections() {
		var $box    = $( '#tsosk-snapshot-import-sections' );
		var $list   = $( '#tsosk-snapshot-import-list' );
		var json    = $( '#tsosk-snapshot-json' ).val().trim();
		var labels = ( typeof tsosk !== 'undefined' && tsosk.snapshot_section_labels )
			? tsosk.snapshot_section_labels
			: {};

		$list.empty();
		if ( ! json ) {
			$box.hide();
			tsoskSnapshotRefreshEnvDiff( null );
			return;
		}

		var data;
		try {
			data = JSON.parse( json );
		} catch ( e ) {
			$box.hide();
			tsoskSnapshotRefreshEnvDiff( null );
			return;
		}

		tsoskSnapshotRefreshEnvDiff( data );

		var sections = data.sections || {};
		var keys = Object.keys( sections );
		if ( ! keys.length ) {
			$box.hide();
			return;
		}

		keys.forEach( function ( id ) {
			var label = labels[ id ] || id;
			var $li = $( '<li style="margin-bottom:6px;"></li>' );
			var $label = $( '<label></label>' );
			var operational = ( typeof tsosk !== 'undefined' && tsosk.snapshot_operational ) ? tsosk.snapshot_operational : [];
			var $cb = $( '<input type="checkbox" class="tsosk-snapshot-import-section">' ).val( id );
			// Operational logs (lockouts, attempts, manifests) are unchecked by default, like on export.
			$cb.prop( 'checked', operational.indexOf( id ) === -1 );
			$label.append( $cb ).append( document.createTextNode( ' ' + String( label ) ) );
			$li.append( $label );
			$list.append( $li );
		} );
		$box.show();
	}

	$( document ).on( 'submit', '#tsosk-snapshot-export-form', function () {
		var checked = $( this ).find( 'input[name="sections[]"]:checked' ).length;
		if ( checked < 1 ) {
			window.alert( tsosk.i18n.snapshot_no_sections );
			return false;
		}
	} );

	$( document ).on( 'click', '#tsosk-snapshot-file-btn', function () {
		$( '#tsosk-snapshot-file' ).trigger( 'click' );
	} );

	$( document ).on( 'change', '#tsosk-snapshot-file', function ( e ) {
		var file = e.target.files && e.target.files[0];
		var $msg = $( '#tsosk-snapshot-msg' );
		var $name = $( '#tsosk-snapshot-file-name' );
		var noneLabel = ( tsosk.i18n && tsosk.i18n.snapshot_no_file ) ? tsosk.i18n.snapshot_no_file : '';
		if ( ! file ) {
			if ( noneLabel ) {
				$name.text( noneLabel );
			}
			return;
		}
		$name.text( file.name );
		var reader = new FileReader();
		reader.onload = function ( ev ) {
			$( '#tsosk-snapshot-json' ).val( ev.target.result || '' );
			tsoskSnapshotRefreshImportSections();
			$msg.hide().text( '' );
		};
		reader.onerror = function () {
			showMsg( $msg, tsosk.i18n.error, 'error' );
		};
		reader.readAsText( file );
	} );

	$( document ).on( 'input', '#tsosk-snapshot-json', tsoskSnapshotRefreshImportSections );

	$( document ).on( 'click', '#tsosk-snapshot-import', function () {
		var $btn = $( this );
		var $msg = $( '#tsosk-snapshot-msg' );
		var json = $( '#tsosk-snapshot-json' ).val().trim();
		if ( ! json ) {
			showMsg( $msg, tsosk.i18n.error, 'error' );
			return;
		}
		if ( ! $( '#tsosk-snapshot-import-sections' ).is( ':visible' ) ) {
			showMsg( $msg, tsosk.i18n.snapshot_invalid_json || tsosk.i18n.error, 'error' );
			return;
		}
		if ( ! window.confirm( tsosk.i18n.snapshot_confirm_import ) ) { return; }

		var importSections = [];
		$( '.tsosk-snapshot-import-section:checked' ).each( function () {
			importSections.push( $( this ).val() );
		} );
		if ( importSections.length < 1 ) {
			window.alert( tsosk.i18n.snapshot_no_sections );
			return;
		}

		$btn.prop( 'disabled', true );
		ajaxPost( {
			action : 'tsosk_snapshot_import',
			data   : { nonce: $btn.data( 'nonce' ), snapshot: json, import_sections: importSections },
			success: function ( r ) {
				if ( r.success ) {
					$( '#tsosk-snapshot-json' ).val( '' );
					$( '#tsosk-snapshot-file' ).val( '' );
					$( '#tsosk-snapshot-file-name' ).text( tsosk.i18n.snapshot_no_file || '' );
					$( '#tsosk-snapshot-import-sections' ).hide();
					$( '#tsosk-snapshot-import-list' ).empty();
					tsoskSnapshotRefreshEnvDiff( null );
					showMsg( $msg, r.data || tsosk.i18n.done, 'ok' );
				} else {
					showMsg( $msg, r.data || tsosk.i18n.error, 'error' );
				}
				$btn.prop( 'disabled', false );
			},
			error: function () {
				showMsg( $msg, tsosk.i18n.error, 'error' );
				$btn.prop( 'disabled', false );
			}
		} );
	} );

	$( document ).on( 'click', '#tsosk-snapshot-restore', function () {
		var $btn = $( this );
		var $msg = $( '#tsosk-snapshot-restore-msg' );
		if ( ! window.confirm( tsosk.i18n.snapshot_confirm_restore ) ) { return; }
		$btn.prop( 'disabled', true );
		ajaxPost( {
			action : 'tsosk_snapshot_restore',
			data   : { nonce: $btn.data( 'nonce' ) },
			success: function ( r ) {
				if ( r.success ) {
					showMsg( $msg, r.data || tsosk.i18n.done, 'ok' );
					$btn.closest( '.tsosk-snapshot-restore-card' ).find( 'button' ).hide();
				} else {
					showMsg( $msg, r.data || tsosk.i18n.error, 'error' );
					$btn.prop( 'disabled', false );
				}
			},
			error: function () {
				showMsg( $msg, tsosk.i18n.error, 'error' );
				$btn.prop( 'disabled', false );
			}
		} );
	} );

	// ── Action Scheduler ─────────────────────────────────────────────────────

	var tsoskAschedPage = 1;

	function tsoskEscHtml( text ) {
		return $( '<div/>' ).text( text == null ? '' : String( text ) ).html();
	}

	function tsoskAschedLoad( page ) {
		var $tbody = $( '#tsosk-asched-tbody' );
		var $msg   = $( '#tsosk-asched-msg' );
		var nonce  = $( '#tsosk-asched-nonce' ).val();
		if ( ! $tbody.length || ! nonce ) { return; }

		tsoskAschedPage = page || 1;
		$tbody.html( '<tr><td colspan="6">' + tsosk.i18n.loading + '</td></tr>' );

		ajaxPost( {
			action : 'tsosk_asched_list',
			data   : {
				nonce  : nonce,
				status : $( '#tsosk-asched-status' ).val(),
				page   : tsoskAschedPage
			},
			success: function ( r ) {
				if ( ! r.success ) {
					showMsg( $msg, r.data || tsosk.i18n.error, 'error' );
					$tbody.html( '<tr><td colspan="6">' + tsosk.i18n.error + '</td></tr>' );
					return;
				}
				var rows = r.data.rows || [];
				if ( ! rows.length ) {
					$tbody.html( '<tr><td colspan="6">' + tsosk.i18n.no_matches + '</td></tr>' );
				} else {
					var html = '';
					rows.forEach( function ( row ) {
						var status = row.status || '';
						var canCancel = status === 'pending' || status === 'in-progress';
						html += '<tr data-id="' + row.id + '">';
						html += '<td>' + row.id + '</td>';
						html += '<td class="tsosk-code">' + tsoskEscHtml( row.hook || '—' ) + '</td>';
						html += '<td>' + tsoskEscHtml( row.group || '—' ) + '</td>';
						html += '<td>' + tsoskEscHtml( status || '—' ) + '</td>';
						html += '<td>' + tsoskEscHtml( row.schedule || '—' ) + '</td>';
						html += '<td class="tsosk-actions">';
						if ( canCancel ) {
							html += '<button type="button" class="button button-small tsosk-asched-cancel" data-id="' + row.id + '">' + tsoskEscHtml( tsosk.i18n.cancel ) + '</button> ';
						}
						html += '<button type="button" class="button button-small tsosk-asched-delete" data-id="' + row.id + '">' + tsoskEscHtml( tsosk.i18n.delete ) + '</button>';
						html += '</td></tr>';
					} );
					$tbody.html( html );
				}
				var pages = r.data.pages || 1;
				var $pag  = $( '#tsosk-asched-pagination' );
				$pag.empty();
				$pag.append(
					'<span style="font-size:12px;color:#646970;margin-right:8px;">' +
					tsosk.i18n.sr_rows + ': ' + ( r.data.total || 0 ) + ' · ' +
					tsoskAschedPage + '/' + pages + '</span>'
				);
				if ( tsoskAschedPage > 1 ) {
					$pag.append( ' <button type="button" class="button button-small tsosk-asched-page" data-page="' + ( tsoskAschedPage - 1 ) + '">&larr; ' + tsosk.i18n.previous + '</button>' );
				}
				if ( tsoskAschedPage < pages ) {
					$pag.append( ' <button type="button" class="button button-small tsosk-asched-page" data-page="' + ( tsoskAschedPage + 1 ) + '">' + tsosk.i18n.next + ' &rarr;</button>' );
				}
				showMsg( $msg, '', 'ok' );
			},
			error: function () {
				showMsg( $msg, tsosk.i18n.error, 'error' );
				$tbody.html( '<tr><td colspan="6">' + tsosk.i18n.error + '</td></tr>' );
			}
		} );
	}

	if ( $( '#tsosk-asched-tbody' ).length ) {
		tsoskAschedLoad( 1 );
	}

	$( document ).on( 'click', '#tsosk-asched-refresh', function () {
		tsoskAschedLoad( 1 );
	} );

	$( document ).on( 'change', '#tsosk-asched-status', function () {
		tsoskAschedLoad( 1 );
	} );

	$( document ).on( 'click', '.tsosk-asched-page', function () {
		tsoskAschedLoad( parseInt( $( this ).data( 'page' ), 10 ) || 1 );
	} );

	$( document ).on( 'click', '.tsosk-asched-cancel', function () {
		if ( ! window.confirm( tsosk.i18n.asched_cancel_confirm ) ) { return; }
		var id    = $( this ).data( 'id' );
		var nonce = $( '#tsosk-asched-nonce' ).val();
		var $msg  = $( '#tsosk-asched-msg' );
		ajaxPost( {
			action : 'tsosk_asched_cancel',
			data   : { nonce: nonce, action_id: id },
			success: function ( r ) {
				showMsg( $msg, r.success ? r.data : ( r.data || tsosk.i18n.error ), r.success ? 'ok' : 'error' );
				if ( r.success ) { tsoskAschedLoad( tsoskAschedPage ); }
			},
			error: function () { showMsg( $msg, tsosk.i18n.error, 'error' ); }
		} );
	} );

	$( document ).on( 'click', '.tsosk-asched-delete', function () {
		if ( ! window.confirm( tsosk.i18n.confirm_delete ) ) { return; }
		var id    = $( this ).data( 'id' );
		var nonce = $( '#tsosk-asched-nonce' ).val();
		var $msg  = $( '#tsosk-asched-msg' );
		ajaxPost( {
			action : 'tsosk_asched_delete',
			data   : { nonce: nonce, action_id: id },
			success: function ( r ) {
				showMsg( $msg, r.success ? r.data : ( r.data || tsosk.i18n.error ), r.success ? 'ok' : 'error' );
				if ( r.success ) { tsoskAschedLoad( tsoskAschedPage ); }
			},
			error: function () { showMsg( $msg, tsosk.i18n.error, 'error' ); }
		} );
	} );

	// ── Roles & capabilities ─────────────────────────────────────────────────

	function tsoskEncodeRoleSlug( slug ) {
		try {
			return window.btoa( unescape( encodeURIComponent( slug || '' ) ) );
		} catch ( e ) {
			return slug || '';
		}
	}

	function tsoskText( value ) {
		return $( '<div>' ).text( value == null ? '' : String( value ) ).html();
	}

	function tsoskRolesLoad() {
		var $tbody = $( '#tsosk-roles-tbody' );
		var $msg   = $( '#tsosk-roles-msg' );
		var nonce  = $( '#tsosk-roles-nonce' ).val();
		var role   = $( '#tsosk-roles-select' ).val();
		if ( ! $tbody.length || ! nonce ) { return; }

		$tbody.html( '<tr><td colspan="3">' + tsoskText( tsosk.i18n.loading ) + '</td></tr>' );

		ajaxPost( {
			action : 'tsosk_roles_caps',
			data   : { nonce: nonce, role_slug: tsoskEncodeRoleSlug( role ) },
			success: function ( r ) {
				if ( ! r.success ) {
					var errText = typeof r.data === 'string' ? r.data : tsosk.i18n.error;
					showMsg( $msg, errText, 'error' );
					$tbody.html( '<tr><td colspan="3">' + tsoskText( errText ) + '</td></tr>' );
					return;
				}
				var caps = r.data.caps || [];
				$( '#tsosk-roles-count' ).text( caps.length );
				if ( ! caps.length ) {
					$tbody.html( '<tr><td colspan="3">' + tsoskText( tsosk.i18n.no_matches ) + '</td></tr>' );
					return;
				}
				var isAdmin = role === 'administrator' || r.data.read_only;
				var html    = '';
				caps.forEach( function ( item ) {
					var cap  = typeof item === 'string' ? item : ( item.cap || '' );
					var desc = typeof item === 'object' && item.description ? item.description : '';
					var danger = item.dangerous ? ' <span class="tsosk-badge tsosk-badge-warn">' + tsoskText( tsosk.i18n.dangerous_cap || 'Risk' ) + '</span>' : '';
					html += '<tr><td class="tsosk-code">' + tsoskText( cap ) + danger + '</td><td class="description">' + tsoskText( desc || '—' ) + '</td><td>';
					if ( ! isAdmin ) {
						html += '<button type="button" class="button button-small tsosk-roles-remove" data-cap="' + tsoskText( cap ) + '">' + tsoskText( tsosk.i18n.delete ) + '</button>';
					} else {
						html += '—';
					}
					html += '</td></tr>';
				} );
				$tbody.html( html );
				$( '#tsosk-roles-add-box' ).toggle( ! isAdmin );
				if ( isAdmin && r.data.admin_role ) {
					showMsg( $msg, tsosk.i18n.roles_admin_readonly || tsosk.i18n.done, 'ok' );
				} else {
					showMsg( $msg, tsosk.i18n.done, 'ok' );
				}
			},
			error: function () {
				showMsg( $msg, tsosk.i18n.error, 'error' );
				$tbody.html( '<tr><td colspan="3">' + tsoskText( tsosk.i18n.error ) + '</td></tr>' );
			}
		} );
	}

	$( document ).on( 'click', '#tsosk-roles-load', tsoskRolesLoad );
	$( document ).on( 'change', '#tsosk-roles-select', tsoskRolesLoad );
	if ( $( '#tsosk-roles-select' ).length && $( '#tsosk-roles-nonce' ).val() ) {
		tsoskRolesLoad();
	}

	$( document ).on( 'click', '#tsosk-health-save-suppress', function () {
		var $btn  = $( this );
		var nonce = $btn.data( 'nonce' );
		var $msg  = $( '#tsosk-health-suppress-msg' );
		$btn.prop( 'disabled', true );
		ajaxPost( {
			action : 'tsosk_health_save_suppress',
			data   : {
				nonce: nonce,
				suppress_blog_public: $( '#tsosk-health-suppress-blog-public' ).is( ':checked' ) ? 1 : 0,
				suppress_debug_enabled: $( '#tsosk-health-suppress-debug' ).is( ':checked' ) ? 1 : 0,
				suppress_inactive_plugins: $( '#tsosk-health-suppress-inactive-plugins' ).is( ':checked' ) ? 1 : 0,
				suppress_inactive_themes: $( '#tsosk-health-suppress-inactive-themes' ).is( ':checked' ) ? 1 : 0
			},
			success: function ( r ) {
				showMsg( $msg, r.success ? ( r.data || tsosk.i18n.done ) : ( r.data || tsosk.i18n.error ), r.success ? 'ok' : 'error' );
				$btn.prop( 'disabled', false );
			},
			error: function () {
				showMsg( $msg, tsosk.i18n.error, 'error' );
				$btn.prop( 'disabled', false );
			}
		} );
	} );

	$( document ).on( 'click', '#tsosk-roles-add-cap', function () {
		var cap   = $( '#tsosk-roles-new-cap' ).val().trim();
		var role  = $( '#tsosk-roles-select' ).val();
		var nonce = $( '#tsosk-roles-nonce' ).val();
		var $msg  = $( '#tsosk-roles-msg' );
		if ( ! cap ) { return; }
		ajaxPost( {
			action : 'tsosk_roles_add_cap',
			data   : { nonce: nonce, role_slug: tsoskEncodeRoleSlug( role ), cap: cap },
			success: function ( r ) {
				showMsg( $msg, r.success ? r.data : ( r.data || tsosk.i18n.error ), r.success ? 'ok' : 'error' );
				if ( r.success ) {
					$( '#tsosk-roles-new-cap' ).val( '' );
					tsoskRolesLoad();
				}
			},
			error: function () { showMsg( $msg, tsosk.i18n.error, 'error' ); }
		} );
	} );

	$( document ).on( 'click', '.tsosk-roles-remove', function () {
		if ( ! window.confirm( tsosk.i18n.confirm_delete ) ) { return; }
		var cap   = $( this ).data( 'cap' );
		var role  = $( '#tsosk-roles-select' ).val();
		var nonce = $( '#tsosk-roles-nonce' ).val();
		var $msg  = $( '#tsosk-roles-msg' );
		ajaxPost( {
			action : 'tsosk_roles_remove_cap',
			data   : { nonce: nonce, role_slug: tsoskEncodeRoleSlug( role ), cap: cap },
			success: function ( r ) {
				showMsg( $msg, r.success ? r.data : ( r.data || tsosk.i18n.error ), r.success ? 'ok' : 'error' );
				if ( r.success ) { tsoskRolesLoad(); }
			},
			error: function () { showMsg( $msg, tsosk.i18n.error, 'error' ); }
		} );
	} );

	$( document ).on( 'click', '#tsosk-roles-compare', function () {
		var nonce = $( '#tsosk-roles-nonce' ).val();
		var $out  = $( '#tsosk-roles-compare-out' );
		ajaxPost( {
			action : 'tsosk_roles_compare',
			data   : {
				nonce: nonce,
				role_a_slug: tsoskEncodeRoleSlug( $( '#tsosk-roles-compare-a' ).val() ),
				role_b_slug: tsoskEncodeRoleSlug( $( '#tsosk-roles-compare-b' ).val() )
			},
			success: function ( r ) {
				if ( ! r.success ) {
					$out.hide();
					return;
				}
				var d = r.data || {};
				var text = ( tsosk.i18n.roles_only_a || 'Only in A' ) + ':\n' + ( d.only_a || [] ).join( ', ' ) + '\n\n'
					+ ( tsosk.i18n.roles_only_b || 'Only in B' ) + ':\n' + ( d.only_b || [] ).join( ', ' ) + '\n\n'
					+ ( tsosk.i18n.roles_both || 'In both' ) + ':\n' + ( d.both || [] ).join( ', ' );
				$out.text( text ).show();
			}
		} );
	} );

	$( document ).on( 'click', '#tsosk-roles-clone', function () {
		var slug = $( '#tsosk-roles-clone-slug' ).val().trim();
		var label = $( '#tsosk-roles-clone-label' ).val().trim();
		if ( ! slug || ! label ) { return; }
		var $msg = $( '#tsosk-roles-msg' );
		ajaxPost( {
			action : 'tsosk_roles_clone',
			data   : {
				nonce: $( '#tsosk-roles-nonce' ).val(),
				source_slug: tsoskEncodeRoleSlug( $( '#tsosk-roles-select' ).val() ),
				new_role: slug,
				new_label: label
			},
			success: function ( r ) {
				showMsg( $msg, r.success ? r.data : ( r.data || tsosk.i18n.error ), r.success ? 'ok' : 'error' );
			},
			error: function () { showMsg( $msg, tsosk.i18n.error, 'error' ); }
		} );
	} );

	$( document ).on( 'click', '#tsosk-roles-apply-template', function () {
		if ( ! confirm( tsosk.i18n.roles_apply_confirm || tsosk.i18n.confirm_delete ) ) {
			return;
		}
		var $msg = $( '#tsosk-roles-msg' );
		ajaxPost( {
			action : 'tsosk_roles_apply_template',
			data   : {
				nonce: $( '#tsosk-roles-nonce' ).val(),
				role_slug: tsoskEncodeRoleSlug( $( '#tsosk-roles-select' ).val() ),
				template: $( '#tsosk-roles-template' ).val()
			},
			success: function ( r ) {
				showMsg( $msg, r.success ? r.data : ( r.data || tsosk.i18n.error ), r.success ? 'ok' : 'error' );
				if ( r.success ) { tsoskRolesLoad(); }
			},
			error: function () { showMsg( $msg, tsosk.i18n.error, 'error' ); }
		} );
	} );

	// ── Global tab search (Fase 4) ────────────────────────────────────────────

	var tsoskSearchActive = -1;

	// Lowercase and strip accents so "configuración" finds "configuracion".
	function tsoskSearchNorm( text ) {
		text = String( text || '' ).toLowerCase();
		if ( text.normalize ) {
			text = text.normalize( 'NFD' ).replace( /[̀-ͯ]/g, '' );
		}
		return text;
	}

	function tsoskSearchEscape( text ) {
		return String( text || '' ).replace( /[&<>"']/g, function ( c ) {
			return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[ c ];
		} );
	}

	// Query tokens: normalised, without surrounding dots (".htaccess" -> "htaccess").
	function tsoskSearchTokens( query ) {
		return tsoskSearchNorm( query ).split( /\s+/ ).map( function ( token ) {
			return token.replace( /^\.+|\.+$/g, '' );
		} ).filter( function ( token ) {
			return token.length > 0;
		} );
	}

	// Score one token against one tab (0 = no match). Label beats slug beats keywords.
	function tsoskSearchTokenScore( item, token ) {
		var variants = [ token ];
		if ( token.length > 3 && token.slice( -1 ) === 's' ) {
			variants.push( token.slice( 0, -1 ) ); // "redirects" -> "redirect".
		}
		var label = item.label_n || tsoskSearchNorm( item.label );
		var slug  = item.slug || '';
		var kw    = ' ' + ( item.kw || '' ) + ' ';
		var group = item.group_n || tsoskSearchNorm( item.group );
		var best  = 0;
		variants.forEach( function ( v ) {
			var score = 0;
			if ( label.indexOf( v ) === 0 ) {
				score = 6;
			} else if ( label.indexOf( ' ' + v ) > -1 ) {
				score = 5;
			} else if ( label.indexOf( v ) > -1 ) {
				score = 4;
			} else if ( slug.indexOf( v ) > -1 ) {
				score = 3;
			} else if ( kw.indexOf( ' ' + v ) > -1 || kw.indexOf( '.' + v ) > -1 ) {
				score = 2;
			} else if ( kw.indexOf( v ) > -1 ) {
				score = 1;
			} else if ( group.indexOf( v ) > -1 ) {
				score = 0.5;
			}
			best = Math.max( best, score );
		} );
		return best;
	}

	// Keyword words that explain why a tab matched (shown under the result title).
	function tsoskSearchHints( item, tokens ) {
		var label = item.label_n || '';
		var words = ( item.kw || '' ).split( ' ' );
		var hints = [];
		tokens.forEach( function ( token ) {
			if ( label.indexOf( token ) > -1 ) {
				return;
			}
			for ( var i = 0; i < words.length; i++ ) {
				if ( words[ i ] && words[ i ].indexOf( token ) > -1 ) {
					if ( hints.indexOf( words[ i ] ) === -1 ) {
						hints.push( words[ i ] );
					}
					break;
				}
			}
		} );
		return hints.slice( 0, 3 );
	}

	function tsoskSearchFilter( query ) {
		var items  = tsosk.tab_search || [];
		var tokens = tsoskSearchTokens( query );
		if ( ! tokens.length ) {
			return items.slice( 0, 12 ).map( function ( item ) {
				return { item: item, hints: [] };
			} );
		}
		var scored = items.map( function ( item ) {
			var total = 0, matched = 0;
			tokens.forEach( function ( token ) {
				var sc = tsoskSearchTokenScore( item, token );
				if ( sc > 0 ) {
					matched++;
					total += sc;
				}
			} );
			return { item: item, total: total, matched: matched, hints: tsoskSearchHints( item, tokens ) };
		} );
		// All words must match; if nothing does, fall back to tabs matching at least one word.
		var strict = scored.filter( function ( row ) {
			return row.matched === tokens.length;
		} );
		var rows = strict.length ? strict : scored.filter( function ( row ) {
			return row.matched > 0;
		} );
		rows.sort( function ( a, b ) {
			return ( b.matched - a.matched ) || ( b.total - a.total );
		} );
		return rows.slice( 0, 12 );
	}

	function tsoskSearchRender( matches ) {
		var $list = $( '#tsosk-global-search-results' );
		if ( ! $list.length ) {
			return;
		}
		tsoskSearchActive = -1;
		if ( ! matches.length ) {
			$list.html(
				'<li><span class="tsosk-search-no-results">' +
				( tsosk.i18n.search_no_results || tsosk.i18n.no_matches ) +
				'</span></li>'
			).prop( 'hidden', false );
			return;
		}
		var html = '';
		matches.forEach( function ( row, i ) {
			var item = row.item;
			var sub  = tsoskSearchEscape( item.group );
			if ( row.hints && row.hints.length ) {
				sub += ' · ' + row.hints.map( tsoskSearchEscape ).join( ', ' );
			}
			html += '<li data-index="' + i + '">' +
				'<a href="' + tsoskSearchEscape( item.url ) + '" class="tsosk-search-result">' +
				tsoskSearchEscape( item.label ) +
				'<span class="tsosk-search-result-group">' + sub + '</span>' +
				'</a></li>';
		} );
		$list.html( html ).prop( 'hidden', false );
	}

	// ── Jump to a section inside a tab (links from the finder end in #tsosk-go=<heading text>) ──
	function tsoskFindSection( needle ) {
		var target = tsoskSearchNorm( needle );
		var best   = null;
		var bestScore = 0;
		var scope  = document.getElementById( 'wpbody-content' ) || document.body;
		$( scope ).find( 'h1, h2, h3, h4, h5, summary, legend, th, label, strong, .tsosk-card-title' ).each( function () {
			var $el = $( this );
			if ( $el.closest( '#tsosk-global-search-results, #adminmenu, .tsosk-sidebar, .tsosk-favs, script, style' ).length ) {
				return;
			}
			var txt = tsoskSearchNorm( $el.text().replace( /\s+/g, ' ' ).trim() );
			if ( ! txt || txt.indexOf( target ) === -1 ) {
				return;
			}
			var score = txt.indexOf( target ) === 0 ? 3 : 1;
			if ( /^H[1-5]$/.test( this.tagName ) ) {
				score += 2;
			}
			if ( score > bestScore ) {
				best      = this;
				bestScore = score;
			}
		} );
		return best;
	}

	function tsoskGoToSection( attempt ) {
		var m = /^#tsosk-go=(.+)$/.exec( window.location.hash || '' );
		if ( ! m ) {
			return;
		}
		var needle;
		try {
			needle = decodeURIComponent( m[ 1 ] );
		} catch ( e ) {
			return;
		}
		var el = tsoskFindSection( needle );
		if ( ! el ) {
			if ( attempt < 4 ) {
				window.setTimeout( function () {
					tsoskGoToSection( attempt + 1 );
				}, 400 );
			}
			return;
		}
		$( el ).parents( 'details' ).prop( 'open', true );
		if ( el.tagName === 'SUMMARY' ) {
			$( el ).parent( 'details' ).prop( 'open', true );
		}
		var $box = $( el ).closest( '.tsosk-card, details, .tsosk-section' );
		var $hit = $box.length ? $box.first() : $( el );
		var top  = $hit.offset().top - 80;
		window.scrollTo( { top: Math.max( 0, top ), behavior: 'smooth' } );
		$hit.addClass( 'tsosk-section-flash' );
		window.setTimeout( function () {
			$hit.removeClass( 'tsosk-section-flash' );
		}, 2800 );
	}

	$( function () {
		tsoskGoToSection( 0 );
	} );
	$( window ).on( 'hashchange', function () {
		tsoskGoToSection( 0 );
	} );

	function tsoskSearchNavigate( url ) {
		if ( url ) {
			window.location.href = url;
		}
	}

	function tsoskSearchSetActive( index ) {
		var $items = $( '#tsosk-global-search-results li[data-index]' );
		$items.removeClass( 'is-active' );
		tsoskSearchActive = index;
		if ( index >= 0 && index < $items.length ) {
			$items.eq( index ).addClass( 'is-active' );
		}
	}

	$( document ).on( 'input', '#tsosk-global-search-input', function () {
		tsoskSearchRender( tsoskSearchFilter( $( this ).val() ) );
	} );

	$( document ).on( 'focus', '#tsosk-global-search-input', function () {
		tsoskSearchRender( tsoskSearchFilter( $( this ).val() ) );
	} );

	$( document ).on( 'keydown', '#tsosk-global-search-input', function ( e ) {
		var $list    = $( '#tsosk-global-search-results' );
		var $links   = $list.find( 'li[data-index] a' );
		var count    = $links.length;

		if ( e.key === 'ArrowDown' ) {
			e.preventDefault();
			tsoskSearchSetActive( count ? ( ( tsoskSearchActive + 1 ) % count ) : -1 );
		} else if ( e.key === 'ArrowUp' ) {
			e.preventDefault();
			tsoskSearchSetActive( count ? ( ( tsoskSearchActive - 1 + count ) % count ) : -1 );
		} else if ( e.key === 'Enter' ) {
			if ( tsoskSearchActive >= 0 && $links.eq( tsoskSearchActive ).length ) {
				e.preventDefault();
				tsoskSearchNavigate( $links.eq( tsoskSearchActive ).attr( 'href' ) );
			}
		} else if ( e.key === 'Escape' ) {
			$list.prop( 'hidden', true );
			$( this ).blur();
		}
	} );

	$( document ).on( 'click', function ( e ) {
		if ( ! $( e.target ).closest( '#tsosk-global-search' ).length ) {
			$( '#tsosk-global-search-results' ).prop( 'hidden', true );
		}
	} );

	$( document ).on( 'keydown', function ( e ) {
		if ( ( e.ctrlKey || e.metaKey ) && e.key.toLowerCase() === 'k' ) {
			var $input = $( '#tsosk-global-search-input' );
			if ( $input.length ) {
				e.preventDefault();
				$input.trigger( 'focus' ).select();
			}
		}
	} );

	// ── Developer mode preset ─────────────────────────────────────────────────

	function tsoskDeveloperMode( enable, $msg ) {
		var nonce = tsosk.debug_nonce || $( '#tsosk-debug-developer-on' ).data( 'nonce' );
		if ( ! nonce ) {
			return;
		}
		ajaxPost( {
			action : 'tsosk_debug_developer_mode',
			data   : { nonce: nonce, enable: enable ? 1 : 0 },
			success: function ( r ) {
				var text = r.success ? ( r.data && r.data.message ? r.data.message : tsosk.i18n.done ) : ( r.data || tsosk.i18n.error );
				if ( $msg && $msg.length ) {
					showMsg( $msg, text, r.success ? 'ok' : 'error' );
				}
				if ( r.success ) {
					window.location.reload();
				}
			},
			error: function () {
				if ( $msg && $msg.length ) {
					showMsg( $msg, tsosk.i18n.error, 'error' );
				}
			}
		} );
	}

	$( document ).on( 'click', '#tsosk-debug-developer-on, #tsosk-header-dev-mode-on', function () {
		tsoskDeveloperMode( true, $( '#tsosk-debug-msg' ) );
	} );

	$( document ).on( 'click', '#tsosk-debug-developer-off', function () {
		tsoskDeveloperMode( false, $( '#tsosk-debug-msg' ) );
	} );

	// ── Admin Menu Editor ─────────────────────────────────────────────────────

	function tsoskAmGetTopSlug( $topRow ) {
		return String( $topRow.attr( 'data-slug' ) || '' );
	}

	var tsoskAmExpandedSections = {};

	function tsoskAmSectionSlug( $row ) {
		return String( $row.attr( 'data-am-section' ) || $row.attr( 'data-slug' ) || '' );
	}

	function tsoskAmSubParentSlug( $row ) {
		return String( $row.attr( 'data-am-parent-section' ) || '' );
	}

	function tsoskAmTopRowBySection( sectionSlug ) {
		return $( '#tsosk-am-tbody tr.tsosk-am-row-top' ).filter( function () {
			return tsoskAmSectionSlug( $( this ) ) === sectionSlug;
		} );
	}

	function tsoskAmSubRowsBySection( sectionSlug ) {
		return $( '#tsosk-am-tbody tr.tsosk-am-row-sub, #tsosk-am-tbody tr.tsosk-am-row-nested-top' ).filter( function () {
			return tsoskAmGetSubParentSlug( $( this ) ) === sectionSlug;
		} );
	}

	function tsoskAmSetSectionExpanded( sectionSlug, expanded ) {
		if ( ! sectionSlug ) {
			return;
		}
		if ( expanded ) {
			tsoskAmExpandedSections[ sectionSlug ] = true;
		} else {
			delete tsoskAmExpandedSections[ sectionSlug ];
		}

		var $top = tsoskAmTopRowBySection( sectionSlug );
		$top.toggleClass( 'is-am-expanded', expanded );

		var $toggle = $top.find( '.tsosk-am-toggle' );
		if ( $toggle.length ) {
			$toggle.attr( 'aria-expanded', expanded ? 'true' : 'false' );
			$toggle.find( '.dashicons' )
				.toggleClass( 'dashicons-arrow-right-alt2', ! expanded )
				.toggleClass( 'dashicons-arrow-down-alt2', expanded );
		}

		tsoskAmSubRowsBySection( sectionSlug ).each( function () {
			var $sub = $( this );
			$sub.toggleClass( 'is-am-collapsed', ! expanded );
			$sub.prop( 'hidden', ! expanded );
		} );

		if ( $.fn.sortable && $( '#tsosk-am-tbody' ).hasClass( 'ui-sortable' ) ) {
			$( '#tsosk-am-tbody' ).sortable( 'refresh' );
		}
	}

	function tsoskAmApplyCollapseState() {
		$( '#tsosk-am-tbody tr.tsosk-am-row-top.tsosk-am-has-children' ).each( function () {
			var slug = tsoskAmSectionSlug( $( this ) );
			tsoskAmSetSectionExpanded( slug, !! tsoskAmExpandedSections[ slug ] );
		} );
	}

	function tsoskAmExpandAllSections( expand ) {
		$( '#tsosk-am-tbody tr.tsosk-am-row-top.tsosk-am-has-children' ).each( function () {
			tsoskAmSetSectionExpanded( tsoskAmSectionSlug( $( this ) ), expand );
		} );
	}

	function tsoskAmToggleSection( sectionSlug ) {
		tsoskAmSetSectionExpanded( sectionSlug, ! tsoskAmExpandedSections[ sectionSlug ] );
	}

	function tsoskAmGetSubParentSlug( $row ) {
		var nestUnder = $.trim( $row.find( '.tsosk-am-top-nest' ).val() || '' );
		if ( nestUnder && ( $row.hasClass( 'tsosk-am-row-nested-top' ) || $row.hasClass( 'tsosk-am-row-top' ) ) ) {
			return nestUnder;
		}
		return $row.find( '.tsosk-am-parent' ).val() || $row.attr( 'data-am-parent-section' ) || '';
	}

	function tsoskAmAssignParentFromDrag( $dragged ) {
		if ( ! $dragged || ! $dragged.length ) {
			return;
		}

		if ( $dragged.hasClass( 'tsosk-am-row-nested-top' ) ) {
			var $prevTop = $dragged.prevAll( 'tr.tsosk-am-row-top:first' );
			if ( $prevTop.length ) {
				var parentSlug = tsoskAmGetTopSlug( $prevTop );
				$dragged.find( '.tsosk-am-top-nest' ).val( parentSlug );
				$dragged.attr( 'data-am-parent-section', parentSlug );
			}
			return;
		}

		if ( $dragged.hasClass( 'tsosk-am-row-sub' ) ) {
			var $prevTop = $dragged.prevAll( 'tr.tsosk-am-row-top:first' );
			if ( $prevTop.length ) {
				$dragged.find( '.tsosk-am-parent' ).val( tsoskAmGetTopSlug( $prevTop ) );
			}
			return;
		}

		if ( $dragged.hasClass( 'tsosk-am-row-top' ) ) {
			var $prev = $dragged.prev( 'tr.tsosk-am-row' );
			if ( ! $prev.length ) {
				$dragged.find( '.tsosk-am-top-nest' ).val( '' );
				return;
			}
			if ( $prev.hasClass( 'tsosk-am-row-top' ) ) {
				$dragged.find( '.tsosk-am-top-nest' ).val( tsoskAmGetTopSlug( $prev ) );
				$dragged.attr( 'data-am-parent-section', tsoskAmGetTopSlug( $prev ) );
				return;
			}
			if ( $prev.hasClass( 'tsosk-am-row-sub' ) || $prev.hasClass( 'tsosk-am-row-nested-top' ) ) {
				var parentSlug = $prev.find( '.tsosk-am-parent' ).val() || $prev.attr( 'data-am-parent-section' ) || '';
				if ( ! parentSlug ) {
					var $sectionTop = $prev.prevAll( 'tr.tsosk-am-row-top:first' );
					if ( $sectionTop.length ) {
						parentSlug = tsoskAmGetTopSlug( $sectionTop );
					}
				}
				$dragged.find( '.tsosk-am-top-nest' ).val( parentSlug );
				$dragged.attr( 'data-am-parent-section', parentSlug );
			}
		}
	}

	function tsoskAmNormalizeRows( expandSection ) {
		var $tbody = $( '#tsosk-am-tbody' );
		if ( ! $tbody.length ) {
			return;
		}

		var rows = [];
		$tbody.find( 'tr.tsosk-am-row' ).each( function () {
			rows.push( $( this ).detach() );
		} );

		// Nested plugin menus restored to a top-level section.
		rows.forEach( function ( $row ) {
			if ( ! $row.hasClass( 'tsosk-am-row-nested-top' ) ) {
				return;
			}
			var nestUnder = $.trim( $row.find( '.tsosk-am-top-nest' ).val() || '' );
			if ( nestUnder ) {
				return;
			}
			var topSlug = tsoskAmGetTopSlug( $row );
			$row.removeClass( 'tsosk-am-row-sub tsosk-am-row-nested-top' )
				.addClass( 'tsosk-am-row-top' )
				.attr( 'data-am-section', topSlug )
				.removeAttr( 'data-am-parent-section' );
		} );

		// Top-level plugin menus configured to live under another section.
		rows.forEach( function ( $row ) {
			if ( ! $row.hasClass( 'tsosk-am-row-top' ) || $row.hasClass( 'tsosk-am-row-nested-top' ) ) {
				return;
			}
			var topSlug   = tsoskAmGetTopSlug( $row );
			var nestUnder = $.trim( $row.find( '.tsosk-am-top-nest' ).val() || '' );
			if ( ! nestUnder || nestUnder === topSlug ) {
				return;
			}
			$row.removeClass( 'tsosk-am-row-top' )
				.addClass( 'tsosk-am-row-sub tsosk-am-row-nested-top' )
				.attr( 'data-am-parent-section', nestUnder )
				.removeAttr( 'data-am-section' );
		} );

		var topRows          = [];
		var childrenByParent = {};

		rows.forEach( function ( $row ) {
			if ( $row.hasClass( 'tsosk-am-row-top' ) ) {
				topRows.push( $row );
				return;
			}
			var parent = tsoskAmGetSubParentSlug( $row );
			if ( ! parent ) {
				return;
			}
			if ( ! childrenByParent[ parent ] ) {
				childrenByParent[ parent ] = [];
			}
			childrenByParent[ parent ].push( $row );
		} );

		topRows.forEach( function ( $top ) {
			var slug = tsoskAmGetTopSlug( $top );
			$top.addClass( 'tsosk-am-row-top' ).removeClass( 'tsosk-am-row-sub tsosk-am-row-nested-top' );
			$top.attr( 'data-am-section', slug ).removeAttr( 'data-am-parent-section' );
			$tbody.append( $top );

			var kids = childrenByParent[ slug ] || [];
			kids.forEach( function ( $child ) {
				$tbody.append( $child );
			} );
		} );

		rows.forEach( function ( $row ) {
			if ( $row.hasClass( 'tsosk-am-row-top' ) ) {
				return;
			}
			var parent = tsoskAmGetSubParentSlug( $row );
			if ( parent && childrenByParent[ parent ] ) {
				var parentIsTop = topRows.some( function ( $top ) {
					return tsoskAmGetTopSlug( $top ) === parent;
				} );
				if ( parentIsTop ) {
					return;
				}
			}
			$tbody.append( $row );
		} );

		if ( expandSection ) {
			tsoskAmSetSectionExpanded( expandSection, true );
		} else {
			tsoskAmApplyCollapseState();
		}

		if ( $.fn.sortable && $tbody.hasClass( 'ui-sortable' ) ) {
			$tbody.sortable( 'refresh' );
		}
	}

	function tsoskAmCollectItems() {
		var items = [];
		var sort  = 0;

		function pushRow( $row ) {
			var isTopRow = $row.hasClass( 'tsosk-am-row-top' ) && ! $row.hasClass( 'tsosk-am-row-nested-top' );
			var item     = {
				id     : $row.attr( 'data-id' ),
				slug   : $.trim( $row.attr( 'data-slug' ) || '' ),
				visible: ! $row.find( '.tsosk-am-hide' ).is( ':checked' ),
				label  : $.trim( $row.find( '.tsosk-am-label' ).val() ),
				sort   : sort
			};

			if ( ! isTopRow ) {
				item.effective_parent = tsoskAmGetSubParentSlug( $row );
				item.parent_slug      = $row.find( '.tsosk-am-parent' ).val() || item.effective_parent || '';
				item.orig_parent        = $row.attr( 'data-orig-parent' ) || '';
			}
			if ( $row.hasClass( 'tsosk-am-row-top' ) || $row.hasClass( 'tsosk-am-row-nested-top' ) ) {
				item.nest_under = $.trim( $row.find( '.tsosk-am-top-nest' ).val() || '' );
			}

			items.push( item );
			sort += 1;
		}

		// Preserve exact on-screen order from the main list first.
		$( '#tsosk-am-tbody > tr.tsosk-am-row' ).each( function () {
			pushRow( $( this ) );
		} );
		$( '#tsosk-am-hidden-tbody > tr.tsosk-am-row' ).each( function () {
			pushRow( $( this ) );
		} );

		return items;
	}

	/**
	 * Build top/sub menu order maps from the current table layout (visual order).
	 *
	 * @return {{top_order: string[], sub_order: Object.<string, string[]>}}
	 */
	function tsoskAmBuildSectionOrders() {
		var topOrder    = [];
		var subOrder    = {};
		var subOrderIds = {};
		var currentSection = '';

		// Read exact tbody DOM order (do not regroup — preserves drag order).
		$( '#tsosk-am-tbody > tr.tsosk-am-row' ).each( function () {
			var $row   = $( this );
			var slug   = $.trim( $row.attr( 'data-slug' ) || '' );
			var id     = $.trim( $row.attr( 'data-id' ) || '' );
			var isTop  = $row.hasClass( 'tsosk-am-row-top' ) && ! $row.hasClass( 'tsosk-am-row-nested-top' );

			if ( isTop ) {
				if ( slug && topOrder.indexOf( slug ) === -1 ) {
					topOrder.push( slug );
				}
				currentSection = slug;
				return;
			}

			if ( ! slug || ! id ) {
				return;
			}

			var parent = tsoskAmGetSubParentSlug( $row ) || currentSection;
			if ( ! parent ) {
				return;
			}

			if ( ! subOrder[ parent ] ) {
				subOrder[ parent ]    = [];
				subOrderIds[ parent ] = [];
			}
			if ( subOrder[ parent ].indexOf( slug ) === -1 ) {
				subOrder[ parent ].push( slug );
			}
			if ( subOrderIds[ parent ].indexOf( id ) === -1 ) {
				subOrderIds[ parent ].push( id );
			}
		} );

		return {
			top_order     : topOrder,
			sub_order     : subOrder,
			sub_order_ids : subOrderIds
		};
	}

	var tsoskAmScrollActive = false;
	var tsoskAmScrollY      = 0;
	var tsoskAmScrollRaf    = null;

	function tsoskAmGetScrollTargets() {
		var targets = [];
		$( '.tsosk-content, #wpbody-content, #wpcontent, #wpwrap' ).each( function () {
			if ( this.scrollHeight > this.clientHeight + 2 ) {
				targets.push( this );
			}
		} );
		if ( document.scrollingElement ) {
			targets.push( document.scrollingElement );
		} else {
			targets.push( document.documentElement );
		}
		return targets;
	}

	function tsoskAmAutoScrollStep() {
		if ( ! tsoskAmScrollActive ) {
			tsoskAmScrollRaf = null;
			return;
		}

		var edge    = 80;
		var maxStep = 22;
		var y       = tsoskAmScrollY;

		function stepForRect( rect ) {
			if ( y < rect.top + edge ) {
				return -maxStep * Math.min( 1, ( rect.top + edge - y ) / edge );
			}
			if ( y > rect.bottom - edge ) {
				return maxStep * Math.min( 1, ( y - ( rect.bottom - edge ) ) / edge );
			}
			return 0;
		}

		tsoskAmGetScrollTargets().forEach( function ( el ) {
			var rect = ( el === document.documentElement || el === document.scrollingElement )
				? { top: 0, bottom: window.innerHeight }
				: el.getBoundingClientRect();
			var step = stepForRect( rect );
			if ( ! step ) {
				return;
			}
			if ( el === document.documentElement || el === document.scrollingElement ) {
				window.scrollBy( 0, step );
			} else {
				el.scrollTop += step;
			}
		} );

		tsoskAmScrollRaf = window.requestAnimationFrame( tsoskAmAutoScrollStep );
	}

	function tsoskAmBindDragScroll() {
		$( document ).on( 'mousemove.tsoskAmScroll touchmove.tsoskAmScroll', function ( e ) {
			tsoskAmUpdatePointerY( e );
		} );
	}

	function tsoskAmUnbindDragScroll() {
		$( document ).off( 'mousemove.tsoskAmScroll touchmove.tsoskAmScroll' );
	}

	function tsoskAmStartAutoScroll( event ) {
		tsoskAmUpdatePointerY( event );
		tsoskAmScrollActive = true;
		tsoskAmBindDragScroll();
		if ( ! tsoskAmScrollRaf ) {
			tsoskAmScrollRaf = window.requestAnimationFrame( tsoskAmAutoScrollStep );
		}
	}

	function tsoskAmStopAutoScroll() {
		tsoskAmScrollActive = false;
		tsoskAmUnbindDragScroll();
		if ( tsoskAmScrollRaf ) {
			window.cancelAnimationFrame( tsoskAmScrollRaf );
			tsoskAmScrollRaf = null;
		}
	}

	function tsoskAmUpdatePointerY( event ) {
		if ( event && typeof event.clientY === 'number' ) {
			tsoskAmScrollY = event.clientY;
			return;
		}
		var oe = event && event.originalEvent;
		if ( oe && oe.touches && oe.touches.length ) {
			tsoskAmScrollY = oe.touches[0].clientY;
		} else if ( oe && oe.changedTouches && oe.changedTouches.length ) {
			tsoskAmScrollY = oe.changedTouches[0].clientY;
		}
	}

	function tsoskAmInitSortable() {
		var $tbody = $( '#tsosk-am-tbody' );
		if ( ! $tbody.length || ! $.fn.sortable ) {
			return;
		}
		if ( $tbody.hasClass( 'ui-sortable' ) ) {
			$tbody.sortable( 'destroy' );
		}

		$tbody.sortable( {
			handle               : '.tsosk-am-handle',
			items                : '> tr.tsosk-am-row:not([hidden])',
			axis                 : 'y',
			appendTo               : document.body,
			scroll                 : false,
			tolerance              : 'pointer',
			distance               : 4,
			cursor                 : 'grabbing',
			forcePlaceholderSize   : true,
			cancel                 : 'input,textarea,select,button,a,label,.tsosk-am-toggle',
			helper                 : function ( e, $row ) {
				var $helper = $row.clone();
				$helper.children().each( function ( index ) {
					$( this ).width( $row.children().eq( index ).outerWidth() );
				} );
				$helper.css( {
					width    : $row.outerWidth(),
					display  : 'table',
					tableLayout : 'fixed',
					position : 'absolute',
					zIndex   : 100100
				} );
				return $helper;
			},
			start                : function ( event, ui ) {
				ui.item.addClass( 'tsosk-am-dragging' );
				ui.placeholder.height( ui.item.outerHeight() );
				tsoskAmStartAutoScroll( event );
			},
			sort             : function ( event ) {
				tsoskAmUpdatePointerY( event );
			},
			stop             : function ( event, ui ) {
				ui.item.removeClass( 'tsosk-am-dragging' );
				tsoskAmStopAutoScroll();
				tsoskAmAssignParentFromDrag( ui.item );
			}
		} );
	}

	function tsoskAmInit() {
		if ( ! $( '#tsosk-am-tbody' ).length ) {
			return;
		}
		tsoskAmInitSortable();
		tsoskAmExpandedSections = {};
		tsoskAmApplyCollapseState();
		var expandSections = $( '#tsosk-am-table' ).data( 'expand-sections' );
		if ( expandSections ) {
			String( expandSections ).split( ',' ).forEach( function ( slug ) {
				slug = $.trim( slug );
				if ( slug ) {
					tsoskAmSetSectionExpanded( slug, true );
				}
			} );
		}
	}

	$( tsoskAmInit );

	$( document ).on( 'click', '.tsosk-am-toggle', function ( e ) {
		e.preventDefault();
		e.stopPropagation();
		var $top = $( this ).closest( 'tr.tsosk-am-row-top' );
		tsoskAmToggleSection( tsoskAmSectionSlug( $top ) );
	} );

	$( document ).on( 'click', 'tr.tsosk-am-row-top.tsosk-am-has-children', function ( e ) {
		if ( $( e.target ).closest( '.tsosk-am-handle, input, select, textarea, button, a, label' ).length ) {
			return;
		}
		tsoskAmToggleSection( tsoskAmSectionSlug( $( this ) ) );
	} );

	$( document ).on( 'click', '#tsosk-am-expand-all', function ( e ) {
		e.preventDefault();
		tsoskAmExpandAllSections( true );
	} );

	$( document ).on( 'click', '#tsosk-am-collapse-all', function ( e ) {
		e.preventDefault();
		tsoskAmExpandAllSections( false );
	} );

	$( document ).on( 'change', '.tsosk-am-parent', function () {
		var $row = $( this ).closest( 'tr.tsosk-am-row-sub' );
		$row.attr( 'data-am-parent-section', $( this ).val() || '' );
		tsoskAmNormalizeRows();
	} );

	$( document ).on( 'change', '.tsosk-am-top-nest', function () {
		var nest = $.trim( $( this ).val() || '' );
		tsoskAmNormalizeRows( nest );
	} );

	$( document ).on( 'change', '.tsosk-am-hide', function () {
		var $row = $( this ).closest( 'tr' );
		var hidden = $( this ).is( ':checked' );
		$row.toggleClass( 'tsosk-am-row-is-hidden', hidden );
		$row.find( '.tsosk-am-label' ).prop( 'disabled', hidden );
	} );

	$( document ).on( 'click', '#tsosk-am-show-hidden', function ( e ) {
		e.preventDefault();
		var $section = $( '#tsosk-am-hidden-section' );
		if ( ! $section.length ) {
			return;
		}

		$section.addClass( 'is-highlighted' );
		setTimeout( function () {
			$section.removeClass( 'is-highlighted' );
		}, 2200 );

		var scrollTop = Math.max( 0, $section.offset().top - 100 );
		$( 'html, body, .tsosk-content' ).animate( { scrollTop: scrollTop }, 300 );

		var $first = $section.find( 'tr.tsosk-am-row' ).first();
		if ( $first.length ) {
			$first.addClass( 'tsosk-am-row-highlight' );
			setTimeout( function () {
				$first.removeClass( 'tsosk-am-row-highlight' );
			}, 2200 );
		}
	} );

	$( document ).on( 'click', '#tsosk-am-save', function () {
		var $btn  = $( this );
		var $msg  = $( '#tsosk-am-msg' );
		var nonce = $btn.data( 'nonce' );

		// Apply nest/unnest row layout, then read order from the table (sections stay collapsed).
		tsoskAmNormalizeRows();
		var sectionOrders = tsoskAmBuildSectionOrders();

		$btn.prop( 'disabled', true );

		ajaxPost( {
			action : 'tsosk_am_save',
			data   : {
				nonce         : nonce,
				items         : JSON.stringify( tsoskAmCollectItems() ),
				sub_order     : JSON.stringify( sectionOrders.sub_order ),
				sub_order_ids : JSON.stringify( sectionOrders.sub_order_ids ),
				top_order     : JSON.stringify( sectionOrders.top_order )
			},
			success: function ( r ) {
				if ( r.success ) {
					var text = tsosk.i18n.done;
					if ( r.data && typeof r.data === 'object' && r.data.message ) {
						text = r.data.message;
					} else if ( typeof r.data === 'string' && r.data ) {
						text = r.data;
					}
					showMsg( $msg, text, 'ok' );
					setTimeout( function () { window.location.reload(); }, 700 );
				} else {
					var errText = tsosk.i18n.error;
					if ( typeof r.data === 'string' && r.data ) {
						errText = r.data;
					} else if ( r.data && r.data.message ) {
						errText = r.data.message;
					}
					showMsg( $msg, errText, 'error' );
					$btn.prop( 'disabled', false );
				}
			},
			error: function () {
				showMsg( $msg, tsosk.i18n.error, 'error' );
				$btn.prop( 'disabled', false );
			}
		} );
	} );

	$( document ).on( 'click', '#tsosk-am-reset', function () {
		if ( ! window.confirm( tsosk.i18n.am_reset_confirm || 'Reset the admin menu to WordPress defaults?' ) ) {
			return;
		}
		var $btn  = $( this );
		var $msg  = $( '#tsosk-am-msg' );
		var nonce = $btn.data( 'nonce' );

		$btn.prop( 'disabled', true );

		ajaxPost( {
			action : 'tsosk_am_reset',
			data   : { nonce: nonce },
			success: function ( r ) {
				if ( r.success ) {
					showMsg( $msg, r.data || tsosk.i18n.done, 'ok' );
					setTimeout( function () { window.location.reload(); }, 900 );
				} else {
					showMsg( $msg, r.data || tsosk.i18n.error, 'error' );
					$btn.prop( 'disabled', false );
				}
			},
			error: function () {
				showMsg( $msg, tsosk.i18n.error, 'error' );
				$btn.prop( 'disabled', false );
			}
		} );
	} );

	// ── Custom 404 page ───────────────────────────────────────────────────────

	$( document ).on( 'click', '#tsosk-custom-404-preview', function () {
		var $btn    = $( this );
		var $msg    = $( '#tsosk-custom-404-msg' );
		var pageId  = $( '#tsosk-custom-404-page' ).val();
		var nonce   = $btn.data( 'preview-nonce' );
		var homeUrl = $btn.data( 'home-url' ) || '/';

		if ( ! pageId || pageId === '0' ) {
			showMsg( $msg, tsosk.i18n.custom_404_select_preview || tsosk.i18n.error, 'error' );
			return;
		}

		var url = homeUrl + ( homeUrl.indexOf( '?' ) >= 0 ? '&' : '?' )
			+ 'tsosk_404_preview=1'
			+ '&page_id=' + encodeURIComponent( pageId )
			+ '&preview_nonce=' + encodeURIComponent( nonce );

		if ( $( '#tsosk-custom-404-send-410' ).is( ':checked' ) ) {
			url += '&send_410=1';
		}

		window.open( url, '_blank', 'noopener,noreferrer' );
	} );

	$( document ).on( 'click', '#tsosk-custom-404-save', function () {
		var nonce   = $( this ).data( 'nonce' );
		var $msg    = $( '#tsosk-custom-404-msg' );
		var pageId  = $( '#tsosk-custom-404-page' ).val();

		ajaxPost( {
			action : 'tsosk_custom_404_save',
			data   : {
				nonce              : nonce,
				page_id            : pageId,
				hide_from_search   : $( '#tsosk-custom-404-hide-search' ).is( ':checked' ) ? 1 : 0,
				hide_from_admin    : $( '#tsosk-custom-404-hide-admin' ).is( ':checked' ) ? 1 : 0,
				force_direct_404   : $( '#tsosk-custom-404-force-direct' ).is( ':checked' ) ? 1 : 0,
				disable_url_guess  : $( '#tsosk-custom-404-disable-guess' ).is( ':checked' ) ? 1 : 0,
				send_410           : $( '#tsosk-custom-404-send-410' ).is( ':checked' ) ? 1 : 0
			},
			success: function ( r ) {
				var text = r.success ? ( r.data && r.data.message ? r.data.message : tsosk.i18n.done ) : ( r.data || tsosk.i18n.error );
				showMsg( $msg, text, r.success ? 'ok' : 'error' );
				if ( r.success && r.data ) {
					var $badge = $( '#tsosk-custom-404-status' );
					if ( r.data.active ) {
						$badge.attr( 'class', 'tsosk-badge tsosk-badge-ok' ).text( tsosk.i18n.custom_404_active || 'Custom 404 active' );
					} else {
						$badge.attr( 'class', 'tsosk-badge tsosk-badge-info' ).text( tsosk.i18n.custom_404_default || 'Using theme default 404' );
					}
				}
			},
			error: function () {
				showMsg( $msg, tsosk.i18n.error, 'error' );
			}
		} );
	} );

	// ── Staging Mode ───────────────────────────────────────────────────────

	$( document ).on( 'click', '#tsosk-staging-save', function () {
		var $btn  = $( this );
		var nonce = $btn.data( 'nonce' );
		var $msg  = $( '#tsosk-staging-msg' );

		$btn.prop( 'disabled', true );
		ajaxPost( {
			action : 'tsosk_staging_save',
			data   : {
				nonce            : nonce,
				show_badge       : $( '#tsosk-staging-show-badge' ).is( ':checked' ) ? 1 : 0,
				hide_from_search : $( '#tsosk-staging-hide-search' ).is( ':checked' ) ? 1 : 0,
				block_mail       : $( '#tsosk-staging-block-mail' ).is( ':checked' ) ? 1 : 0,
				log_mail         : $( '#tsosk-staging-log-mail' ).is( ':checked' ) ? 1 : 0,
				pause_cron       : $( '#tsosk-staging-pause-cron' ).is( ':checked' ) ? 1 : 0
			},
			success: function ( r ) {
				var text = r.success ? ( r.data || tsosk.i18n.done ) : ( r.data || tsosk.i18n.error );
				showMsg( $msg, text, r.success ? 'ok' : 'error' );
				if ( r.success ) {
					setTimeout( function () { window.location.reload(); }, 500 );
					return;
				}
				$btn.prop( 'disabled', false );
			},
			error: function () {
				showMsg( $msg, tsosk.i18n.error, 'error' );
				$btn.prop( 'disabled', false );
			}
		} );
	} );

	$( document ).on( 'click', '#tsosk-staging-clear-log', function () {
		var $btn  = $( this );
		var nonce = $btn.data( 'nonce' );
		var $msg  = $( '#tsosk-staging-msg' );
		var confirmMsg = ( tsosk.i18n && tsosk.i18n.confirm_clear_mail_log ) ? tsosk.i18n.confirm_clear_mail_log : tsosk.i18n.confirm_purge;
		if ( ! window.confirm( confirmMsg ) ) {
			return;
		}
		$btn.prop( 'disabled', true );
		ajaxPost( {
			action : 'tsosk_staging_clear_mail_log',
			data   : { nonce: nonce },
			success: function ( r ) {
				var text = r.success ? ( r.data || tsosk.i18n.done ) : ( r.data || tsosk.i18n.error );
				showMsg( $msg, text, r.success ? 'ok' : 'error' );
				if ( r.success ) {
					$( '#tsosk-staging-mail-log tbody' ).empty();
					setTimeout( function () { window.location.reload(); }, 600 );
				}
				$btn.prop( 'disabled', false );
			},
			error: function () {
				showMsg( $msg, tsosk.i18n.error, 'error' );
				$btn.prop( 'disabled', false );
			}
		} );
	} );

	$( document ).on( 'change', '#tsosk-staging-held-only', function () {
		var only = $( this ).prop( 'checked' );
		$( '#tsosk-staging-mail-log tbody tr' ).each( function () {
			var held = $( this ).attr( 'data-blocked' ) === '1';
			$( this ).toggle( ! only || held );
		} );
	} );

	// ── URL & HTTPS Doctor ─────────────────────────────────────────────────

	$( document ).on( 'click', '#tsosk-url-doctor-probe', function () {
		var $btn  = $( this );
		var nonce = $btn.data( 'nonce' );
		var $msg  = $( '#tsosk-url-doctor-msg' );
		var $box  = $( '#tsosk-url-doctor-probe-result' );

		$btn.prop( 'disabled', true );
		ajaxPost( {
			action : 'tsosk_url_doctor_probe',
			data   : { nonce: nonce },
			success: function ( r ) {
				$btn.prop( 'disabled', false );
				if ( ! r.success ) {
					showMsg( $msg, r.data || tsosk.i18n.error, 'error' );
					return;
				}
				var data = r.data || {};
				var $p = $( '<p/>' );
				var okText = ( tsosk.i18n && tsosk.i18n.ok_label ) ? tsosk.i18n.ok_label : 'OK';
				var warnText = ( tsosk.i18n && tsosk.i18n.needs_attention ) ? tsosk.i18n.needs_attention : '!';
				var $badge = $( '<span/>' )
					.addClass( data.ok ? 'tsosk-badge tsosk-badge-ok' : 'tsosk-badge tsosk-badge-warn' )
					.text( data.ok ? okText : warnText );
				$p.append( $badge ).append( document.createTextNode( ' ' + ( data.message || '' ) ) );
				if ( data.final_url ) {
					$p.append( document.createElement( 'br' ) );
					$p.append( $( '<code/>' ).text( String( data.final_url ) ) );
				}
				$box.empty().append( $p );
				showMsg( $msg, tsosk.i18n.done, 'ok' );
			},
			error: function () {
				showMsg( $msg, tsosk.i18n.error, 'error' );
				$btn.prop( 'disabled', false );
			}
		} );
	} );

	$( document ).on( 'click', '#tsosk-url-doctor-leftovers', function () {
		var $btn  = $( this );
		var nonce = $btn.data( 'nonce' );
		var $msg  = $( '#tsosk-url-doctor-leftovers-msg' );
		var $box  = $( '#tsosk-url-doctor-leftovers-result' );

		$btn.prop( 'disabled', true );
		ajaxPost( {
			action : 'tsosk_url_doctor_leftovers',
			data   : { nonce: nonce },
			success: function ( r ) {
				$btn.prop( 'disabled', false );
				if ( ! r.success ) {
					showMsg( $msg, r.data || tsosk.i18n.error, 'error' );
					return;
				}
				var data = r.data || {};
				var $p = $( '<p/>' );
				$p.append( document.createTextNode( data.message || '' ) );
				if ( data.replace_url && ! data.skip ) {
					$p.append( document.createElement( 'br' ) );
					$p.append(
						$( '<a/>' )
							.attr( 'href', data.replace_url )
							.text( data.replace_label || 'Search & Replace' )
					);
				}
				if ( data.counts_label && ! data.skip ) {
					$p.append( document.createElement( 'br' ) );
					$p.append(
						$( '<span/>' )
							.addClass( 'description' )
							.text( data.counts_label )
					);
				}
				$box.empty().append( $p );
				showMsg( $msg, tsosk.i18n.done, 'ok' );
			},
			error: function () {
				showMsg( $msg, tsosk.i18n.error, 'error' );
				$btn.prop( 'disabled', false );
			}
		} );
	} );

	$( document ).on( 'click', '#tsosk-runtime-opcache', function () {
		var $btn  = $( this );
		var nonce = $btn.data( 'nonce' );
		var $msg  = $( '#tsosk-runtime-opcache-msg' );
		$btn.prop( 'disabled', true );
		ajaxPost( {
			action : 'tsosk_runtime_opcache_reset',
			data   : { nonce: nonce },
			success: function ( r ) {
				$btn.prop( 'disabled', false );
				showMsg( $msg, r.success ? ( r.data || tsosk.i18n.done ) : ( r.data || tsosk.i18n.error ), r.success ? 'ok' : 'error' );
			},
			error: function () {
				showMsg( $msg, tsosk.i18n.error, 'error' );
				$btn.prop( 'disabled', false );
			}
		} );
	} );

	$( document ).on( 'click', '#tsosk-log-snippet-copy', function () {
		var $msg = $( '#tsosk-log-snippet-msg' );
		var text = $.trim( $( '#tsosk-log-snippet' ).text() );
		var doneLabel = ( tsosk.i18n && tsosk.i18n.copied ) ? tsosk.i18n.copied : 'Copied';
		function fallback() {
			var range = document.createRange();
			range.selectNodeContents( document.getElementById( 'tsosk-log-snippet' ) );
			var sel = window.getSelection();
			sel.removeAllRanges();
			sel.addRange( range );
			try {
				document.execCommand( 'copy' );
				showMsg( $msg, doneLabel, 'ok' );
			} catch ( e ) {
				showMsg( $msg, tsosk.i18n.error, 'error' );
			}
		}
		if ( navigator.clipboard && navigator.clipboard.writeText ) {
			navigator.clipboard.writeText( text ).then( function () {
				showMsg( $msg, doneLabel, 'ok' );
			} ).catch( fallback );
		} else {
			fallback();
		}
	} );

	$( document ).on( 'click', '#tsosk-runtime-copy-summary', function () {
		var $msg = $( '#tsosk-runtime-copy-msg' );
		var text = $( '#tsosk-runtime-summary' ).val() || '';
		var doneLabel = ( tsosk.i18n && tsosk.i18n.email_copied ) ? tsosk.i18n.email_copied : 'Copied';
		function onCopied() {
			showMsg( $msg, doneLabel, 'ok' );
		}
		if ( navigator.clipboard && navigator.clipboard.writeText ) {
			navigator.clipboard.writeText( text ).then( onCopied ).catch( function () {
				$( '#tsosk-runtime-summary' ).trigger( 'select' );
				try {
					document.execCommand( 'copy' );
					onCopied();
				} catch ( e ) {
					showMsg( $msg, tsosk.i18n.error, 'error' );
				}
			} );
		} else {
			$( '#tsosk-runtime-summary' ).trigger( 'select' );
			try {
				document.execCommand( 'copy' );
				onCopied();
			} catch ( e ) {
				showMsg( $msg, tsosk.i18n.error, 'error' );
			}
		}
	} );

	// ── View Counter ───────────────────────────────────────────────────────

	$( document ).on( 'click', '#tsosk-vc-save', function () {
		var $btn  = $( this );
		var nonce = $btn.data( 'nonce' );
		var $msg  = $( '#tsosk-vc-settings-msg' );
		var types = [];

		$( '.tsosk-vc-post-type:checked' ).each( function () {
			types.push( $( this ).val() );
		} );

		var roles = [];
		$( '.tsosk-vc-exclude-role:checked' ).each( function () {
			roles.push( $( this ).val() );
		} );

		ajaxPost( {
			action : 'tsosk_vc_save_settings',
			data   : {
				nonce                 : nonce,
				post_types            : types,
				exclude_logged_in     : $( '#tsosk-vc-exclude-logged-in' ).is( ':checked' ) ? 1 : '',
				track_outbound_links  : $( '#tsosk-vc-track-links' ).is( ':checked' ) ? 1 : '',
				track_header_links    : $( '#tsosk-vc-track-header-links' ).is( ':checked' ) ? 1 : '',
				track_downloads       : $( '#tsosk-vc-track-downloads' ).is( ':checked' ) ? 1 : '',
				track_download_links  : $( '#tsosk-vc-track-download-links' ).is( ':checked' ) ? 1 : '',
				download_extensions   : $( '#tsosk-vc-download-extensions' ).val(),
				download_images       : $( '#tsosk-vc-download-images' ).is( ':checked' ) ? 1 : '',
				exclude_roles         : roles,
				exclude_ips           : $( '#tsosk-vc-exclude-ips' ).val(),
				email_weekly_summary  : $( '#tsosk-vc-email-weekly' ).is( ':checked' ) ? 1 : '',
				email_period_days     : $( '#tsosk-vc-email-period' ).val(),
				email_recipient       : $( '#tsosk-vc-email-recipient' ).val()
			},
			success: function ( r ) {
				showMsg( $msg, ( r && r.data ) || tsosk.i18n.done, r && r.success ? 'ok' : 'error' );
			},
			error: function () {
				showMsg( $msg, tsosk.i18n.error, 'error' );
			}
		} );
	} );

	$( document ).on( 'click', '.tsosk-vc-fix-day', function () {
		var $btn = $( this );
		var ask  = $btn.data( 'confirm' );
		if ( ask && ! window.confirm( ask ) ) { // eslint-disable-line no-alert
			return;
		}
		var $msg = $( '#tsosk-vc-fix-msg' );
		$btn.prop( 'disabled', true );
		ajaxPost( {
			action : 'tsosk_vc_fix_day',
			data   : { nonce: $btn.data( 'nonce' ), date: $btn.data( 'date' ), mode: $btn.data( 'mode' ) },
			success: function ( r ) {
				if ( r.success ) {
					window.location.reload();
					return;
				}
				showMsg( $msg, r.data || tsosk.i18n.error, 'error' );
				$btn.prop( 'disabled', false );
			},
			error: function () {
				showMsg( $msg, tsosk.i18n.error, 'error' );
				$btn.prop( 'disabled', false );
			}
		} );
	} );

	$( document ).on( 'click', '#tsosk-vc-import', function () {
		var $btn  = $( this );
		var nonce = $btn.data( 'nonce' );
		var $msg  = $( '#tsosk-vc-import-msg' );
		var source = $( '#tsosk-vc-import-source' ).val();
		var done   = String( $btn.attr( 'data-imported' ) || '' ).split( ',' );
		var force  = '';

		// Importing adds to the counters: confirm before running the same source twice.
		if ( -1 !== $.inArray( source, done ) ) {
			if ( ! window.confirm( tsosk.i18n.vc_import_again_confirm ) ) {
				return;
			}
			force = 1;
		} else if ( '1' === String( $btn.attr( 'data-has-data' ) ) && ! window.confirm( tsosk.i18n.vc_import_has_data_confirm ) ) {
			// No import is recorded, but the counter already holds data (it may come from an earlier import).
			return;
		}

		ajaxPost( {
			action : 'tsosk_vc_import',
			data   : {
				nonce : nonce,
				source: source,
				force : force
			},
			success: function ( r ) {
				// Persistent (non-fading) result so the outcome of the import stays readable.
				var $result = $( '#tsosk-vc-import-result' );
				$result.text( ( r && r.data ) || tsosk.i18n.done ).toggleClass( 'is-error', ! ( r && r.success ) ).prop( 'hidden', false );
				if ( r && r.success ) {
					$btn.attr( 'data-has-data', '1' );
					$btn.attr( 'data-imported', ( String( $btn.attr( 'data-imported' ) || '' ) + ',' + source ).replace( /^,/, '' ) );
					tsooskVcLoadTopContent( $( '.tsosk-vc-period' ).first().closest( '.tsosk-filter-pills' ) );
				}
			},
			error: function () {
				showMsg( $msg, tsosk.i18n.error, 'error' );
			}
		} );
	} );

	$( document ).on( 'click', '#tsosk-vc-reset', function () {
		if ( ! window.confirm( tsosk.i18n.vc_reset_confirm ) ) {
			return;
		}
		var $btn  = $( this );
		var nonce = $btn.data( 'nonce' );
		var $msg  = $( '#tsosk-vc-reset-msg' );

		ajaxPost( {
			action : 'tsosk_vc_reset',
			data   : { nonce: nonce },
			success: function ( r ) {
				showMsg( $msg, ( r && r.data ) || tsosk.i18n.done, r && r.success ? 'ok' : 'error' );
				if ( r && r.success ) {
					// Counters are empty again: importing is safe again.
					$( '#tsosk-vc-import' ).attr( { 'data-imported': '', 'data-has-data': '0' } );
					$( '#tsosk-vc-import-result' ).prop( 'hidden', true ).text( '' );
				}
			},
			error: function () {
				showMsg( $msg, tsosk.i18n.error, 'error' );
			}
		} );
	} );

	// View Counter: Top Content report (period pills, built entirely with DOM
	// methods below — never string-concatenated HTML — since row values come
	// from the site's own titles/URLs and must be treated as untrusted text).
	function tsooskVcLoadTopContent( $pills ) {
		var nonce  = $pills.data( 'nonce' );
		var period = $pills.find( '.tsosk-filter-active' ).data( 'period' ) || '30';

		ajaxPost( {
			action : 'tsosk_vc_top_content',
			data   : { nonce: nonce, period: period },
			success: function ( r ) {
				if ( ! r || ! r.success ) {
					return;
				}
				var $postsBody = $( '#tsosk-vc-top-posts-table tbody' ).empty();
				var $linksBody = $( '#tsosk-vc-top-links-table tbody' ).empty();
				var $dlBody    = $( '#tsosk-vc-top-downloads-table tbody' ).empty();

				if ( ! r.data.posts.length ) {
					$postsBody.append( $( '<tr>' ).append( $( '<td colspan="2">' ).text( tsosk.i18n.vc_no_data ) ) );
				}
				$.each( r.data.posts, function ( i, row ) {
					var $link = $( '<a>' ).attr( 'href', row.edit_url ).text( row.title );
					$postsBody.append(
						$( '<tr>' ).append(
							$( '<td>' ).append( $link ),
							$( '<td>' ).text( row.total )
						)
					);
				} );

				if ( ! r.data.links.length ) {
					$linksBody.append( $( '<tr>' ).append( $( '<td colspan="2">' ).text( tsosk.i18n.vc_no_data ) ) );
				}
				$.each( r.data.links, function ( i, row ) {
					var $link = $( '<a>' ).attr( { href: row.url, target: '_blank', rel: 'noopener noreferrer' } ).text( row.url );
					$linksBody.append(
						$( '<tr>' ).append(
							$( '<td>' ).append( $link ),
							$( '<td>' ).text( row.total )
						)
					);
				} );

				var downloads = r.data.downloads || [];
				if ( ! downloads.length ) {
					$dlBody.append( $( '<tr>' ).append( $( '<td colspan="2">' ).text( tsosk.i18n.vc_no_data ) ) );
				}
				$.each( downloads, function ( i, row ) {
					var name  = String( row.url ).split( '/' ).pop() || row.url;
					var $link = $( '<a>' ).attr( { href: row.url, target: '_blank', rel: 'noopener noreferrer', title: row.url } ).text( name );
					$dlBody.append(
						$( '<tr>' ).append(
							$( '<td>' ).append( $link ),
							$( '<td>' ).text( row.total )
						)
					);
				} );
			}
		} );
	}

	$( document ).on( 'click', '.tsosk-vc-period', function () {
		var $pills = $( this ).closest( '.tsosk-filter-pills' );
		$pills.find( '.tsosk-vc-period' ).removeClass( 'tsosk-filter-active' );
		$( this ).addClass( 'tsosk-filter-active' );
		tsooskVcLoadTopContent( $pills );
	} );

	if ( $( '#tsosk-vc-top-posts-table' ).length ) {
		tsooskVcLoadTopContent( $( '.tsosk-vc-period' ).first().closest( '.tsosk-filter-pills' ) );
	}

	/* ── Info popovers (long table notes) ─────────────────────────────────── */
	function tsoskCloseInfoPops() {
		$( '.tsosk-info-pop:not([hidden])' ).prop( 'hidden', true );
		$( '.tsosk-info-btn[aria-expanded="true"]' ).attr( 'aria-expanded', 'false' );
	}

	$( document ).on( 'click', '.tsosk-info-btn', function ( e ) {
		e.preventDefault();
		e.stopPropagation();
		var $btn  = $( this );
		var $pop  = $btn.siblings( '.tsosk-info-pop' ).first();
		var isOpen = ! $pop.prop( 'hidden' );
		tsoskCloseInfoPops();
		if ( isOpen ) {
			return;
		}
		$pop.prop( 'hidden', false );
		$btn.attr( 'aria-expanded', 'true' );

		var rect = this.getBoundingClientRect();
		var popW = $pop.outerWidth();
		var popH = $pop.outerHeight();
		var left = Math.max( 12, Math.min( rect.left, window.innerWidth - popW - 12 ) );
		var top  = rect.bottom + 6;
		if ( top + popH > window.innerHeight - 12 && rect.top - popH - 6 > 12 ) {
			top = rect.top - popH - 6;
		}
		$pop.css( { left: left + 'px', top: top + 'px' } );
	} );

	$( document ).on( 'click', function ( e ) {
		if ( ! $( e.target ).closest( '.tsosk-info' ).length ) {
			tsoskCloseInfoPops();
		}
	} );

	$( document ).on( 'keydown', function ( e ) {
		if ( 'Escape' === e.key ) {
			tsoskCloseInfoPops();
		}
	} );

	window.addEventListener( 'scroll', tsoskCloseInfoPops, true );
	$( window ).on( 'resize', tsoskCloseInfoPops );


} )( jQuery );